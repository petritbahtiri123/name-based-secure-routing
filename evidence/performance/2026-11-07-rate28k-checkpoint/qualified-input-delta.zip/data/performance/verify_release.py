"""Refresh release identity and VM readiness without transferring or rebuilding."""
import pathlib,sys,json
HERE=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(HERE/'cells/rate28k'))
from prepare_remote import run,ssh
import plan,resource_boundary
counts=resource_boundary.check(starting=True)
(HERE/'cells/rate28k/LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
manifest=json.loads((HERE/'release-build-manifest.json').read_bytes())
for role in plan.HOSTS:
 code='''import pathlib,os,json,hashlib,shutil,subprocess,socket
base=pathlib.Path(BASE);p=pathlib.Path(RELEASE)
assert os.getuid()==os.getgid()==1001 and sorted(os.sched_getaffinity(0))==[0,1]
assert base.resolve(strict=True)==base and base.stat().st_uid==1001 and p.resolve(strict=True)==p and p.stat().st_uid==1001
assert {x.name for x in p.iterdir()}==set(HASHES)
assert all(not (p/n).is_symlink() and (p/n).stat().st_size==SIZES[n] and hashlib.sha256((p/n).read_bytes()).hexdigest()==h and ((p/n).stat().st_mode&0o777)==0o500 for n,h in HASHES.items())
assert shutil.disk_usage(base).free>=10*1024**3+6*600*1024**2 and shutil.disk_usage('/run').free>=32*1024**2
assert int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>=2*1024**3
assert not list(pathlib.Path('/sys/fs/cgroup/system.slice').glob('nbsr*')) and not list(pathlib.Path('/run').glob('nbsr*'))
paths=[]
for n in (28,):
 suffix='rxe20261107'+str(n).zfill(2)
 paths += [base/('control'+suffix),base/('controlbundle-nbsr-sphere-'+suffix+'.zip'),base/'evidence'/('run'+suffix),base/'evidence'/('system'+suffix)]
assert not any(os.path.lexists(x) for x in paths)
def cmd(args):return subprocess.run(args,capture_output=True,text=True,timeout=4,check=True).stdout.strip()
assert cmd(['git','-C',str(base/'repo'),'rev-parse','HEAD'])==SHA
assert cmd(['git','-C',str(base/'repo'),'status','--porcelain'])==''
assert cmd(['sudo','-i','--','/usr/bin/id','-u'])=='0'
route=json.loads(cmd(['/usr/sbin/ip','-j','route','get',PEER]))[0]
assert route['dev']=='eth1' and route['prefsrc']==IP
print(json.dumps(dict(role=ROLE,hostname=socket.gethostname(),uid=os.getuid(),binary_sha256=HASHES,binary_sizes=SIZES,mode='0500',fresh_planned_paths=[str(x) for x in paths],source_sha=SHA,clean_checkout=True,route=route,root_probe=0,disk_free=shutil.disk_usage(base).free,active_owned_resources=[])))
'''
 values=dict(BASE=plan.ROOT,RELEASE=plan.config()[role]['binaries'],HASHES=manifest['binary_sha256'],SIZES=manifest['binary_sizes'],SHA=plan.SHA,ROLE=role,PEER=plan.IPS['destination' if role=='source' else 'source'],IP=plan.IPS[role])
 prefix='\n'.join(k+'='+repr(v) for k,v in values.items())+'\n'
 run(role,'verify-release',ssh(role,['python3','-B','-c',prefix+code]))
 print('RELEASE_AND_READINESS_VERIFIED',role,flush=True)
