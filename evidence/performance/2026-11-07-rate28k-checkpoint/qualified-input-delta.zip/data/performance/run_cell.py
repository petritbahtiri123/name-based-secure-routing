"""One bounded authorized performance cell. No retries or automatic next cell."""
import hashlib,json,pathlib,runpy,sys,time
H=pathlib.Path(__file__).resolve().parent;label=sys.argv[1];C=H/'cells'/label
def read(p):return json.loads(p.read_bytes())
def fresh(p,data):
    with p.open('x') as f:json.dump(data,f,indent=2)
campaign=read(H/'plan.json');rows=campaign['cells'];index=next(i for i,r in enumerate(rows) if r['label']==label);row=rows[index]
assert not (H/'STOP.json').exists() and not (C/'attempt.json').exists()
from qualification_gate import verified_sources
qualified_pins=verified_sources(H,label)
for earlier in rows[:index]:assert read(H/'cells'/earlier['label']/'accepted.json')['advance'] is True
for role in ('source','destination'):assert read(H/'cells/rate28k'/('step-'+role+'-verify-release/supervision.json'))['status']=='LOCAL_WORKER_COMPLETED'
sys.path.insert(0,str(C));from activate import activate
activate()
import plan,resource_boundary
from scripts.performance.linux_native_pair import verify_index
counts=resource_boundary.check(starting=True)
(C/'LOCAL-ADMISSION.json').write_text(json.dumps({'retained_bytes':counts['task']}))
fresh(C/'attempt.json',dict(label=label,utc=time.time(),one_attempt=True))
enabled=False
try:
    from prepare_remote import run
    run('local','cold-bootstrap',[sys.executable,'-B',str(C/'bootstrap.py')])
    assert verified_sources(H,label)==qualified_pins
    activation=H/'activation';activation.mkdir(exist_ok=True)
    (C/'LIVE-DISABLED.json').rename(activation/(label+'-LIVE-DISABLED.json'));enabled=True
    fresh(C/'LIVE-AUTHORIZATION.json',dict(label=label,scope='one bounded approved performance cell',runtime_activation=False))
    # Preserve the qualification-time hashes. Only the explicit one-cell
    # authorization is a newly generated staging member.
    pins=dict(qualified_pins)
    pins['LIVE-AUTHORIZATION.json']=hashlib.sha256((C/'LIVE-AUTHORIZATION.json').read_bytes()).hexdigest()
    (C/'staging-inventory.json').write_text(json.dumps(pins,indent=2))
    import archive_prepare
    archive_prepare.prepare()
    import tls_and_trial
    tls_and_trial.main()
    runpy.run_path(str(C/'collect_guard.py'),run_name='__main__')
    trial=C/'run01-trial';sup=read(trial/'supervision.json');result=read(trial/'coordinator/result.json');cleanup=read(trial/'independent-cleanup.json')
    assert sup['status']=='LOCAL_WORKER_COMPLETED' and sup['owned_handles'] is False and sup['drain_failure'] is None and sup['elapsed_seconds']<115
    assert cleanup['errors']=={} and read(trial/'final-result.json')['status']==plan.final_gate(result,cleanup['receipts'])
    for role in plan.HOSTS:assert verify_index(trial/'coordinator'/role)==result['endpoint_indexes'][role]
    accounting=read(trial/'coordinator/essential-accounting.json')
    assert accounting['integrity_complete'] and accounting['scheduled']==row['scheduled'] and accounting['issued']==accounting['completed'] and accounting['completed']+accounting['unissued']==row['scheduled'] and accounting['failed']==accounting['unresolved']==0
    assert result['recv_errors']['diagnostic']['mode']=='off'
    from scripts.performance.linux_native_paced import read_paced
    cell=dict(path='nbsr',cores=1,payload_bytes=1024,streams=row['streams'],outstanding=1,benchmark_seconds=20,origin_record=True,diagnostic_rate=[row['rate'],1])
    parsed=read_paced(trial/'coordinator/source/peer/stdout',cell)
    metrics={}
    for role in plan.HOSTS:
        guard=read(C/('step-'+role+'-collect-guard/stdout.log'));summary=read(C/('guard-summary-'+role+'.json'))
        assert guard['failure'] is None and guard['exit']==0 and not guard['counter_trace'].get('invalid',False)
        metrics[role]=dict(summary,service_cpu_usec=guard['cpu_after']['usage_usec']-guard['cpu_before']['usage_usec'])
    # A single finite pass is an observation, never a capacity or causality claim.
    advance=accounting['completed']/row['scheduled']>=0.999
    if index:
        previous=read(H/'cells'/rows[index-1]['label']/'accepted.json')
        if parsed['p99_latency_ns']>2*previous['parsed']['p99_latency_ns'] and accounting['completed']<=previous['accounting']['completed']:
            advance=False
    accepted=dict(accepted=True,label=label,streams=row['streams'],rate=row['rate'],accounting=accounting,metrics=metrics,parsed=parsed,advance=advance)
    fresh(C/'accepted.json',accepted)
    if not accepted['advance']:fresh(H/'STOP.json',dict(reason='completion ratio or latency advancement gate',label=label))
    print('ACCEPTED_PERFORMANCE_CELL',label,json.dumps(accounting),flush=True)
except BaseException as exc:
    if not (H/'STOP.json').exists():fresh(H/'STOP.json',dict(label=label,type=type(exc).__name__,message=str(exc),decision='STOP_NO_REPLACEMENT'))
    raise
finally:
    if enabled and not (C/'LIVE-DISABLED.json').exists():fresh(C/'LIVE-DISABLED.json',dict(live_enabled=False,reason='single attempt ended; no relaunch'))
