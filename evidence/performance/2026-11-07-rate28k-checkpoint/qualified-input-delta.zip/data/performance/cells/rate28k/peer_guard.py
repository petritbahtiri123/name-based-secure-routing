"""Finite in-unit monitor; systemd retains ownership of every descendant."""
import json, math, os, pathlib, shutil, subprocess, sys, time
from plan import ROOT, IPS, WORK, TIMER_CPU
from affinity_guard import Watch
from benchmark_contract import Guard
from throttle_intervals import CounterWatch
from fresh_output import count_output

def arguments(argv, now):
    args=list(argv); i=args.index('--global-deadline')
    value=float(args[i+1]); del args[i:i+2]
    if not math.isfinite(value) or value<=now: raise ValueError('expired global deadline')
    return args,min(now+WORK,value)

class Progress:
    def __init__(self,path):
        self.path=path; self.offset=0; self.pending=b''; self.started=False; self.origin=None
        from activate import activate
        activate()
        from scripts.performance.b5_grouped import ProgressValidator
        self.grouped=ProgressValidator(1,1024)
    def poll(self,guard,now):
        if not self.path.exists(): return
        if not self.started:
            self.started=True;guard.monitor_progress=True;guard.last_progress=[now]
        size=self.path.stat().st_size
        if size<self.offset or size>4*1024**2: raise RuntimeError('progress file bounds')
        with self.path.open('rb') as f:
            f.seek(self.offset);data=f.read(65537)
        if len(data)>65536: raise RuntimeError('progress backlog')
        self.offset+=len(data);self.pending+=data
        lines=self.pending.split(b'\n');self.pending=lines.pop()
        if len(self.pending)>8192: raise RuntimeError('progress line bounds')
        for line in lines:
            row=json.loads(line)
            if row.get('schema')=='nbsr-origin-monotonic-v1':
                lo=row.get('origin_lo_ns');hi=row.get('origin_hi_ns')
                a=row.get('sample_before_ns');b=row.get('sample_after_ns')
                if self.origin is not None or any(type(v) is not int for v in (lo,hi,a,b)) or not 0<=lo<=hi<=b or a>b or hi-lo!=b-a or b-a>1_000_000:
                    raise RuntimeError('invalid or duplicate origin record')
                self.origin=row
                continue
            if row.get('schema')=='nbsr-b5-grouped-progress-v1':
                self.grouped.accept(row)
                if row['completed']>guard.completed[0]:guard.progress(0,row['completed'],now)
                continue
            if row.get('schema')=='nbsr-b5-grouped-final-v1':
                self.grouped.finish(row)
                continue
            if row.get('event')!='p2a_progress':continue
            if row.get('schema')!='nbsr-b5-progress-v1' or row.get('errors')!=0 or row.get('timeouts')!=0:
                raise RuntimeError('application progress integrity')
            guard.progress(0,row.get('completed_total'),now)

def keyvals(path):
    return {k:int(v) for k,v in (line.split() for line in path.read_text().splitlines())}

def sample(root,cgroup,role,expected_affinity=None):
    if role == 'source' and expected_affinity is not None and os.sched_getaffinity(0) != expected_affinity:
        raise RuntimeError('support affinity mismatch')
    quota=(cgroup/'cpu.max').read_text().strip()
    if quota!='100000 100000':raise RuntimeError('actual service CPU quota/period mismatch')
    net=pathlib.Path('/sys/class/net/eth1/statistics')
    counter=lambda n:int((net/n).read_text())
    peer=IPS['destination' if role=='source' else 'source']
    route=json.loads(subprocess.check_output(['/usr/sbin/ip','-j','route','get',peer],timeout=.5))[0]
    if route.get('prefsrc')!=IPS[role]:raise RuntimeError('wrong source address')
    events=keyvals(cgroup/'memory.events'); pids=keyvals(cgroup/'pids.events')
    return dict(cpu_max=quota,now=time.monotonic(),memory=int((cgroup/'memory.current').read_text()),
        tasks=int((cgroup/'pids.current').read_text()),
        available=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024,
        disk_free=shutil.disk_usage(root).free if shutil.disk_usage('/run').free>=32*1024**2 else 0,
        task_bytes=count_output(root/'evidence/runrxe2026110728')+count_output(root/'evidence/systemrxe2026110728'),
        tx=counter('tx_bytes'),rx=counter('rx_bytes'),drops=counter('tx_dropped')+counter('rx_dropped'),
        errors=counter('tx_errors')+counter('rx_errors'),oom=events.get('oom',0)+events.get('oom_kill',0),
        pids_denied=pids.get('max',0),route=route.get('dev'))

def main():
    started=time.monotonic();args,deadline=arguments(sys.argv[1:],started)
    role=args[args.index('--role')+1]
    from remote_ops import security_snapshot
    from tls_lifetime import gate
    security_snapshot(role);gate(role,420,public=True)
    if role == 'source' and os.sched_getaffinity(0) != {0, 1}:
        raise RuntimeError('initial support affinity mismatch')
    root=pathlib.Path(ROOT);out=root/'evidence/runrxe2026110728'
    cgroup=pathlib.Path('/sys/fs/cgroup')/next(x[3:] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')).lstrip('/')
    guard=Guard(connections=1,t0=started,monitor_progress=False,artifact_mib=(406 if role=="source" else 600))
    progress=Progress(out/role/'peer/stdout')
    affinity=None # Existing native sample_process enforces uniform CPU0 for every thread.
    affinity_result=None
    counters=CounterWatch({'service':cgroup/'cpu.stat','system':cgroup.parent/'cpu.stat','root':cgroup.parent.parent/'cpu.stat'})
    rows=[];child=None;failure=None;cpu_before=keyvals(cgroup/'cpu.stat')
    try:
        counters.poll()
        first=sample(root,cgroup,role);rows.append(first);guard.sample(**{k:v for k,v in first.items() if k!='cpu_max'})
        if time.monotonic()>=deadline:raise TimeoutError('endpoint work limit')
        child=subprocess.Popen([sys.executable,*args],stdin=sys.stdin,stdout=sys.stdout,stderr=sys.stderr,
            env={**os.environ,'BENCHMARK_DEADLINE_MONOTONIC':str(deadline)})
        support_affinity_ns=time.monotonic_ns()
        next_sample=started+1
        while child.poll() is None:
            now=time.monotonic()
            if now>=deadline:raise TimeoutError('endpoint work limit')
            counters.poll()
            if now>=next_sample:
                row=sample(root,cgroup,role,{0, 1});rows.append(row)
                if role=='source':progress.poll(guard,row['now'])
                guard.sample(**{k:v for k,v in row.items() if k!='cpu_max'})
                if affinity is not None:affinity.poll()
                next_sample+=1
            time.sleep(min(.05,max(0,deadline-time.monotonic())))
        counters.poll(force=True)
        if role=='source':
            progress.poll(guard,time.monotonic())
            if progress.origin is None:raise RuntimeError('missing origin record')
            if support_affinity_ns > progress.origin['origin_lo_ns']:raise RuntimeError('support affinity set after origin')
            if os.sched_getaffinity(0) != {0, 1}:raise RuntimeError('final support affinity mismatch')
        if affinity is not None:affinity_result=affinity.finish()
        result=child.returncode
    except BaseException as e:
        failure={'type':type(e).__name__,'message':str(e)}
        if child is not None and child.poll() is None:
            child.terminate()
            try:child.wait(timeout=min(5,max(.01,deadline-time.monotonic())))
            except subprocess.TimeoutExpired:
                child.kill();child.wait(timeout=1)
        result=125
    finally:
        try: counter_trace=counters.result()
        except BaseException as e:
            counter_trace={'invalid':True,'failure':{'type':type(e).__name__,'message':str(e)[:256]}}
            if failure is None:failure={'type':'CounterEvidenceFailure','message':str(e)[:256]}
        (out/('guard-'+role+'.json')).write_text(json.dumps(dict(affinity=affinity_result,cgroup=str(cgroup),failure=failure,elapsed=time.monotonic()-started,
            origin=progress.origin,support_affinity=sorted(os.sched_getaffinity(0)),counter_trace=counter_trace,deadline=deadline,exit=child.poll() if child else None,samples=rows,completed=guard.completed,cpu_before=cpu_before,cpu_after=keyvals(cgroup/'cpu.stat'))))

    return 125 if failure is not None else result

if __name__=='__main__':raise SystemExit(main())
