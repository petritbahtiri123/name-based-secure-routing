"""Opt-in returned-error evidence. No transport, privilege or workload changes."""
import argparse,hashlib,json,os,re,stat
from pathlib import Path,PurePosixPath
from scripts.performance.linux_b5_ceiling import require
from scripts.performance.recv_error_validate import validate,object_pairs,integer

FILES=('recv-errors.json','recv-errors-file.json','recv-errors-sockets.ndjson')
def identity(run):
    require(type(run) is str and re.fullmatch('[0-9a-f]{32}',run),'receive-error run identity')
class Once(argparse.Action):
    def __call__(self,parser,namespace,values,option_string=None):
        require(getattr(namespace,self.dest,None) is None,'duplicate receive-error activation')
        setattr(namespace,self.dest,values)
def declaration(run,mode):
    if run is None and mode is None:return None
    identity(run);require(mode == 'off','explicit receive-error mode')
    return dict(run=run,mode=mode)
def workload(cell):
    require(cell==dict(path='nbsr',cores=1,payload_bytes=1024,streams=16,outstanding=1,benchmark_seconds=20,origin_record=True,diagnostic_rate=[28000,1]),'receive-error workload')
def overrides(role,cell,root,decl):
    if decl is None:return {}
    require(declaration(**decl)==decl,'activation fields');workload(cell)
    path=PurePosixPath(str(root));require(path.is_absolute() and '..' not in path.parts and str(path)==str(root),'diagnostic output path')
    require(role in ('source','destination'),'diagnostic role')
    if role=='source' and decl['mode']=='on':return dict(NBSR_RECV_ERRORS_RUN=decl['run'],NBSR_RECV_ERRORS_FILE=str(path/FILES[0]))
    return {}
def bounded(path,cap):
    path=Path(path);require(not any(p.is_symlink() for p in (path,*path.parents)),'evidence link')
    st=path.lstat();require(stat.S_ISREG(st.st_mode) and 0<=st.st_size<=cap,'evidence file bound')
    with path.open('rb') as f:
        before=os.fstat(f.fileno());require((before.st_dev,before.st_ino)==(st.st_dev,st.st_ino),'evidence replaced')
        data=f.read(cap+1);after=os.fstat(f.fileno())
    require(len(data)==st.st_size and (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'evidence changed')
    return data
def read(root,name,cap=65536):return json.loads(bounded(Path(root)/name,cap),object_pairs_hook=object_pairs)
def put(root,name,value):
    with (Path(root)/name).open('x') as f:json.dump(value,f,sort_keys=True)

class Observer:
    """One bounded external socket observation, identically enabled for OFF/ON."""
    def __init__(self,root,decl,binary,address):
        self.root=Path(root);self.decl=decl;self.binary=str(binary);self.address=address;self.count=0;self.done=False
        for name in FILES:require(not os.path.lexists(self.root/name),'fresh diagnostic artifacts')
    def sample(self,sample):
        if self.done or sample['state']=='Z':return
        require(self.count<20,'receive-error socket observation exhausted')
        from scripts.performance.linux_socket_ownership import snapshot
        row=snapshot(sample['pid'],sample['start_ticks'],self.binary,self.address);self.count+=1
        wire=json.dumps(row)+'\n';require(len(wire.encode())<=65536,'socket row bound')
        with (self.root/FILES[2]).open('a') as f:f.write(wire)
        if row['status']=='MEASURED_LIVE_SOCKET_SNAPSHOT':
            require(len(row['sockets'])==1,'one measured source socket required');self.done=True
    def seal(self):
        require(self.done,'missing receive-error socket observation')
        if self.decl['mode']=='off':
            require(not os.path.lexists(self.root/FILES[0]),'OFF produced errors sidecar');return
        data=bounded(self.root/FILES[0],65536)
        put(self.root,FILES[1],dict(schema='nbsr-recv-errors-file-v1',run=self.decl['run'],role='source',name=FILES[0],bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))

def admit_peer(root,role,env,config):
    root=Path(root);decl=env.get('recv_errors')
    if config is None:
        require(decl is None and not any(os.path.lexists(root/n) for n in FILES),'undeclared receive-error evidence');return None
    require(set(config)=={'run','mode',*[r+'_'+k for r in ('source','destination') for k in ('output','executable','authority')]},'receive-error config fields')
    expected=declaration(config['run'],config['mode']);require(decl==expected,'receive-error activation mismatch')
    require(env['output_root']==str(PurePosixPath(config[role+'_output'])/'peer'),'receive-error output pin')
    workload(env['cell'])
    require(not env.get('live_socket_observer') and not env.get('source_live_guard') and not env.get('paired_live_guards'),'conflicting live observer')
    from scripts.performance.linux_native_peer import native_command
    for key in ('executable','authority'):
        value=config[role+'_'+key];path=PurePosixPath(value)
        require(path.is_absolute() and '..' not in path.parts and str(path)==value,'pinned '+key+' path')
    expected_argv,_=native_command(env['cell'],role,PurePosixPath(config[role+'_executable']).parent,PurePosixPath(config[role+'_authority']),PurePosixPath(env['output_root']),bind=env['bind'],endpoint=env['endpoint'],post_close_reports=True)
    command=read(root,'command.json')
    prefix=[env['linux_environment']['taskset'],'--cpu-list',','.join(map(str,env['linux_environment']['selected_cpus']))]
    require(expected_argv[0]==config[role+'_executable'] and command['argv']==prefix+expected_argv,'exact diagnostic argv mismatch')
    require(read(root,'executed-binary.json')['path']==command['argv'][3],'executed path/argv mismatch')
    if role=='destination':
        require(not any(os.path.lexists(root/n) for n in FILES),'source-only receive-error artifacts');return None
    return validate_source(root,env,expected)

def validate_source(root,env,decl):
    from scripts.performance.linux_native_paced import read_paced
    from scripts.performance.linux_socket_ownership import validate_binding,validate_history
    row=read_paced(root/'stdout',env['cell']);origin=row['origin_record'];duration=row['final']['measurement_duration_ns']
    require(set(origin)==set('schema origin_lo_ns origin_hi_ns sample_before_ns sample_after_ns client_origin_ns client_sample_ns'.split()),'independent client clock missing')
    o=integer(origin['client_origin_ns']);s=integer(origin['client_sample_ns']);require(s>=o,'client clock precedes origin')
    lo=origin['origin_lo_ns'];hi=origin['origin_hi_ns']
    require(lo==origin['sample_before_ns']-(s-o) and hi==origin['sample_after_ns']-(s-o),'client clock bridge mismatch')
    resources=[json.loads(x,object_pairs_hook=object_pairs) for x in bounded(root/'resources.ndjson',1024*1024).splitlines()]
    require(len(resources)>=2,'process observation span')
    pid=read(root,'pid.json')['pid'];ticks=resources[0]['start_ticks'];previous=-1
    for r in resources:
        require(r['pid']==pid and r['start_ticks']==ticks and integer(r['timestamp_ns'])>=previous,'external process identity/time')
        previous=r['timestamp_ns']
    require(resources[0]['timestamp_ns']<=lo and resources[-1]['timestamp_ns']>=hi+duration,'process does not cover measurement')
    exe=read(root,'executed-binary.json');require(exe.get('proc_exe_verified') is True and exe['sha256']==env['binary_sha256']['perf_rust_source'],'executed source binding')
    history=bounded(root/FILES[2],20*65536).decode();lines=history.splitlines();require(1<=len(lines)<=20,'socket attempts bound')
    observed=json.loads(lines[-1],object_pairs_hook=object_pairs)
    require(len(observed['sockets'])==1,'one expected socket required');sock=observed['sockets'][0]
    require(sock['local'][0]==env['bind'].rsplit(':',1)[0],'observed bind')
    validate_binding(observed,pid=pid,start_ticks=ticks,binary=exe['path'],local=sock['local'])
    validate_history(observed,history,resource_start_ns=resources[0]['timestamp_ns'],resource_end_ns=resources[-1]['timestamp_ns'])
    if decl['mode']=='off':
        require(not any(os.path.lexists(root/n) for n in FILES[:2]),'OFF diagnostic sidecar');return dict(mode='off',socket_observed=True,error_count='NOT_RECORDED')
    data=bounded(root/FILES[0],65536);receipt=read(root,FILES[1],4096)
    require(receipt==dict(schema='nbsr-recv-errors-file-v1',run=decl['run'],role='source',name=FILES[0],bytes=len(data),sha256=hashlib.sha256(data).hexdigest()),'error receipt binding')
    expected=[dict(generation=1,fd=sock['fd'],inode=sock['inode'],local=f"{sock['local'][0]}:{sock['local'][1]}")]
    checked=validate(data,run=decl['run'],pid=pid,start_ticks=ticks,origin_ns=o,expected_sockets=expected,measurement_end_ns=o+duration)
    socket_record=json.loads(data,object_pairs_hook=object_pairs)['sockets'][0]
    require(hi+socket_record['registered_ns']-o<=observed['started_ns']<=observed['finished_ns']<=lo+socket_record['retired_ns']-o,'external snapshot outside registered lifetime')
    checked.update(mode='on',external_socket_scope='One independent live FD snapshot; remaining continuity from pinned in-process lifecycle, not continuous external observation.')
    return checked

class Session:
    def __init__(self,pins,config):
        self.pins=dict(pins);self.config=dict(config);self.captured={}
        identity(config['run']);declaration(config['run'],config['mode'])
        for key in ['build_manifest_sha256','client_binary_sha256','server_binary_sha256']:
            require(type(pins[key]) is str and re.fullmatch('[0-9a-f]{64}',pins[key]),'trusted digest pin')
        require(re.fullmatch('[0-9a-f]{40}',pins['runtime_source_sha']),'trusted runtime pin')
    def capture(self,role,root):
        from scripts.performance.linux_native_pair import verify_index,check_peer
        from scripts.performance.linux_native_finite_run import check_endpoint
        require(role in ('source','destination') and role not in self.captured,'duplicate/invalid role');root=Path(root)
        role_bound(root);endpoint=check_endpoint(root,role);outer=endpoint['index_sha256'];peer=root/'peer';env,_,_=check_peer(peer,role,self.pins['runtime_source_sha'],recv_errors_config=self.config)
        build=bounded(peer/'build-manifest.json',2**20);require(hashlib.sha256(build).hexdigest()==self.pins['build_manifest_sha256'],'pinned release manifest')
        for name,key in [('perf_rust_source','client_binary_sha256'),('wp8_interop_server','server_binary_sha256')]:require(env['binary_sha256'][name]==self.pins[key],'pinned release binary')
        require(verify_index(root)==outer,'role index changed during capture')
        self.captured[role]=dict(root=str(root.resolve()),index_sha256=outer)
        return dict(self.captured[role])
    def finish(self):
        from scripts.performance.linux_native_pair import verify_index,analyze_pair
        from scripts.performance.linux_native_finite_run import check_endpoint
        require(set(self.captured)=={'source','destination'},'both captured roles required')
        for role,value in self.captured.items():
            role_bound(Path(value['root']));require(check_endpoint(Path(value['root']),role)['index_sha256']==value['index_sha256'],'captured collection changed')
        source=Path(self.captured['source']['root'])/'peer';destination=Path(self.captured['destination']['root'])/'peer'
        pair=analyze_pair(source,destination,source_sha=self.pins['runtime_source_sha'],recv_errors_config=self.config)
        checked=admit_peer(source,'source',read(source,'environment.json'),self.config)
        for value in self.captured.values():require(verify_index(Path(value['root']))==value['index_sha256'],'collection changed during join')
        return dict(pair=pair,diagnostic=checked,collection_receipts=self.captured.copy(),trust_scope='Locally pinned release and complete captured SSH indexes; not remote attestation.',vm_qualified=False)

def role_bound(root):
    """Match the established per-role decompressed transfer cap before hashing."""
    require(not root.is_symlink(),'role root link');total=0;count=0
    for f in root.rglob('*'):
        require(not f.is_symlink(),'role entry link')
        if f.is_file():
            count+=1;total+=f.stat().st_size
            require(count<=2048 and total<=2*1024*1024,'role collection bound')
