"""Pure exact-workload, command and prior-identity checks; never launches a peer."""
import copy,hashlib,json,pathlib,sys
H=pathlib.Path(__file__).resolve().parent;label=sys.argv[1];C=H/'cells'/label
row=next(r for r in json.loads((H/'plan.json').read_bytes())['cells'] if r['label']==label)
sys.path.insert(0,str(C));from activate import activate
activate()
import plan
from scripts.performance import linux_native_finite_run as finite
from scripts.performance.recv_error_handoff import collector_config
from scripts.performance.recv_error_collection import Session,workload,overrides
from scripts.performance.linux_native_peer import native_command
c=plan.config();finite.validate_config(c)
assert c==json.loads((C/'finite-config.json').read_bytes())
assert c['streams']==row['streams'] and c['diagnostic_rate']==[row['rate'],1] and c['recv_errors_mode']=='off'
assert collector_config(c)==json.loads((C/'collector-config.json').read_bytes())
for role in plan.HOSTS:assert finite.endpoint_arguments(c,role)==json.loads((C/'endpoint-arguments.json').read_bytes())[role]
cell=dict(path='nbsr',cores=1,payload_bytes=1024,streams=row['streams'],outstanding=1,benchmark_seconds=20,origin_record=True,diagnostic_rate=[row['rate'],1])
workload(cell)
for field,value in [('streams',row['streams']+1),('diagnostic_rate',[row['rate']+1,1]),('outstanding',2),('payload_bytes',2048),('benchmark_seconds',300)]:
    wrong=copy.deepcopy(cell);wrong[field]=value
    try:workload(wrong)
    except ValueError:pass
    else:raise AssertionError('accepted wrong '+field)
for role in plan.HOSTS:
    command,_=native_command(cell,role,pathlib.PurePosixPath(c[role]['binaries']),pathlib.PurePosixPath(c[role]['authority']),pathlib.PurePosixPath(c[role]['output'])/'peer',bind=c[role]['bind'],endpoint='10.77.0.1:42000' if role=='source' else None,post_close_reports=True)
    if role=='source':
        assert command[command.index('--p2a-streams')+1]==str(row['streams'])
        assert command[command.index('--b5-rate-numerator')+1]==str(row['rate'])
    assert overrides(role,cell,c[role]['output'],dict(run=c['recv_errors_run'],mode='off'))=={}
wrong=copy.deepcopy(c);wrong['recv_errors_mode']='on'
try:finite.validate_config(wrong)
except ValueError:pass
else:raise AssertionError('diagnostic ON must remain forbidden in performance context')
s=Session(json.loads((C/'release-pins.json').read_bytes()),collector_config(c))
try:s.capture('source',H.parent/'throughput-streams01/cells/rate24k/run01-trial/coordinator/source')
except ValueError:pass
else:raise AssertionError('old run evidence accepted as fresh')
from qualification_gate import receipt,verified_sources
proof=receipt(H,label,row,c['recv_errors_run'])
prior=C/'LOCAL-QUALIFICATION.json'
if prior.exists():prior.rename(C/'LOCAL-QUALIFICATION-attempt01.json')
with prior.open('x') as f:json.dump(proof,f,indent=2)
verified_sources(H,label)
print(json.dumps({k:v for k,v in proof.items() if k not in ('source_pins','root_pins')}))
