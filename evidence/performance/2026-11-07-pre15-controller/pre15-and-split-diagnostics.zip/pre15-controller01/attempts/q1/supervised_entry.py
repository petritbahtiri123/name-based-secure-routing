"""Copied verbatim into an exclusive qualification slot by the reviewed runner."""
import pathlib,sys
SLOT=pathlib.Path(__file__).resolve().parent;H=SLOT.parent.parent
sys.path.insert(0,str(H))
if __name__=='__main__':
 if len(sys.argv)!=2 or SLOT.parent.name!='attempts' or SLOT.name not in ('q1','q2'):raise SystemExit('Use the reviewed qualification runner')
 from capture_admission import consume
 deadline=consume(SLOT,sys.argv[1])
 from qualify_pre15 import main
 main(SLOT.name,deadline,SLOT)
