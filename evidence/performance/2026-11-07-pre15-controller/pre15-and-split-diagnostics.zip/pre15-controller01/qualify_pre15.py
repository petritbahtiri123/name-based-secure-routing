"""One supervised PRE15 management session; no NBSR workload or replay."""
import hashlib,json,pathlib,sys,time,traceback
H=pathlib.Path(__file__).resolve().parent;C=H/'cells/controller';sys.path[:0]=[str(H/'src'),str(C)]
from activate import activate
activate()
import resource_boundary,session_adapter
from session_cost import assess
from qualification_cleanup import finish_cleanup
from capture_admission import validate_consumed
from qualification_gate import require_previous,DeadlineGate

def main(label,outer_deadline,slot):
 if label not in ('q1','q2') or pathlib.Path(slot)!=H/'attempts'/label:raise ValueError('qualification slot')
 validate_consumed(slot,outer_deadline)
 pins=json.loads((H/'qualification-inputs.json').read_bytes())
 if pins['status']!='READY_FOR_PRE15_MANAGEMENT':raise ValueError('review gate')
 for name,digest in pins['files'].items():
  if hashlib.sha256((H/name).read_bytes()).hexdigest()!=digest:raise ValueError('changed input: '+name)
 if label=='q2':require_previous(H)
 run='nbsr-cal-pre15-20261107-'+label
 if json.loads((slot/'attempt.json').read_bytes())['run']!=run:raise ValueError('claimed run mismatch')
 here=H/'management'/label;here.mkdir(parents=True,exist_ok=False)
 owner=None;error=None;cost=None;gate=DeadlineGate(outer_deadline)
 try:
  counts=gate.call(lambda:resource_boundary.check(starting=True))
  (here/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
  owner=gate.call(lambda:session_adapter.create(here,run))
  owner.guard=gate.wrap(owner.guard)
  gate.check();pre=session_adapter.pre(owner,here);gate.check();first=owner.sample()
  idle_end=time.monotonic()+10.05
  while time.monotonic()<idle_end:
   owner.guard()
   if owner.failure or owner.done.is_set():raise RuntimeError('session failed during idle')
   if time.monotonic()>=outer_deadline:raise TimeoutError('original outer budget')
   time.sleep(.02)
  last=owner.sample();post=owner.client().exchange('POST')
  session_adapter.save_calibration(here/'calibration-after.json',post)
  owner.close();session_adapter.internal_exchange.validate_pair(here)
  before=json.loads((owner.root/'pre-admission.json').read_bytes());after=json.loads((owner.root/'post-admission.json').read_bytes())
  terminal=owner.receipt()['last_sample']
  raw=dict(first=first,last=last,pre=pre,post=post,pre_admission=before,post_admission=after,terminal_sample=terminal)
  (here/'cost-inputs.json').write_text(json.dumps(raw,indent=2))
  cost=assess(first,last,pre,post,pre_seconds=before['completed']-before['started'],post_seconds=after['completed']-after['started'],terminal_peak_bytes=terminal['peak_job_memory_bytes'])
 except BaseException as e:error=dict(type=type(e).__name__,message=str(e),traceback=traceback.format_exc(limit=16))
 finally:
  cleanup=finish_cleanup(owner,here,run,outer_deadline)
  remote=cleanup['remote'];remote_valid=remote is not None and remote.get('status')=='REMOTE_CLOSED' and remote.get('execution_valid') is True
  if time.monotonic()>=outer_deadline and error is None:error=dict(type='TimeoutError',message='original outer deadline before final admission')
  status='PASS' if error is None and not cleanup['errors'] and cleanup['local_closed'] and remote_valid and cost is not None else 'STOP_INVALID_OR_UNQUALIFIED'
  result=dict(status=status,run=run,error=error,local_closed=cleanup['local_closed'],remote_closed=remote_valid,remote_cleanup_confirmed=remote is not None and remote.get('cleanup_confirmed') is True,cleanup_errors=cleanup['errors'],inspection_gate_refusal=cleanup['inspection_gate_refusal'],cost=cost,benchmark_workloads=0)
  (here/'qualification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
 if status!='PASS':raise RuntimeError('qualification stopped; no replacement session or benchmark')

if __name__=='__main__':raise SystemExit('Use the reviewed supervised qualification runner')
