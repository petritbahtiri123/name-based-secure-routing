import hashlib,json,os,pathlib,sys,time,uuid
T=pathlib.Path(__file__).resolve().parent;H=T/'pre15-controller01';C=H/'cells/controller';sys.path[:0]=[str(H),str(C)]
import bounded,resource_boundary
from capture_admission import process_identity
from qualification_gate import require_previous,complete
label=sys.argv[1]
if label not in ('q1','q2'):raise ValueError('two declared slots only')
pins=json.loads((H/'qualification-inputs.json').read_bytes())
if pins['status']!='READY_FOR_PRE15_MANAGEMENT':raise ValueError('qualification review gate')
for name,digest in pins['files'].items():
 if hashlib.sha256((H/name).read_bytes()).hexdigest()!=digest:raise ValueError('changed input: '+name)
if hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()!=pins['outer_runner_sha256']:raise ValueError('changed runner')
if label=='q2':require_previous(H)
slot=H/'attempts'/label;slot.mkdir(parents=True,exist_ok=False);(slot/'evidence').mkdir()
if (H/'management'/label).exists():raise ValueError('no replacement qualification')
run='nbsr-cal-pre15-20261107-'+label
(slot/'plan.json').write_text(json.dumps(dict(live=dict(run=run))))
(slot/'supervised_entry.py').write_bytes((H/'entry_template.py').read_bytes())
token=uuid.uuid4().hex;who=process_identity(os.getpid())
with (slot/'attempt.json').open('x') as f:json.dump(dict(run=run,token=token,parent_pid=os.getpid(),parent_created=who['created'],created=time.monotonic(),one_attempt=True,replacement=False),f)
counts=resource_boundary.check(starting=True);(C/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
print('PRE15_MANAGEMENT_QUALIFICATION_START '+label+'; no NBSR workload',flush=True)
bounded.run([sys.executable,'-u','-B',str(slot/'supervised_entry.py'),token],slot/'evidence/capture-command',60)
print(json.dumps(complete(H,label)),flush=True)
