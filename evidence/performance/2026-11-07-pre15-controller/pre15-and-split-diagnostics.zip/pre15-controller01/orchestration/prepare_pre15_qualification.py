import pathlib,json,shutil,hashlib
T=pathlib.Path(__file__).resolve().parent;H=T/'pre15-controller01';B=T/'pre-guard-boundaries01'
shutil.copyfile(B/'capture_admission.py',H/'capture_admission.py')
shutil.copyfile(B/'tests/test_capture_admission.py',H/'tests/test_capture_admission.py')
text=(B/'capture_pre.py').read_text();fn=text[text.index('def finish_cleanup('):text.index('\ndef main(')]
fn=fn.replace('planned diagnostic ends after PRE; no POST/workload','qualification ends; no workload')
(H/'qualification_cleanup.py').write_text('import json,pathlib,sys\nH=pathlib.Path(__file__).resolve().parent;sys.path[:0]=[str(H/"src"),str(H/"cells/controller")]\nimport session_adapter\n'+fn)
text=(B/'tests/test_capture_cleanup.py').read_text().replace("import_module('capture_pre')","import_module('qualification_cleanup')")
(H/'tests/test_capture_cleanup.py').write_text(text)
old=(H/'qualify_one.py').read_bytes();(H/'evidence/qualify-one-before.py').write_bytes(old)
progress=json.loads((H/'progress.json').read_bytes());progress.update(completed=['PRE-only boundary change RED/GREEN','67 affected tests passed'],active_task=2,tests=dict(budget_red='1 failure/4 errors among7; missing behavior',budget_green=7,cost_red='1 error among2 at new13s screen',all_green=67),split_candidate='NOT_QUALIFIED; sealed separately, no runtime integration')
(H/'progress.json').write_text(json.dumps(progress,indent=2));print('prepared inherited admission/cleanup regressions; no VM operation')
