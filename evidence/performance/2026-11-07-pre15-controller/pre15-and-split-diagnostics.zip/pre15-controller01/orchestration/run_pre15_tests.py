import pathlib,sys,json
T=pathlib.Path(__file__).resolve().parent;H=T/'pre15-controller01';C=H/'cells/controller';sys.path.insert(0,str(C))
import bounded,resource_boundary
label=sys.argv[1]
if label not in ('budget-red','budget-green','cost-red','all-green','review-red','final-tests','after-review'):raise ValueError('declared test invocation')
counts=resource_boundary.check(starting=True);(C/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
pattern='test_pre_budget.py' if label.startswith('budget') else 'test_*.py'
if label=='cost-red':pattern='test_pre_cost.py'
bounded.run([sys.executable,'-B','-m','unittest','discover','-s',str(H/'tests'),'-p',pattern,'-v'],H/'evidence'/(label+'-command'),40)
