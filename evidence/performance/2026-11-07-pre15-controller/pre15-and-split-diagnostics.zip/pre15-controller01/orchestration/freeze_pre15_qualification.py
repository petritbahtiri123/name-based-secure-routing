import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'pre15-controller01';C=H/'cells/controller'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (H/'qualification-inputs.json').exists() and not (H/'attempts').exists() and not (H/'management').exists()
log=(H/'evidence/after-review-command/stderr.log').read_text()
assert 'Ran 86 tests' in log and log.rstrip().endswith('OK')
sup=json.loads((H/'evidence/after-review-command/supervision.json').read_bytes())
assert sup['status']=='LOCAL_WORKER_COMPLETED' and not sup['owned_handles'] and sup['leader_reaped'] and sup['group_exit_observed'] and sup['drain_failure'] is None
for name in ['session_owner.py','session_client.py','session_broker.py','session_adapter.py','session_cost.py']:
 assert (H/'src'/name).read_bytes()==(C/name).read_bytes()
review=dict(status='READY_FOR_MANAGEMENT_QUALIFICATION_AFTER_AUTHOR_FIX_PASS',reviewer='GPT-6 Astra',initial_verdict='NOT_READY',critical=0,important=2,minor=0,
 fixes=[dict(issue='q2 allowed after child PASS before outer terminal result',resolution='Both outer and child require q1 terminal receipt; bound to request/run/pins and successful supervision, exit/reap/group/handle/drain fields.',tests='test_qualification_gates.QualificationGateTests: five cases'),dict(issue='resource scan could delay startup past original outer deadline',resolution='DeadlineGate wraps startup resource scans, owner creation and every owner guard before/after; explicit check before PRE. Cleanup remains independent.',tests='test_qualification_gates.StartupDeadlineTests: three cases, including actual unstarted owner after injected clock crossing')],
 verification='Eight new failures observed in review-red; all86 tests passed after one fix pass. No second reviewer verdict claimed.',
 declined_to_judge=['Actual VM admission, PRE/POST headroom and idle impact remain unmeasured until planned qualification.','Benchmark validity,production readiness and historical whole-controller/old16-reference equivalence are not established by local tests.'],
 rulings=['Keep empirical gates pending; no workload before both management sessions pass including terminal outer receipts.','Use the same qualified candidate for future32/16 cells; retained old16 remains descriptive context, not strict whole-controller equivalence.','Rejected directory-only split prototype remains sealed/unpromoted; no new file-lock or journal subsystem.'])
(H/'review-resolution.json').write_text(json.dumps(review,indent=2))
(H/'orchestration').mkdir()
for name in ['prepare_pre15_controller.py','implement_pre15_controller.py','run_pre15_tests.py','prepare_pre15_qualification.py','run_pre15_qualification.py','freeze_pre15_qualification.py']:
 (H/'orchestration'/name).write_bytes((T/name).read_bytes())
parent=json.loads((T/'pre-guard-boundaries01/parent-inputs.json').read_bytes())
selected={H/name for name in parent}
for root in [H/'src',H/'tests',H/'orchestration']:selected.update(root.glob('*.py'))
selected.update(H.glob('*.py'));selected.add(H/'plan.json');selected.add(H/'review-resolution.json')
files={p.relative_to(H).as_posix():sha(p) for p in sorted(selected)}
for p in selected:
 if p.suffix=='.py':compile(p.read_bytes(),str(p),'exec')
result=dict(status='READY_FOR_PRE15_MANAGEMENT',files=files,outer_runner_sha256=sha(T/'run_pre15_qualification.py'),local_tests=86,
 original_caps='Full fresh scans unchanged; PRE15-only approved, POST/CLOSE10 and78/88/90 unchanged.',max_sessions=2,replacements=0,workloads_allowed=False,
 qualification=json.loads((H/'plan.json').read_bytes())['qualification'],review='review-resolution.json')
(H/'qualification-inputs.json').write_text(json.dumps(result,indent=2))
progress=json.loads((H/'progress.json').read_bytes());progress.update(active_task=3,local_tests=86,review=review['status'],completed=['PRE-only budget and boundary regressions','full86-test suite','independent review and two RED/GREEN fixes'],qualification='READY_NOT_STARTED')
(H/'progress.json').write_text(json.dumps(progress,indent=2))
print(json.dumps(dict(status=result['status'],pinned_inputs=len(files),manifest_sha256=sha(H/'qualification-inputs.json'),local_tests=86)))
