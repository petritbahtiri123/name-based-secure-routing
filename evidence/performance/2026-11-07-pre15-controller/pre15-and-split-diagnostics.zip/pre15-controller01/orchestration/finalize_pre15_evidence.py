import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'pre15-controller01';Q=H/'management/q1'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins=read(H/'qualification-inputs.json')
assert sha(H/'qualification-inputs.json')=='f3f61a24d8fb134d66a20f7fc72ce5e7ce4123a946d71467523d2c8352c1e571'
for name,digest in pins['files'].items():assert sha(H/name)==digest,name
q=read(Q/'qualification.json');raw=read(Q/'cost-inputs.json');a,b=raw['first'],raw['last'];pre,post=raw['pre'],raw['post']
local_ns=b['before_ns']-a['after_ns'];remote_ns=post['before']['monotonic_ns']-pre['after']['monotonic_ns']
assert q['status']=='STOP_INVALID_OR_UNQUALIFIED' and q['error']['message']=='added idle CPU exceeds1% onecore'
cost=dict(local_idle_seconds=local_ns/1e9,remote_idle_seconds=remote_ns/1e9,
 job_cpu_percent=(b['cpu_100ns']-a['cpu_100ns'])*100/local_ns*100,
 monitor_cpu_percent=(b['monitor_cpu_ns']-a['monitor_cpu_ns'])/local_ns*100,
 remote_cpu_percent=(post['before']['cpu_ns']-pre['after']['cpu_ns'])/remote_ns*100,
 job_cpu_ns=(b['cpu_100ns']-a['cpu_100ns'])*100,monitor_cpu_ns=b['monitor_cpu_ns']-a['monitor_cpu_ns'],remote_cpu_ns=post['before']['cpu_ns']-pre['after']['cpu_ns'],
 job_peak_bytes=max(a['peak_job_memory_bytes'],b['peak_job_memory_bytes'],raw['terminal_sample']['peak_job_memory_bytes']),
 remote_peak_bytes=max(pre['after']['peak_rss_bytes'],post['before']['peak_rss_bytes'],post['after']['peak_rss_bytes']),
 pre_seconds=raw['pre_admission']['completed']-raw['pre_admission']['started'],post_seconds=raw['post_admission']['completed']-raw['post_admission']['started'])
cost['close_seconds']=read(Q/'calibration-session/close-admission.json')['completed']-read(Q/'calibration-session/close-admission.json')['started']
outer=read(H/'attempts/q1/evidence/capture-command/supervision.json');owner=read(Q/'calibration-session/ownership-final.json');remote=read(Q/'calibration-remote-observation.json')
assert q['local_closed'] and q['remote_closed'] and q['remote_cleanup_confirmed'] and not q['cleanup_errors']
assert remote['status']=='REMOTE_CLOSED' and remote['execution_valid'] and remote['cleanup_confirmed'] and not remote['errors']
assert outer['status']=='INVALID_PARTIAL' and outer['exit_code']==1 and outer['reason']=='worker_exit'
for v in [outer,owner,read(Q/'calibration-remote-absence/supervision.json')]:
 assert not v['owned_handles'] and v['leader_reaped'] and v['group_exit_observed'] and v['drain_failure'] is None
assert not (H/'attempts/q2').exists() and not (H/'management/q2').exists() and not (Q/'outer-completion.json').exists()
assert not (H/'cells/controller/run01-trial').exists() and (H/'cells/controller/LIVE-DISABLED.json').is_file()
commands={}
for p in sorted((H/'evidence').glob('*-command/supervision.json')):
 v=read(p);assert not v['owned_handles'] and v['leader_reaped'] and v['group_exit_observed'] and v['drain_failure'] is None
 commands[p.relative_to(H).as_posix()]={k:v[k] for k in ['status','exit_code','elapsed_seconds','owned_handles','leader_reaped','group_exit_observed']}
summary=dict(status='PRE15_TIME_GATES_PASSED_IDLE_CPU_QUALIFICATION_FAILED',promoted=False,benchmark_workloads=0,
 attempted_management_sessions=1,max_sessions=2,q2='NOT_RUN_AFTER_STOP',replacements=0,
 local_tests=86,review=read(H/'review-resolution.json'),qualification=q,cost=cost,
 time_screens=dict(pre_hard=15,pre_screen=13,post_hard=10,post_screen=5,close_hard=10,passed_in_this_observation=True),
 unchanged=read(H/'source-equivalence.json'),calibration=read(Q/'CALIBRATION.json'),
 cleanup=dict(local_session=owner,outer=outer,remote=remote['observations'],remote_status=remote['status'],confirmed=True),
 commands=commands,qualification_inputs_sha256=sha(H/'qualification-inputs.json'),pinned_inputs=len(pins['files']),
 history=read(T/'split-resource-guard01/deadline-provenance.json'),
 rejected_split_guard=dict(path='split-resource-guard01',status='NOT_QUALIFIED_ABANDONED_DIRECTORY_LEASE_PATH',index_sha256=sha(T/'split-resource-guard01/final-evidence-index.json')),
 interpretation='PRE15 is a justified previously used controller sub-budget, not a protocol timer. This one observation passes time screens but fails the preregistered local idle CPU screen. It is not a benchmark or whole-controller equivalence result.',
 next_hypothesis='The existing20ms polling loops in the local Job monitor and broker request wait may contribute to added localCPU. Aggregate Job CPU does not identify which child consumed it; this is a hypothesis, not a proved cause.',
 next_discriminator='A separately declared finite local paired polling-cost/response/cleanup test could evaluate a smaller polling rate while preserving all absolute deadlines and original1% threshold. Do not rerun q1/q2 or widen CPU thresholds; no VM workload until a new qualified candidate exists.',
 branch='codex/nbsr-v3-wp0-wp1',base_commit='bd14667e70983efeb92a9df942fad5bc6b4db774')
(H/'summary.json').write_text(json.dumps(summary,indent=2))
p=read(H/'progress.json');p.update(status=summary['status'],active_task=None,qualification='STOPPED_AFTER_Q1_CPU_SCREEN_FAILURE',completed=['PRE-only implementation and86 tests','independent review and two author fixes','one bounded management qualification','verified local/remote cleanup'],not_run=['q2','benchmark32/16','protocol quick wins'],next=summary['next_discriminator']);(H/'progress.json').write_text(json.dumps(p,indent=2))
(H/'orchestration/finalize_pre15_evidence.py').write_bytes(pathlib.Path(__file__).read_bytes())
files={p.relative_to(H).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(H.rglob('*')) if p.is_file()}
with (H/'final-evidence-index.json').open('x',encoding='utf-8') as f:json.dump(dict(files=files,total_bytes=sum(v['bytes'] for v in files.values())),f,indent=2)
print(json.dumps(dict(status=summary['status'],cost=cost,indexed_files=len(files),index_sha256=sha(H/'final-evidence-index.json'))))
