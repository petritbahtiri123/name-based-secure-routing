import pathlib,json,hashlib
T=pathlib.Path(__file__).resolve().parent;H=T/'pre15-controller01';S=H/'src';C=H/'cells/controller';changes=[]
def edit(name,pairs):
 p=S/name;before=p.read_bytes();text=before.decode()
 for old,new in pairs:
  assert text.count(old)==1,(name,old,text.count(old));text=text.replace(old,new)
 compile(text,str(p),'exec');p.write_bytes(text.encode());(C/name).write_bytes(text.encode())
 changes.append(dict(path=name,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
edit('session_owner.py',[
 ('request_seconds=10,transport=', 'request_seconds=10,pre_seconds=None,transport='),
 ('        self.root=pathlib.Path(root);', '        pre_seconds=request_seconds if pre_seconds is None else pre_seconds\n        self.root=pathlib.Path(root);'),
 ('not 0<request_seconds<=10):','not 0<request_seconds<=10\n                or type(pre_seconds) not in (int,float) or not math.isfinite(pre_seconds) or not 0<pre_seconds<=15):'),
 ('self.lifetime=lifetime;self.seconds=request_seconds;', 'self.lifetime=lifetime;self.seconds=request_seconds;self.pre_seconds=pre_seconds;'),
 ('request_seconds=self.seconds,','request_seconds=self.seconds,pre_seconds=self.pre_seconds,'),
 ('self.started+self.seconds:raise TimeoutError', 'self.started+self.pre_seconds:raise TimeoutError'),
 ('deadline=self.started+self.seconds)', 'deadline=self.started+self.pre_seconds)')])
edit('session_client.py',[
 ("self.seconds=self.config['request_seconds']", "self.seconds=self.config['request_seconds'];self.pre_seconds=self.config.get('pre_seconds',self.seconds)"),
 ('(self.started,self.end,self.seconds))', '(self.started,self.end,self.seconds,self.pre_seconds))'),
 ('not 0<self.seconds<=10:', 'not 0<self.seconds<=10 or not 0<self.pre_seconds<=15:'),
 ("self.wait(1,'PRE',self.started+self.seconds)", "self.wait(1,'PRE',self.started+self.pre_seconds)")])
edit('session_broker.py',[
 ("'deadline','request_seconds','transport'", "'deadline','request_seconds','pre_seconds','transport'"),
 ("seconds=c['request_seconds']", "seconds=c['request_seconds'];pre_seconds=c['pre_seconds']"),
 ('(start,deadline,seconds))', '(start,deadline,seconds,pre_seconds))'),
 ('not 0<seconds<=10:', 'not 0<seconds<=10 or not 0<pre_seconds<=15:'),
 ('check(start+seconds)', 'check(start+pre_seconds)'),
 ("receive(start+seconds,0,'READY')", "receive(start+pre_seconds,0,'READY')"),
 ('start+seconds if seq==1', 'start+pre_seconds if seq==1')])
edit('session_adapter.py',[("guard=guard_for(here),", "guard=guard_for(here),pre_seconds=15,")])
p=C/'calibration_sequence.py';before=p.read_bytes();text=before.decode();assert text.count('<=10:raise TimeoutError')==1;text=text.replace('<=10:raise TimeoutError','<=15:raise TimeoutError');p.write_bytes(text.encode())
changes.append(dict(path='calibration_sequence.py',before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(H/'budget-changes.json').write_text(json.dumps(changes,indent=2));print(json.dumps(changes))
