import pathlib,json,hashlib,shutil,difflib
T=pathlib.Path(__file__).resolve().parent;S=T/'split-resource-guard01';H=T/'pre15-controller01';B=T/'temporary-ssh-session01'
H.mkdir(exist_ok=False)
pins=json.loads((T/'pre-guard-boundaries01/parent-inputs.json').read_bytes())
for name,digest in pins.items():
 data=(T/'pre-guard-boundaries01'/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
 p=H/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for name in ['src','tests']:shutil.copytree(B/name,H/name,ignore=shutil.ignore_patterns('__pycache__'))
(H/'evidence').mkdir();shutil.copyfile(B/'qualify_one.py',H/'qualify_one.py')
provenance=json.loads((S/'deadline-provenance.json').read_bytes())
old=pathlib.Path(provenance['inherited_window10']['path']).read_text();current=pathlib.Path(provenance['current_window10']['path']).read_text()
provenance['current_matches_inherited_normalized_text']=old==current
provenance['raw_difference_explanation']='Text equals inherited source; raw bytes differ in line ending normalization.' if old==current else list(difflib.unified_diff(old.splitlines(),current.splitlines()))
(S/'deadline-provenance.json').write_text(json.dumps(provenance,indent=2))
split_summary=dict(status='NOT_QUALIFIED_ABANDONED_DIRECTORY_LEASE_PATH',vm_attempts=0,benchmark_workloads=0,
 last_suite=dict(total=18,passed=15,failures=2,errors=1,log='evidence/split-green2-command/stderr.log'),
 blocker='Under the actual unsandboxed fixture, two open-file size-growth tests did not invalidate a directory R lease. Holding child directory handles also prevented ancestor rename. Directory-only leases are insufficient for the proposed freshness/noninterference contract.',
 limitation='Earlier six sandboxed passes are environment-limited observations and do not establish the missing open-writer guarantee. No real history tree was leased, no runtime/source guard was replaced.',
 local_fixes='Bottom-up acquisition and DirEntry.inode avoid self-invalidation by child lstat/open; failure tests now assert startup actually occurred. These do not fix the open-writer gap.',
 decision='Do not promote or add a larger file-lock/journal subsystem. Follow latest authorization to assess historical PRE-only15s with unchanged full accounting.',
 web_sources=['https://learn.microsoft.com/en-us/windows/win32/api/winioctl/ni-winioctl-fsctl_request_oplock','https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-readdirectorychangesw'])
(S/'summary.json').write_text(json.dumps(split_summary,indent=2))
progress=json.loads((S/'progress.json').read_bytes());progress.update(status=split_summary['status'],active_task=None,completed=['bounded capability investigation'],uncompleted=['qualified split guard','performance screen','VM qualification','benchmark'],reason=split_summary['blocker']);(S/'progress.json').write_text(json.dumps(progress,indent=2))
files={p.relative_to(S).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(S.rglob('*')) if p.is_file()}
(S/'final-evidence-index.json').write_text(json.dumps(dict(files=files),indent=2))
(H/'plan.json').write_text(json.dumps(dict(
 status='AUTHORIZED_PRE_ONLY_BUDGET_ASSESSMENT',base_commit='bd14667e70983efeb92a9df942fad5bc6b4db774',
 authorization='Petriti permits raising the controller limit if justified and preserving workload/results comparability. Historical PRE15s exists; no automatic equivalence or late-result rehabilitation.',
 changes=['Separate initial PRE budget15s from later POST/CLOSE request10s in owner,broker,client; preserve default fixture behavior.',
 'Use historical Window.admit_pre15s, unchanged phase anchor+78, calibration anchor+88 and actual span<=90s.',
 'Keep full fresh resource accounting, same VM limits, same source/runtime, same three clock probes, same workload and cleanup ownership. No split-guard promotion.'],
 tasks=['Boundary regressions RED/GREEN, real owned scaled PRE/POST distinction, full affected58-test suite','Fresh independent whole-candidate review and one fix pass','At most2 management sessions, stop on failure; PRE<=13s promotion screen leaves2s reserve, POST<=5s unchanged; original hard PRE15/POST10','Only after all gates, fresh32/16 comparison at28kops/s and20s each, max2, same prior workload limits','Preserve evidence and existing branch; canonical note only'],
 qualification=dict(pre_hard_seconds=15,pre_promotion_seconds=13,post_hard_seconds=10,post_promotion_seconds=5,session_seconds=88,work_phase_seconds=78,clock_envelope_seconds=90,remote_seconds=70,remote_kill_grace_seconds=2,max_sessions=2,idle_seconds=10,cpu_fraction_max=.01,job_memory_mib_max=128,remote_memory_mib_max=32),
 comparability='PRE startup acceptance changes; endpoint20s workload and measured quantities remain. Additional startup consumes existing78/88s slack; all remaining-budget and clock-span gates still decide validity. Persistent SSH impact must pass finite qualification and remains a comparison limitation.',
 review_focus=['Separate PRE from POST/CLOSE with no default widening','No reanchoring of78/88/90 or loss of cleanup reserve','Broker/owner/client configuration consistency and late-check rejection','One-attempt outer ownership and failure-independent cleanup','Do not claim rejected split guard or historical invalid runs passed']),indent=2))
(H/'progress.json').write_text(json.dumps(dict(plan='pre15-controller01/plan.json',active_task=1,completed=[],rulings=[
 'Latest explicit approval permits a justified PRE-only change. Preserve the failed split prototype and its failed tests; no further lease mechanism is introduced.',
 'Retain all evidence, use existing branch and JSON ledger; no new branch, broad tests or duplicate narrative.',
 'Predeclare PRE<=13s promotion screen before measurements, leaving2s inside historical15s hard limit. POST<=5s screen and all idle-cost bounds stay unchanged.'
]),indent=2))
print(json.dumps(dict(prepared=str(H),split_status=split_summary['status'],split_index_sha256=hashlib.sha256((S/'final-evidence-index.json').read_bytes()).hexdigest(),historical_text_matches=old==current)))
