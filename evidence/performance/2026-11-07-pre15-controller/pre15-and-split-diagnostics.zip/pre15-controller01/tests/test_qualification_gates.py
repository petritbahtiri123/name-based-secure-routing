import importlib.util,json,pathlib,sys,tempfile,unittest
H=pathlib.Path(__file__).resolve().parents[1];sys.path[:0]=[str(H),str(H/'src'),str(H/'cells/controller')]
spec=importlib.util.find_spec('qualification_gate')
if spec is not None:
 from qualification_gate import require_previous,complete,DeadlineGate
else:require_previous=complete=DeadlineGate=None

class QualificationGateTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(require_previous,'terminal outer qualification gate missing')
  self.root=pathlib.Path(tempfile.mkdtemp(prefix='terminal-',dir=H/'evidence'))
  self.slot=self.root/'attempts/q1';self.out=self.slot/'evidence/capture-command';self.here=self.root/'management/q1'
  self.out.mkdir(parents=True);self.here.mkdir(parents=True)
  self.run='nbsr-cal-pre15-20261107-q1';self.token='a'*32
  self.write(self.root/'qualification-inputs.json',{'fixture':'pins'})
  self.write(self.slot/'attempt.json',dict(run=self.run,token=self.token))
  self.write(self.out/'request.json',dict(started=100,output=str(self.out.resolve()),argv=[sys.executable,'-u','-B',str(self.slot/'supervised_entry.py'),self.token]))
  self.write(self.here/'qualification.json',dict(status='PASS',run=self.run,local_closed=True,remote_closed=True,remote_cleanup_confirmed=True,cleanup_errors=[],error=None))
  self.sup=dict(status='LOCAL_WORKER_COMPLETED',exit_code=0,owned_handles=False,leader_reaped=True,group_exit_observed=True,drain_failure=None,errors=[],elapsed_seconds=20)
  self.write(self.out/'supervision.json',self.sup)
 def write(self,p,v):p.write_text(json.dumps(v))
 def test_child_pass_without_terminal_outer_receipt_cannot_advance(self):
  with self.assertRaises((ValueError,FileNotFoundError)):require_previous(self.root)
 def test_child_pass_outer_failure_never_creates_completion(self):
  self.sup['status']='INVALID_PARTIAL';self.write(self.out/'supervision.json',self.sup)
  with self.assertRaises(ValueError):complete(self.root,'q1',clock=lambda:125)
  self.assertFalse((self.here/'outer-completion.json').exists())
 def test_terminal_bound_to_request_and_receipts(self):
  complete(self.root,'q1',clock=lambda:125);require_previous(self.root)
  self.sup['owned_handles']=True;self.write(self.out/'supervision.json',self.sup)
  with self.assertRaises(ValueError):require_previous(self.root)
 def test_completion_at_original_outer_deadline_rejected(self):
  with self.assertRaises(TimeoutError):complete(self.root,'q1',clock=lambda:160)
 def test_uncertain_reap_drain_or_remote_cleanup_cannot_advance(self):
  for field,value in [('leader_reaped',False),('group_exit_observed',False),('drain_failure','TimeoutError')]:
   with self.subTest(field=field):
    original=self.sup[field];self.sup[field]=value;self.write(self.out/'supervision.json',self.sup)
    with self.assertRaises(ValueError):complete(self.root,'q1',clock=lambda:125)
    self.sup[field]=original

class StartupDeadlineTests(unittest.TestCase):
 def setUp(self):self.assertIsNotNone(DeadlineGate,'outer startup gate missing')
 def test_scan_crossing_original_deadline_cannot_launch_owned_session(self):
  from activate import activate
  activate()
  from session_owner import OwnedSession
  now=[0];gate=DeadlineGate(1,clock=lambda:now[0])
  def scan():now[0]=1
  root=pathlib.Path(tempfile.mkdtemp(prefix='late-start-',dir=H/'evidence'))/'session'
  owner=OwnedSession(root,'fixture-late-start',[sys.executable,'-B','-c','raise SystemExit(99)'],guard=gate.wrap(scan),lifetime=8,request_seconds=2,pre_seconds=3,transport='local-fixture')
  with self.assertRaises(RuntimeError):owner.open_pre()
  self.assertTrue(owner.wait_closed(2));self.assertIsNone(owner.owner.process);self.assertIsNone(owner.owner.job)
 def test_expired_gate_does_not_call_startup_action(self):
  calls=[];gate=DeadlineGate(1,clock=lambda:1)
  with self.assertRaises(TimeoutError):gate.call(lambda:calls.append('started'))
  self.assertEqual(calls,[])
 def test_after_scan_error_does_not_reset_original_deadline(self):
  now=[0];gate=DeadlineGate(1,clock=lambda:now[0])
  def scan():now[0]=1.01;return 'late'
  with self.assertRaises(TimeoutError):gate.call(scan)
  with self.assertRaises(TimeoutError):gate.check()

if __name__=='__main__':unittest.main()
