import pathlib,sys,time
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
from session_wire import RequestState,encode
run=sys.argv[1];state=RequestState(run)
def send(seq,op,payload):sys.stdout.buffer.write(encode(dict(v=1,run=run,seq=seq,op=op,payload=payload)));sys.stdout.buffer.flush()
time.sleep(.7);send(0,'READY',{})
for seq in (1,2,3):
 wire=sys.stdin.buffer.readline(8193)
 if not wire:raise SystemExit(2)
 op=state.consume(wire)
 if op=='POST':time.sleep(.7)
 send(seq,op,dict(probe_count=seq))
