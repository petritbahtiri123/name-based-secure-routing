import json,pathlib,sys,tempfile,unittest
H=pathlib.Path(__file__).resolve().parents[1];sys.path[:0]=[str(H/'src'),str(H/'cells/controller')]
from session_client import Client
from session_files import publish
from session_wire import encode
from calibration_sequence import Window

class PreBudgetTests(unittest.TestCase):
 def setUp(self):
  self.root=pathlib.Path(tempfile.mkdtemp(prefix='pre-budget-',dir=H/'evidence'));self.now=10.5
  (self.root/'config.json').write_text(json.dumps(dict(run='fixture-budget',started=0,deadline=88,request_seconds=10,pre_seconds=15)))
  for seq,op in ((0,'READY'),(1,'PRE'),(2,'POST')):
   publish(self.root,'reply-'+str(seq),encode(dict(v=1,run='fixture-budget',seq=seq,op=op,payload={'observed':op})))
 def client(self,guard=lambda:None):return Client(self.root,'fixture-budget',guard=guard,clock=lambda:self.now)
 def test_pre_after10_before15_is_admitted(self):
  self.assertEqual(self.client().pre(),{'observed':'PRE'})
  self.assertFalse((self.root/'cancel').exists())
 def test_guard_may_finish_at14999_but_not15(self):
  def guard():self.now=14.999
  self.assertEqual(self.client(guard).pre(),{'observed':'PRE'})
  self.now=15
  with self.assertRaises(TimeoutError):self.client().pre()
 def test_post_still_stops_at10_from_post_anchor(self):
  self.now=20
  def guard():self.now=30
  with self.assertRaises(TimeoutError):self.client(guard).exchange('POST')
  self.assertFalse((self.root/'request-2.ready').exists())
 def test_absolute_end_remains88(self):
  self.now=87
  with self.assertRaises(TimeoutError):self.client().exchange('POST')
  self.assertFalse((self.root/'request-2.ready').exists())
 def test_historical_window_keeps_fixed_work_and_finish_bounds(self):
  clock=[14.9];w=Window(0,clock=lambda:clock[0]);w.admit_pre()
  clock[0]=77.9;self.assertEqual(w.post_budget(),10)
  clock[0]=78
  with self.assertRaises(TimeoutError):w.check_work()
  clock[0]=88
  with self.assertRaises(TimeoutError):w.finish()
 def test_pre_limit_does_not_accept_invalid_or_above15(self):
  for limit in (0,-1,15.001,float('inf'),True):
   c=json.loads((self.root/'config.json').read_text());c['pre_seconds']=limit
   (self.root/'config.json').write_text(json.dumps(c))
   with self.assertRaises(ValueError):self.client()

class RealBudgetTests(unittest.TestCase):
 def test_scaled_longer_pre_does_not_widen_post_and_job_closes(self):
  from activate import activate
  activate()
  from session_owner import OwnedSession
  root=pathlib.Path(tempfile.mkdtemp(prefix='budget-owned-',dir=H/'evidence'))/'session'
  command=[sys.executable,'-B',str(H/'tests/budget_fixture.py'),'fixture-budget-owned']
  owner=OwnedSession(root,'fixture-budget-owned',command,guard=lambda:None,lifetime=8,request_seconds=.5,pre_seconds=2,transport='local-fixture')
  try:
   self.assertEqual(owner.open_pre()['probe_count'],1)
   with self.assertRaises((TimeoutError,RuntimeError)):owner.client().exchange('POST')
  finally:
   owner.abort('finite fixture end');self.assertTrue(owner.wait_closed(2))
  r=owner.receipt();self.assertFalse(r['owned_handles']);self.assertTrue(r['leader_reaped']);self.assertTrue(r['group_exit_observed'])

if __name__=='__main__':unittest.main()
