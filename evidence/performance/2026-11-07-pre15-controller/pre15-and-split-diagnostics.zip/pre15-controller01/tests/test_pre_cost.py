import pathlib,sys,unittest
H=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(H/'src'))
from session_cost import assess
class PreCostTests(unittest.TestCase):
 def sample(self,pre_seconds,post_seconds=5):
  a=dict(before_ns=0,after_ns=1000,cpu_100ns=0,monitor_cpu_ns=0,peak_job_memory_bytes=10)
  b=dict(before_ns=10_000_001_000,after_ns=10_000_002_000,cpu_100ns=10000,monitor_cpu_ns=10000,peak_job_memory_bytes=10)
  pre=dict(after=dict(monotonic_ns=0,cpu_ns=0,peak_rss_bytes=10))
  post=dict(before=dict(monotonic_ns=12_000_000_000,cpu_ns=10000,peak_rss_bytes=10))
  return assess(a,b,pre,post,pre_seconds=pre_seconds,post_seconds=post_seconds,terminal_peak_bytes=10)
 def test_pre13_retains_two_second_reserve_inside15(self):
  self.assertEqual(self.sample(13)['status'],'PASS_FINITE_IDLE_SCREEN')
  with self.assertRaises(ValueError):self.sample(13.001)
 def test_post_reserve_remains_five_seconds(self):
  with self.assertRaises(ValueError):self.sample(12,5.001)
if __name__=='__main__':unittest.main()
