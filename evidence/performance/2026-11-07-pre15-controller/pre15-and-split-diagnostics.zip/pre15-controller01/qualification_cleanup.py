import json,pathlib,sys
H=pathlib.Path(__file__).resolve().parent;sys.path[:0]=[str(H/"src"),str(H/"cells/controller")]
import session_adapter
def finish_cleanup(owner,here,run,deadline,*,verify=session_adapter.verify_remote):
    result=dict(local_closed=False,remote=None,errors=[],inspection_gate_refusal=None)
    def error(stage,e):result['errors'].append(dict(stage=stage,type=type(e).__name__,message=str(e)[:256]))
    if owner is None:return result
    try:owner.abort('qualification ends; no workload')
    except BaseException as e:error('abort',e)
    try:result['local_closed']=owner.wait_closed(2)
    except BaseException as e:error('wait_closed',e)
    if owner.started is not None:
        try:result['remote']=verify(here,run,min(owner.deadline,deadline))
        except BaseException as e:
            result['inspection_gate_refusal']=dict(type=type(e).__name__,message=str(e)[:256])
            path=here/'calibration-remote-observation.json'
            if isinstance(e,ValueError) and str(e)=='remote calibration cleanup incomplete' and path.exists():
                try:
                    value=json.loads(path.read_bytes());sup=json.loads((here/'calibration-remote-absence/supervision.json').read_bytes())
                    if (value.get('run')==run and value.get('status')=='REMOTE_FAILED_CLEANUP_CONFIRMED'
                            and value.get('cleanup_confirmed') is True and value.get('execution_valid') is False
                            and not value.get('errors') and sup['status']=='LOCAL_WORKER_COMPLETED'
                            and not sup['owned_handles'] and sup['leader_reaped'] and sup['group_exit_observed']):result['remote']=value
                    else:error('remote_receipt_gate',ValueError('cleanup not independently confirmed'))
                except BaseException as parse_error:error('remote_receipt_parse',parse_error)
            else:error('remote_inspection',e)
    return result
