"""Qualification advancement requires terminal outer ownership, not child PASS."""
import hashlib,json,math,pathlib,sys,time
from capture_admission import read

def finite(value):return type(value) in (int,float) and math.isfinite(value)
def records(root,label):
 if label not in ('q1','q2'):raise ValueError('fixed qualification label')
 root=pathlib.Path(root);slot=root/'attempts'/label;out=slot/'evidence/capture-command';here=root/'management'/label
 paths=dict(claim=slot/'attempt.json',request=out/'request.json',qualification=here/'qualification.json',supervision=out/'supervision.json',pins=root/'qualification-inputs.json')
 values={k:read(p) for k,p in paths.items()};claim=values['claim'];request=values['request'];q=values['qualification'];s=values['supervision']
 run='nbsr-cal-pre15-20261107-'+label
 if claim['run']!=run or q['run']!=run:raise ValueError('qualification identity')
 if request['output']!=str(out.resolve()) or request['argv']!=[sys.executable,'-u','-B',str(slot/'supervised_entry.py'),claim['token']]:raise ValueError('outer request identity')
 if q.get('status')!='PASS' or q.get('error') is not None or q.get('cleanup_errors') or any(q.get(k) is not True for k in ('local_closed','remote_closed','remote_cleanup_confirmed')):raise ValueError('inner qualification not complete')
 if (s.get('status')!='LOCAL_WORKER_COMPLETED' or type(s.get('exit_code')) is not int or s['exit_code']!=0
     or s.get('owned_handles') is not False or s.get('leader_reaped') is not True or s.get('group_exit_observed') is not True
     or s.get('drain_failure') is not None or s.get('errors')
     or not finite(s.get('elapsed_seconds')) or not 0<=s['elapsed_seconds']<60):raise ValueError('outer ownership not complete')
 if not finite(request.get('started')):raise ValueError('outer anchor')
 digests={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()}
 return here,run,request['started'],digests

def complete(root,label,*,clock=time.monotonic):
 here,run,started,digests=records(root,label);now=clock()
 if not finite(now) or not started<=now<started+60:raise TimeoutError('original outer completion deadline')
 value=dict(status='PASS_OUTER_COMPLETE',run=run,started=started,completed=now,sha256=digests)
 with (here/'outer-completion.json').open('x') as f:json.dump(value,f,indent=2)
 return value

def require_previous(root):
 here,run,started,digests=records(root,'q1');value=read(here/'outer-completion.json')
 if (value.get('status')!='PASS_OUTER_COMPLETE' or value.get('run')!=run or value.get('started')!=started
     or value.get('sha256')!=digests or not finite(value.get('completed')) or not started<=value['completed']<started+60):raise ValueError('q1 terminal receipt mismatch')
 return value

class DeadlineGate:
 def __init__(self,deadline,*,clock=time.monotonic):
  if not finite(deadline):raise ValueError('finite original outer deadline')
  self.deadline=deadline;self.clock=clock;self.previous=None;self.failure=None
 def check(self):
  if self.failure:raise TimeoutError(self.failure)
  now=self.clock()
  if not finite(now) or self.previous is not None and now<self.previous:
   self.failure='outer clock uncertainty';raise ValueError(self.failure)
  self.previous=now
  if now>=self.deadline:self.failure='original outer deadline';raise TimeoutError(self.failure)
 def call(self,fn):
  self.check();value=fn();self.check();return value
 def wrap(self,fn):return lambda:self.call(fn)
