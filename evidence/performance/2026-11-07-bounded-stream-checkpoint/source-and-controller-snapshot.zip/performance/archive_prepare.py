"""Pinned public staging bundle; no workload, TLS, or deadline changes."""
import pathlib,json,hashlib,zipfile

def prepare(*,resume=False,tag=""):
 assert tag in ("","p2")
 import prepare_remote as remote
 import plan
 here=remote.HERE;label=here.name;root=here.parents[1]
 _,_,pins=remote.sealed_inputs()
 bundles=root/'bundles';bundles.mkdir(exist_ok=True);archive=bundles/(label+('-'+tag if tag else '')+'.zip')
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for name,h in sorted(pins.items()):
   data=(here/name).read_bytes();assert hashlib.sha256(data).hexdigest()==h
   z.writestr(name,data)
 assert archive.stat().st_size<=4*1024**2
 with zipfile.ZipFile(archive) as z:assert sum(i.file_size for i in z.infolist())<=8*1024**2
 bundle_hash=hashlib.sha256(archive.read_bytes()).hexdigest()
 remote_archive=plan.ROOT+'/controlbundle-'+plan.RUN+('-'+tag if tag else '')+'.zip'
 prepared=[]
 try:
  for role in plan.HOSTS:
   manifest=json.loads((here/'release-build-manifest.json').read_bytes())
   code='''import pathlib,os,shutil,hashlib,json
base=pathlib.Path(BASE);q=pathlib.Path(CONTROL);bundle=pathlib.Path(ARCHIVE)
assert os.getuid()==os.getgid()==1001 and base.resolve(strict=True)==base and base.stat().st_uid==1001
assert shutil.disk_usage(base).free>=10*1024**3+256*1024**2 and shutil.disk_usage('/run').free>=32*1024**2
assert not os.path.lexists(bundle)
assert not list(pathlib.Path('/sys/fs/cgroup/system.slice').glob('nbsr*')) and not list(pathlib.Path('/run').glob('nbsr*'))
assert not (base/'evidence'/RUN_OUTPUT).exists() and not (base/'evidence'/SYSTEM_OUTPUT).exists()
b=pathlib.Path(BINARIES);assert all(not (b/n).is_symlink() and hashlib.sha256((b/n).read_bytes()).hexdigest()==h for n,h in HASHES.items())
if RESUME:
 assert q.resolve(strict=True)==q and q.stat().st_uid==1001 and (q/'overlay').is_dir() and not (q/'overlay').is_symlink()
 for f in q.rglob('*'):
  assert not f.is_symlink()
  if f.is_file():assert f.relative_to(q).as_posix() in PINS and f.stat().st_uid==1001 and hashlib.sha256(f.read_bytes()).hexdigest()==PINS[f.relative_to(q).as_posix()]
else:q.mkdir(mode=0o700,exist_ok=False);(q/'overlay').mkdir(mode=0o700)
print(json.dumps(dict(control=str(q),resume=RESUME)))
'''
   suffix=plan.RUN.removeprefix('nbsr-sphere-')
   values=dict(BASE=plan.ROOT,CONTROL=plan.CONTROL,ARCHIVE=remote_archive,BINARIES=plan.config()[role]['binaries'],HASHES=manifest['binary_sha256'],RESUME=resume and role=='source',PINS=pins,RUN_OUTPUT='run'+suffix,SYSTEM_OUTPUT='system'+suffix)
   prefix='\n'.join(k+'='+repr(v) for k,v in values.items())+'\n'
   remote.run(role,'bundle-control-admission'+('-'+tag if tag else ''),remote.ssh(role,['python3','-B','-c',prefix+code]))
   remote.run(role,'transfer-control-bundle'+('-'+tag if tag else ''),['scp',str(archive),plan.HOSTS[role]+':'+remote_archive],90)
   code='''import pathlib,os,zipfile,hashlib,json
q=pathlib.Path(CONTROL);bundle=pathlib.Path(ARCHIVE)
assert q.resolve(strict=True)==q and q.stat().st_uid==1001 and not bundle.is_symlink() and bundle.stat().st_uid==1001 and bundle.stat().st_size<=4*1024**2
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==BUNDLE_HASH
with zipfile.ZipFile(bundle) as z:
 infos=z.infolist();assert len(infos)==len(PINS) and {i.filename for i in infos}==set(PINS) and sum(i.file_size for i in infos)<=8*1024**2
 data={}
 for i in infos:
  p=pathlib.PurePosixPath(i.filename)
  assert not p.is_absolute() and '..' not in p.parts and str(p)==i.filename and chr(92) not in i.filename and ':' not in i.filename
  assert len(p.parts)==1 or (len(p.parts)==2 and p.parts[0]=='overlay')
  data[i.filename]=z.read(i);assert hashlib.sha256(data[i.filename]).hexdigest()==PINS[i.filename]
 for f in q.rglob('*'):
  assert not f.is_symlink()
  if f.is_file():assert f.relative_to(q).as_posix() in PINS and f.stat().st_uid==1001 and hashlib.sha256(f.read_bytes()).hexdigest()==PINS[f.relative_to(q).as_posix()]
 added=[]
 for name,content in data.items():
  f=q/name
  if not f.exists():
   with f.open('xb') as out:out.write(content)
   f.chmod(0o600);added.append(name)
 assert all(not (q/n).is_symlink() and hashlib.sha256((q/n).read_bytes()).hexdigest()==h for n,h in PINS.items())
 print(json.dumps(dict(verified_files=len(PINS),added_files=added,bundle_sha256=BUNDLE_HASH)))
'''
   prefix='CONTROL='+repr(plan.CONTROL)+'\nARCHIVE='+repr(remote_archive)+'\nPINS='+repr(pins)+'\nBUNDLE_HASH='+repr(bundle_hash)+'\n'
   remote.run(role,'verify-control-bundle'+('-'+tag if tag else ''),remote.ssh(role,['python3','-B','-c',prefix+code]))
   remote.run(role,'cold-bootstrap'+('-'+tag if tag else ''),remote.ssh(role,[plan.ROOT+'/venv/bin/python','-B',plan.CONTROL+'/bootstrap.py']))
   remote.run(role,'preflight',remote.ssh(role,remote.call(role,'preflight')))
   remote.run(role,'prepare-mountpoints',remote.ssh(role,remote.call(role,'prepare-mountpoints')));prepared.append(role)
   remote.run(role,'capability',remote.ssh(role,plan.service(role,remote.call(role,'smoke'),smoke=True)))
   receipt=json.loads((here/('step-'+role+'-capability/stdout.log')).read_bytes())
   assert receipt.get('status')=='PASS_CAPABILITY_ONLY'
   remote.run(role,'capability-absence',remote.ssh(role,remote.call(role,'smoke-absence')))
   with (here/(role+'-capability-PASS.json')).open('x') as f:json.dump(receipt,f,indent=2)
   print('CAPABILITY_PASSED',label,role,flush=True)
 except BaseException:
  for role in prepared:
   try:remote.run(role,'preparation-rollback',remote.ssh(role,remote.call(role,'cleanup-mountpoints')))
   except BaseException:pass
  raise
