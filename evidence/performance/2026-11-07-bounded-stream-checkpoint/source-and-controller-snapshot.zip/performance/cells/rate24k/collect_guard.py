"""Read-only collection of this run's raw interface/resource guard evidence."""
import pathlib,json
import plan
from prepare_remote import run,ssh
HERE=pathlib.Path(__file__).resolve().parent
for role in plan.HOSTS:
 path=plan.ROOT+'/evidence/'+('runrxe2026110727')+'/guard-'+role+'.json'
 code='import pathlib,json; p=pathlib.Path('+repr(path)+'); assert p.stat().st_size<1048576; print(p.read_text())'
 run(role,'collect-guard',ssh(role,['python3','-B','-c',code]))
 row=json.loads((HERE/('step-'+role+'-collect-guard/stdout.log')).read_text())
 samples=row['samples'];rates=[]
 for a,b in zip(samples,samples[1:]):
  dt=b['now']-a['now'];assert dt>0
  rates.append({k:8*(b[k]-a[k])/dt/1e6 for k in ('tx','rx')})
 summary=dict(role=role,failure=row['failure'],exit=row['exit'],samples=len(samples),elapsed=row['elapsed'],
  peak_memory_mib=max(x['memory'] for x in samples)/1024**2,peak_tasks=max(x['tasks'] for x in samples),
  min_available_mib=min(x['available'] for x in samples)/1024**2,
  max_tx_mbps=max(x['tx'] for x in rates),max_rx_mbps=max(x['rx'] for x in rates),
  drops_delta=samples[-1]['drops']-samples[0]['drops'],errors_delta=samples[-1]['errors']-samples[0]['errors'])
 print(json.dumps(summary))
 (HERE/('guard-summary-'+role+'.json')).write_text(json.dumps(summary,indent=2))
