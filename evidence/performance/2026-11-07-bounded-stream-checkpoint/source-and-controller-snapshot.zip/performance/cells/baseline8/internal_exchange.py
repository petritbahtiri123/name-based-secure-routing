"""Bounded local supervisor invokes a self-expiring internal SSH exchange."""
import json,pathlib
import bounded,internal_clock

def exchange(path,work=30):
    path=pathlib.Path(path)
    output=path.parent/(path.stem+'-command')
    command=['ssh','-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
             '-o','ConnectTimeout=8','-o','ConnectionAttempts=1',
             '-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2',
             'nbsr-client',internal_clock.remote_command(min(18,work-2))]
    bounded.run(command,output,work)
    wire=(output/'stdout.log').read_bytes()
    if len(wire)>8192:raise ValueError('calibration output cap')
    result=json.loads(wire);path.write_text(json.dumps(result,indent=2))
    if result.get('failure') or result.get('exit')!=0 or result.get('reader_stopped') is not True:
        raise ValueError('internal clock failed')
    rows=result['probes']
    # Admit worst-case drift allowance for a <=90 second pre/post span now.
    internal_clock.envelope(rows,rows,90_000_000_000)
    return result

def validate_pair(root):
    root=pathlib.Path(root)
    before=json.loads((root/'calibration-before.json').read_text())['probes']
    after=json.loads((root/'calibration-after.json').read_text())['probes']
    span=after[-1]['local_after_ns']-before[0]['local_before_ns']
    if after[0]['local_before_ns']<=before[-1]['local_after_ns']:raise ValueError('pre/post order')
    bounds=internal_clock.envelope(before,after,span)
    result={'server_minus_client_ns':bounds,'span_ns':span,
            'conditional_relative_drift_ppm':100,'all_samples_retained':True,
            'maximum_informative_event_width_ns':200_000_000,
            'scope':'Temporal association only; actual counter brackets and origin uncertainty must also be included.'}
    (root/'CALIBRATION.json').write_text(json.dumps(result,indent=2))
    return result
