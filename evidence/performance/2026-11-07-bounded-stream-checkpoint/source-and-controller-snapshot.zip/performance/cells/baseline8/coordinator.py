from activate import activate
activate()
"""Task-local transport adapter; existing finite control plus explicit returned-error collection."""
import json, pathlib, sys, time, gzip


from contextlib import contextmanager

@contextmanager
def owned_transport(finite,remote,collect):
    previous=(finite.remote_command,finite.collect)
    finite.remote_command,finite.collect=remote,collect
    try:yield
    finally:finite.remote_command,finite.collect=previous

def execute(root, ssh_config, started, *, plan, correlation_pins, offsets):
    from scripts.performance import linux_native_finite_run as finite
    from scripts.performance.linux_native_lifecycle_remote import download_archive, extract_public_archive
    from scripts.performance.linux_native_pair import verify_index
    from scripts.performance.process_cancellation import Cancellation
    from scripts.performance.recv_error_collection import Session
    from scripts.performance.recv_error_handoff import collector_config
    from scripts.performance.paced_diagnostics import summarize, read_records
    here=pathlib.Path(__file__).resolve().parent
    if (here/'LIVE-DISABLED.json').exists():raise RuntimeError('Live coordinator disabled: offline verification phase')
    session=Session(correlation_pins,collector_config(plan.config()))
    WORK,COLLECTION=plan.WORK,plan.COLLECTION
    plan.set_origin(started,offsets)
    c=plan.config();finite.validate_config(c)
    from calibration_sequence import Window
    from internal_exchange import exchange,validate_pair
    here=pathlib.Path(__file__).resolve().parent
    window=Window(json.loads((here/'calibration-anchor.json').read_text())['local_monotonic'])
    def post_calibration():
        exchange(here/'calibration-after.json',work=window.post_budget())
        window.finish()
        validate_pair(here)
    def remote(target,argv):return plan.remote_argv(target,argv,ssh_config)
    def collection_check():
        if time.monotonic()-started>=COLLECTION:raise TimeoutError('collection cutoff; reserve final cleanup')
    def collect(target,role,output,*,check_cancelled):
        archive=output/(role+'.tar.gz')
        result=download_archive(remote(target,['tar','-C',target['output'],'-czf','-','.']),archive,
            output/(role+'-transfer-stderr.log'),timeout=min(15,max(.01,COLLECTION-(time.monotonic()-started))),maximum_bytes=2*1024**2,check_cancelled=collection_check)
        with gzip.open(archive,'rb') as stream:data=stream.read(2*1024**2+1)
        if len(data)>2*1024**2:raise ValueError('decompressed archive cap')
        unpacked=output/(role+'.tar');unpacked.write_bytes(data);collection_check()
        extract_public_archive(unpacked,output/role,maximum_bytes=2*1024**2,maximum_entries=1000)
        result['index_sha256']=verify_index(output/role)
        result['recv_errors_capture']=session.capture(role,output/role)

        # Keep both original archive and extracted proof; bounded at 64MiB total.
        (output/(role+'-transfer.json')).write_text(json.dumps(result))
    with owned_transport(finite,remote,collect), Cancellation() as cancellation:
        def check():
            cancellation.check()
            window.check_work()
            if (root.parent/'cancel').exists():raise InterruptedError('parent cancellation')
            if time.monotonic()-started>=WORK:raise TimeoutError('work cutoff; no renewed budget')
        def finalize(output,result):
            collection_check()
            from scripts.performance.linux_native_paced import read_paced
            cell=dict(path='nbsr',cores=1,payload_bytes=1024,streams=8,outstanding=1,benchmark_seconds=20,diagnostic_rate=[16000,1],origin_record=True)
            f=read_paced(output/'source'/'peer'/'stdout',cell)['final']
            assert f['offered']==320000 and f['issued']==f['completed'] and f['completed']+f['missed']==320000 and f['errors']==f['timeouts']==0
            final=dict(integrity_complete=True,scheduled=f['offered'],issued=f['issued'],completed=f['completed'],unissued=f['missed'],failed=0,unresolved=0)
            result['recv_errors']=session.finish()
            (output/'essential-accounting.json').write_text(json.dumps(final))
            collection_check()
        return finite.execute(c,root,check_cancelled=check,recv_errors_finalize=finalize,before_collection=post_calibration)

if __name__=='__main__':
    raise SystemExit('Library integration only: supply verified fresh plan, pins and offsets through execute.')
