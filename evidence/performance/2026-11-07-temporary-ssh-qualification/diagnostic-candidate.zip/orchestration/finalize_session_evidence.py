"""Seal the stopped attempt without changing raw statuses or retrying it."""
import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01';Q=H/'management/q1';C=H/'cells/controller'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins=read(H/'qualification-inputs.json')
for name,digest in pins['files'].items():assert sha(H/name)==digest,name
assert sha(T/'run_session_qualification.py')==pins['outer_runner_sha256']
q=read(Q/'qualification.json');assert q['status']=='STOP_INVALID_OR_UNQUALIFIED' and q['error']['type']=='TimeoutError'
assert not (H/'management/q2').exists() and not (H/'evidence/qualification-q2-command').exists()
assert (C/'LIVE-DISABLED.json').exists() and not (C/'run01-trial').exists()
config=read(Q/'calibration-session/config.json');start=config['started'];broker=read(Q/'calibration-session/broker-final.json');owner=read(Q/'calibration-session/ownership-final.json')
assert owner['status']=='FAILED' and not owner['owned_handles'] and owner['leader_reaped'] and owner['group_exit_observed']
remote=read(Q/'calibration-remote-observation.json')
assert remote['status']=='REMOTE_FAILED_CLEANUP_CONFIRMED' and remote['cleanup_confirmed'] and not remote['execution_valid'] and not remote['errors']
assert len(remote['observations'])==2 and all(x['current'] is None and not x['original_present'] and not x['group_present'] for x in remote['observations'])
reply=read(Q/'calibration-session/reply-1.json')['payload'];clock=reply['result']
assert clock['exit']==0 and clock['reader_stopped'] and not clock.get('failure') and clock['stderr']=='' and len(clock['probes'])==3
commands={}
for p in sorted((H/'evidence').glob('*command*/supervision.json')):
 v=read(p);assert not v['owned_handles'] and v['leader_reaped'] and v['group_exit_observed'],str(p)
 commands[p.parent.relative_to(H).as_posix()]={k:v.get(k) for k in ('status','exit_code','elapsed_seconds','owned_handles','leader_reaped','group_exit_observed','drain_failure')}
v=read(Q/'calibration-remote-absence/supervision.json');assert v['status']=='LOCAL_WORKER_COMPLETED' and not v['owned_handles'] and v['leader_reaped'] and v['group_exit_observed']
commands['management/q1/calibration-remote-absence']=v
fixtures={}
for p in sorted((H/'evidence').glob('test_*/session/ownership-final.json')):
 v=read(p);assert not v['owned_handles'] and v['leader_reaped'] and v['group_exit_observed']
 fixtures[p.relative_to(H).as_posix()]=dict(status=v['status'],sha256=sha(p))
timings=[dict(event=x['event'],operation=x['op'],seconds=x['monotonic']-start) for x in broker['events']]
summary=dict(status='NOT_QUALIFIED_NOT_PROMOTED',authorization='Petriti approved trial-only temporary SSH ownership; no deadline, NBSR protocol or access-policy change.',
 local_tests=58,local_test_log='evidence/all-final-command/stderr.log',owned_local_fixture_receipts=len(fixtures),
 review=dict(model='GPT-6 Astra',initial_important_findings=5,fix_pass='All addressed in scoped RED/GREEN regressions and58-test suite; actual parent-loss watchdog tested in Linux. Author verification after review, no second-review verdict claimed.',minor='Raw provenance hashes corrected; pre-review manifest retained.'),
 parent_loss_fixture=read(H/'evidence/remote-expiry-fixture-command/stdout.log'),
 qualification=dict(attempted_sessions=1,maximum_sessions=2,replacements=0,q1=q['status'],q2='NOT_RUN_AFTER_STOP',
 reason='PRE original10s admission deadline crossed at Client.wait check immediately after the fresh synchronous resource guard.',
 timing_events=timings,broker_cancelled_seconds=broker['elapsed'],local_empty_reaped_closed_seconds=owner['elapsed_seconds'],
 pre_inner_rtts_ns=[r['local_after_ns']-r['local_before_ns'] for r in clock['probes']],
 post='NOT_RUN',idle_cost='NOT_MEASURED',promotion_screen_post_seconds=5,actual_exchange_cutoff_seconds=10),
 cleanup=dict(local_confirmed=True,remote_confirmed=True,remote_execution_valid=False,independent_remote_observation='management/q1/calibration-remote-observation.json',
 interpretation='Raw qualification.remote_closed=false means the success-only REMOTE_CLOSED gate failed. Independent receipt separately confirms absent helper/probe PID+start identities and both groups; raw status is retained unchanged.'),
 commands=commands,owned_fixture_receipts=fixtures,endpoint_workloads=0,throughput_comparison='NOT_PREPARED_OR_RUN_AFTER_QUALIFICATION_STOP',
 conclusions=['PRE reply was published before10s, but complete guarded admission failed. It must not be accepted retroactively.',
 'This attempt does not measure POST savings or idle impact. The claimed benefit of retaining SSH therefore remains unproven.',
 'Both old supervise and new owner retain a pre-start full resource guard. No evidence supports a redundant-startup-guard fix; per-scan durations were not instrumented in this attempt.',
 'Next discriminator, before proposing another qualification: isolate timestamp-only guard entry/exit evidence and cold PRE setup/acceptance cost in a fresh bounded fixture. No additional live test authorized by this sealed attempt; no blind replacement.',
 'Historical intermittent NBSR/DirectQUIC issue and maximum throughput remain unresolved.'],
 branch='codex/nbsr-v3-wp0-wp1',base_commit='648d6ab6485f4b6466afcd2ab7906a36880b1b96',
 guidance='No promoted setup/test workflow or project runtime changed; AGENTS.md requires no change for this unqualified archived diagnostic.',
 canonical_document='SHARED-EVIDENCE-AND-NEXT-TEST-2026-11-06.md')
(H/'summary.json').write_text(json.dumps(summary,indent=2))
progress=read(H/'progress.json');progress.update(completed_tasks=[1,2,3,4],active_task=6,task4_outcome='STOPPED_UNQUALIFIED',task5='NOT_RUN_GATE_FAILED',task6='Seal, document and preserve unpromoted candidate on existing branch')
(H/'progress.json').write_text(json.dumps(progress,indent=2))
helpers=['integrate_temporary_session.py','sync_session_review_fixes.py','refresh_session_owner_fix.py','run_session_owned_tests.py','run_session_owned_tests02.py','run_session_all_tests.py','run_session_all_after_review.py','run_session_all_final.py','run_session_remote_fixture.py','run_session_qualification.py','record_session_local.py','freeze_session_qualification.py','finalize_session_evidence.py']
(H/'orchestration').mkdir(exist_ok=False)
for name in helpers:(H/'orchestration'/name).write_bytes((T/name).read_bytes())
files={}
for p in sorted(H.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts and p.name!='final-evidence-index.json':files[p.relative_to(H).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
index=dict(schema='nbsr-local-evidence-index-v1',files=files,total_bytes=sum(x['bytes'] for x in files.values()))
with (H/'final-evidence-index.json').open('x') as f:json.dump(index,f,indent=2)
print(json.dumps(dict(status=summary['status'],files=len(files),bytes=index['total_bytes'],index_sha256=sha(H/'final-evidence-index.json'),timing_events=timings,owned_fixture_receipts=len(fixtures))))
