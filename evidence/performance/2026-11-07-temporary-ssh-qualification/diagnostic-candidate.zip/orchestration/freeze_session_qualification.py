"""Freeze only after local review regressions and isolated remote expiry pass."""
import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01';C=H/'cells/controller'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ('all-final-command','remote-expiry-fixture-command'):
 v=read(H/'evidence'/name/'supervision.json')
 assert v['status']=='LOCAL_WORKER_COMPLETED' and not v['owned_handles'] and v['leader_reaped'] and v['group_exit_observed'] and v['drain_failure'] is None
assert 'Ran 58 tests' in (H/'evidence/all-final-command/stderr.log').read_text()
fixture=read(H/'evidence/remote-expiry-fixture-command/stdout.log')
assert fixture['status']=='PASS_PARENT_LOSS_ABSOLUTE_EXPIRY'
for p in (H/'src').glob('*.py'):assert p.read_bytes()==(C/p.name).read_bytes()
paths={H/n for n in ('plan.json','support-input-pins.json','integration-delta.json','qualify_one.py','remote_expiry_fixture.py')}
for directory in ('src','tests','collector'):
 paths.update(p for p in (H/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
support=read(H/'support-input-pins.json')
paths.update(C/n for n in support);paths.update(C.glob('*.py'))
pins=dict(review_status='READY_FOR_MANAGEMENT_QUALIFICATION',review_origin='GPT-6 Astra original five Important findings; author qualified the single fix pass through RED/GREEN regressions,58-test suite and Linux parent-loss fixture. No second reviewer verdict is claimed.',
 files={p.relative_to(H).as_posix():sha(p) for p in sorted(paths)},outer_runner_sha256=sha(T/'run_session_qualification.py'),
 local_tests=58,local_supervision_sha256=sha(H/'evidence/all-final-command/supervision.json'),
 remote_fixture=fixture,remote_fixture_supervision_sha256=sha(H/'evidence/remote-expiry-fixture-command/supervision.json'),
 benchmark_launch_allowed=False,qualification_sessions_max=2,replacement_allowed=False)
with (H/'qualification-inputs.json').open('x') as f:json.dump(pins,f,indent=2)
v=read(H/'progress.json');v.update(completed_tasks=[1,2,3],active_task=4,local_suite='58/58 passed after all review fixes; evidence/all-final-command',
 remote_parent_loss_fixture=fixture,review_fixes_verified=True,
 review_fix_evidence=['evidence/review-fixes-red.log','evidence/review-fixes-green.log','evidence/missing-probe-red.log','evidence/persistent-kill-red.log','evidence/all-final-command/stderr.log'])
(H/'progress.json').write_text(json.dumps(v,indent=2))
print(json.dumps(dict(status=pins['review_status'],pinned_files=len(pins['files']),manifest_sha256=sha(H/'qualification-inputs.json'))))
