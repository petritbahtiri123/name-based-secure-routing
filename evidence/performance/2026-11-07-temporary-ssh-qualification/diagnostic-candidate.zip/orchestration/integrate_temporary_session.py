"""Disabled candidate only; preserve the prior controller and all workload limits."""
import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01';C=H/'cells/controller'
changes={}
def edit(name,old,new):
 p=C/name;b=p.read_text();assert b.count(old)==1,name
 p.write_text(b.replace(old,new));changes[name]=dict(before=hashlib.sha256(b.encode()).hexdigest(),after=hashlib.sha256(p.read_bytes()).hexdigest())
edit('tls_and_trial.py',"  from internal_exchange import exchange\n  exchange(HERE/'calibration-before.json')\n  # The owned supervisor records this after admission, before launching PRE.\n  # Thus expensive local admission is excluded, but every actual probe is inside.\n  anchor=json.loads((HERE/'calibration-before-command/request.json').read_text())['started']\n  from calibration_sequence import Window\n  Window(anchor).admit_pre()\n  (HERE/'calibration-anchor.json').write_text(json.dumps({'local_monotonic':anchor}))\n  attempted=True\n  print('MEASUREMENT_STARTING streams32',flush=True)\n  bounded.run(['@COORDINATOR@','existing-default-aliases'],HERE/'run01-trial',plan.COORDINATOR)\n  result=json.loads((HERE/'run01-trial/final-result.json').read_text());print(json.dumps(result))",
"""  import session_adapter
  calibration=session_adapter.create(HERE,plan.RUN)
  trial_problem=None
  try:
   session_adapter.pre(calibration,HERE)
   attempted=True
   print('MEASUREMENT_STARTING streams32',flush=True)
   bounded.run(['@COORDINATOR@','existing-default-aliases'],HERE/'run01-trial',plan.COORDINATOR)
   calibration.close()
  except BaseException as e:
   trial_problem=e
   calibration.abort('trial failed')
  finally:
   if not calibration.wait_closed(2):
    failure=RuntimeError('temporary SSH ownership unconfirmed')
    if trial_problem is None:trial_problem=failure
    else:trial_problem.add_note(str(failure))
   try:
    request=HERE/'run01-trial/request.json'
    deadline=(json.loads(request.read_text())['started']+plan.FINALIZATION if request.exists() else calibration.deadline)
    session_adapter.verify_remote(HERE,plan.RUN,deadline)
   except BaseException as e:
    if trial_problem is None:trial_problem=e
    else:trial_problem.add_note('Calibration remote cleanup: '+type(e).__name__+': '+str(e))
  if trial_problem:raise trial_problem
  result=json.loads((HERE/'run01-trial/final-result.json').read_text());print(json.dumps(result))""")
edit('coordinator.py','    from internal_exchange import exchange,validate_pair','    import session_adapter')
edit('coordinator.py',"        exchange(here/'calibration-after.json',work=window.post_budget())\n        window.finish()\n        validate_pair(here)","        window.post_budget()\n        session_adapter.post(here,plan.RUN)\n        window.finish()")
for p in sorted((H/'src').glob('*.py')):
 target=C/p.name;assert not target.exists();target.write_bytes(p.read_bytes())
 changes[p.name]=dict(after=hashlib.sha256(p.read_bytes()).hexdigest(),source='src/'+p.name)
for p in C.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
(H/'integration-delta.json').write_text(json.dumps(changes,indent=2))
assert (C/'LIVE-DISABLED.json').exists()
print(json.dumps(dict(status='INTEGRATED_LIVE_DISABLED',files=len(changes))))
