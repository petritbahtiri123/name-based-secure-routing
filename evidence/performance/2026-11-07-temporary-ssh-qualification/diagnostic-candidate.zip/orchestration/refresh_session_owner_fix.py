import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01';C=H/'cells/controller'
p=H/'src/session_owner.py';(C/p.name).write_bytes(p.read_bytes())
delta=json.loads((H/'integration-delta.json').read_bytes());delta[p.name]['after']=hashlib.sha256(p.read_bytes()).hexdigest()
(H/'integration-delta.json').write_text(json.dumps(delta,indent=2))
for p in (H/'src').glob('*.py'):assert p.read_bytes()==(C/p.name).read_bytes()
print('Synchronized final ownership failure fix')
