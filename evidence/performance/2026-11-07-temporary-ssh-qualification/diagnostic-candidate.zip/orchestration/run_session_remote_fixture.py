import base64,json,pathlib,shlex,sys,zlib
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01';C=H/'cells/controller'
sys.path[:0]=[str(H/'src'),str(C)]
from activate import activate
activate()
import bounded,resource_boundary,session_payload
code=session_payload.bundle('fixture-expiry').rsplit('\n',1)[0]+'\n'+(H/'remote_expiry_fixture.py').read_text()
compile(code,'remote-expiry-fixture','exec')
encoded=base64.b64encode(zlib.compress(code.encode())).decode()
command=session_payload.SSH_PREFIX+[shlex.join(['timeout','--kill-after=2s','8s','python3','-u','-B','-c',"import base64,zlib;exec(zlib.decompress(base64.b64decode('"+encoded+"')))"])]
counts=resource_boundary.check(starting=True);(C/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
out=H/'evidence/remote-expiry-fixture-command'
bounded.run(command,out,25,consoleless=True)
value=json.loads((out/'stdout.log').read_bytes());assert value['status']=='PASS_PARENT_LOSS_ABSOLUTE_EXPIRY'
print(json.dumps(value),flush=True)
