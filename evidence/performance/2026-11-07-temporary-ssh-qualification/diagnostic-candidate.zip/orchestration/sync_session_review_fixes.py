"""Retain pre-review manifest, refresh only candidate copies and raw-byte provenance."""
import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01';C=H/'cells/controller';B=T/'post-control-timing02/cells/qualification1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=H/'integration-delta.json';retained=H/'integration-delta-before-review.json'
assert not retained.exists();retained.write_bytes(old.read_bytes())
support=json.loads((H/'support-input-pins.json').read_bytes());changes={}
for name in ('tls_and_trial.py','coordinator.py'):
 assert sha(B/name)==support[name]
 changes[name]=dict(before=support[name],after=sha(C/name),baseline='post-control-timing02/cells/qualification1/'+name)
for p in sorted((H/'src').glob('*.py')):
 target=C/p.name;target.write_bytes(p.read_bytes())
 assert target.read_bytes()==p.read_bytes()
 changes[p.name]=dict(after=sha(p),source='src/'+p.name)
for name,digest in support.items():
 if name not in changes:assert sha(C/name)==digest,name
old.write_text(json.dumps(changes,indent=2))
for p in list((H/'src').glob('*.py'))+list(C.glob('*.py'))+[H/'qualify_one.py',H/'remote_expiry_fixture.py']:compile(p.read_bytes(),str(p),'exec')
assert (C/'LIVE-DISABLED.json').exists()
progress=json.loads((H/'progress.json').read_bytes())
progress['review']=dict(model='GPT-6 Astra',initial_verdict='NOT_READY_FOR_MANAGEMENT_QUALIFICATION',important_findings=5,
 fixes='Monitor startup synchronous cleanup; keep ownership observation after termination errors; latch kill only after success; independent absolute probe watchdog; cumulative terminal Job memory peak; inspect failed receipt identities before classifying execution.',
 pending='Full suite after fixes and actual Linux parent-loss fixture. Missing probe identity completeness regression added after recovery.',
 minor_provenance='Corrected raw-byte before hashes and retained original manifest.',
 declined_to_judge='Actual Linux, SSH route/auth, latency, CPU/RSS, remote disappearance, fresh benchmarks and production readiness remain unproven; management gates required.')
(H/'progress.json').write_text(json.dumps(progress,indent=2))
print(json.dumps(dict(status='CANDIDATE_COPIES_SYNCHRONIZED',source_modules=len(list((H/'src').glob('*.py'))),unchanged_support_verified=True)))
