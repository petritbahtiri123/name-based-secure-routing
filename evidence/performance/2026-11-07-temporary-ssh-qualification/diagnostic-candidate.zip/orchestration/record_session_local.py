import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01'
receipts={}
for p in sorted((H/'evidence').glob('test_*/session/ownership-final.json')):
 v=json.loads(p.read_bytes());assert not v['owned_handles'] and v['leader_reaped'] and v['group_exit_observed'],str(p)
 receipts[p.relative_to(H).as_posix()]=dict(status=v['status'],failure=v['failure'],elapsed_seconds=v['elapsed_seconds'],sha256=hashlib.sha256(p.read_bytes()).hexdigest())
sup=json.loads((H/'evidence/all-green-command/supervision.json').read_bytes())
assert sup['status']=='LOCAL_WORKER_COMPLETED' and not sup['owned_handles'] and sup['leader_reaped'] and sup['group_exit_observed']
value=dict(status='LOCAL_TESTS_PASSED_LIVE_UNQUALIFIED',tests=47,python='3.14 Windows only; no cross-platform matrix claim',owned_fixture_receipts=receipts,
 outer_supervision=sup,raw_test_log='evidence/all-green-command/stderr.log',benchmark_workloads=0,
 limitation='Portable remote tests validate emitted source/identity contract only; actual Linux process and SSH semantics require the bounded management qualification.')
(H/'local-validation.json').write_text(json.dumps(value,indent=2));print(json.dumps(dict(tests=47,retained_closed_owned_fixtures=len(receipts))))
