import pathlib,sys,json
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01';C=H/'cells/controller';sys.path.insert(0,str(C))
import bounded,resource_boundary
counts=resource_boundary.check(starting=True);(C/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
bounded.run([sys.executable,'-B','-m','unittest','discover','-s',str(H/'tests'),'-p','test_session_*.py','-v'],H/'evidence/all-after-review-command',30)



