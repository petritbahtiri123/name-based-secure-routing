"""Outer bounded owner for each reviewed management-only qualification."""
import hashlib,json,pathlib,sys
T=pathlib.Path(__file__).resolve().parent;H=T/'temporary-ssh-session01';C=H/'cells/controller'
sys.path.insert(0,str(C));import bounded,resource_boundary
label=sys.argv[1]
if label not in ('q1','q2'):raise ValueError('two fixed qualification slots only')
pins=json.loads((H/'qualification-inputs.json').read_bytes())
assert pins['review_status']=='READY_FOR_MANAGEMENT_QUALIFICATION'
for name,digest in pins['files'].items():assert hashlib.sha256((H/name).read_bytes()).hexdigest()==digest,name
assert hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()==pins['outer_runner_sha256']
if (H/'management'/label).exists() or (H/'evidence'/('qualification-'+label+'-command')).exists():raise ValueError('no qualification replacement/retry')
if label=='q2':assert json.loads((H/'management/q1/qualification.json').read_bytes())['status']=='PASS'
counts=resource_boundary.check(starting=True);(C/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
print('MANAGEMENT_QUALIFICATION_START '+label+'; no NBSR endpoint workload',flush=True)
bounded.run([sys.executable,'-u','-B',str(H/'qualify_one.py'),label],H/'evidence'/('qualification-'+label+'-command'),60)
