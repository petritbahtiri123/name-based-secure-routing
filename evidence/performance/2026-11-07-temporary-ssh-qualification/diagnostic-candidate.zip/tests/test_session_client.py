import json,pathlib,sys,tempfile,unittest
H=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(H/'src'))
from session_client import Client
from session_files import publish
from session_wire import encode

class ClientTests(unittest.TestCase):
 def setUp(self):
  self.root=pathlib.Path(tempfile.mkdtemp(prefix='client-',dir=H/'evidence'));self.now=1
  (self.root/'config.json').write_text(json.dumps(dict(run='fixture-client',started=0,deadline=88,request_seconds=10)))
  for seq,op in ((0,'READY'),(1,'PRE'),(2,'POST')):
   publish(self.root,'reply-'+str(seq),encode(dict(v=1,run='fixture-client',seq=seq,op=op,payload={})))
 def test_completed_pre_cannot_pass_after_fresh_guard_crosses_deadline(self):
  def guard():self.now=10
  c=Client(self.root,'fixture-client',guard=guard,clock=lambda:self.now)
  with self.assertRaises(TimeoutError):c.pre()
  self.assertTrue((self.root/'cancel').exists())
 def test_post_budget_includes_pre_send_guard(self):
  def guard():self.now+=10
  c=Client(self.root,'fixture-client',guard=guard,clock=lambda:self.now)
  with self.assertRaises(TimeoutError):c.exchange('POST')
  self.assertFalse((self.root/'request-2.ready').exists())
 def test_absolute_session_expiry_not_reset_for_post(self):
  self.now=87;c=Client(self.root,'fixture-client',guard=lambda:None,clock=lambda:self.now)
  with self.assertRaises(TimeoutError):c.exchange('POST')
  self.assertFalse((self.root/'request-2.ready').exists())
 def test_prior_failure_cannot_be_hidden_by_available_reply(self):
  publish(self.root,'ownership-final',encode(dict(status='FAILED')))
  c=Client(self.root,'fixture-client',guard=lambda:None,clock=lambda:self.now)
  with self.assertRaises(RuntimeError):c.pre()

if __name__=='__main__':unittest.main(verbosity=2)
