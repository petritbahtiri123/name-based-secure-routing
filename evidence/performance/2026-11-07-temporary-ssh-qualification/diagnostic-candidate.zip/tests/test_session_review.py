"""Failure injection for the independent review's ownership and validity findings."""
import importlib,json,pathlib,sys,tempfile,unittest
from unittest.mock import patch,Mock
H=pathlib.Path(__file__).resolve().parents[1];sys.path[:0]=[str(H/'src'),str(H/'cells/controller')]
from activate import activate
activate()
import session_owner,session_remote,session_cost

class FakeOwner:
 def __init__(self,*a,**k):self.owned=False;self.job=None;self.process=1;self.assigned=True;self.killed=False;self.drain_failure=None;self.drain_events=[];self.signals=0;self.observations=0
 def start(self):self.owned=True
 def signal(self,name):
  self.signals+=1
  if self.signals==1:raise OSError('injected termination error')
 def observe(self):self.observations+=1;return 1,False
 def reap(self):self.owned=False

class ReviewTests(unittest.TestCase):
 def root(self):return pathlib.Path(tempfile.mkdtemp(prefix='review-',dir=H/'evidence'))
 def test_thread_start_failure_reclaims_already_started_owner(self):
  root=self.root()/'session'
  with patch.object(session_owner,'DrainingOwner',FakeOwner),patch.object(session_owner,'SessionJobOwner',FakeOwner,create=True),patch.object(session_owner.threading.Thread,'start',side_effect=RuntimeError('injected thread startup failure')):
   o=session_owner.OwnedSession(root,'fixture-review',['unused'],guard=lambda:None,transport='local-fixture')
   with self.assertRaises(RuntimeError):o.open_pre()
  self.assertTrue(o.done.is_set());self.assertFalse(o.owner.owned);self.assertIsNotNone(o.final)
  self.assertEqual(o.final['status'],'FAILED')
 def test_termination_error_does_not_stop_observation_and_receipt(self):
  root=self.root();o=session_owner.OwnedSession(root,'fixture-review',['unused'],guard=lambda:None)
  import time
  o.started=time.monotonic();o.deadline=o.started+8;o.owner=FakeOwner();o.owner.start();o._fail('injected primary failure')
  o._monitor()
  self.assertFalse(o.owner.owned);self.assertGreater(o.owner.observations,0);self.assertEqual(o.final['status'],'FAILED')
 def test_kill_latch_changes_only_after_success(self):
  self.assertTrue(hasattr(session_owner,'SessionJobOwner'))
  backend=Mock();backend.terminate.side_effect=[OSError('once'),None]
  o=session_owner.SessionJobOwner(['unused'],backend=backend,cancel=lambda:None,deadline=999999999)
  o.process=1;o.job=2;o.assigned=True
  with self.assertRaises(OSError):o.signal('KILL')
  self.assertFalse(o.killed);o.signal('KILL');self.assertTrue(o.killed)
 def test_persistent_kill_error_still_reaps_observed_empty_job(self):
  root=self.root();o=session_owner.OwnedSession(root,'fixture-review',['unused'],guard=lambda:None)
  import time
  o.started=time.monotonic();o.deadline=o.started+.1;o.owner=FakeOwner();o.owner.start();o._fail('primary failure')
  with patch.object(o.owner,'signal',side_effect=OSError('persistent terminate failure')):o._monitor()
  self.assertFalse(o.owner.owned);self.assertTrue(o.final['leader_reaped']);self.assertEqual(o.final['status'],'FAILED')
 def test_late_memory_peak_cannot_pass_idle_screen(self):
  a=dict(after_ns=0,cpu_100ns=0,monitor_cpu_ns=0,peak_job_memory_bytes=10)
  b=dict(before_ns=11_000_000_000,cpu_100ns=0,monitor_cpu_ns=0,peak_job_memory_bytes=10)
  pre=dict(after=dict(monotonic_ns=0,cpu_ns=0,peak_rss_bytes=10))
  post=dict(before=dict(monotonic_ns=11_000_000_000,cpu_ns=0,peak_rss_bytes=10))
  with self.assertRaises(ValueError):session_cost.assess(a,b,pre,post,pre_seconds=9,post_seconds=3,terminal_peak_bytes=129*1024**2)
 def receipt_root(self,ended=True):
  base=self.root();root=base/'calibration-fixture-review';root.mkdir()
  who=dict(pid=123,pgrp=120,start_ticks=456,uid=1001,gid=1001)
  (root/'identity.json').write_text(json.dumps(dict(run='fixture-review',identity=who)))
  if ended:(root/'ended.json').write_text(json.dumps(dict(run='fixture-review',status='FAILED',requests=1,probe_calls=0,identity=who,probe_cleanup=[])))
  return base,who
 def inspect(self,base,live=None):
  with patch.object(session_remote,'ROOT',str(base)),patch.object(session_remote,'read_receipt',side_effect=lambda p:json.loads(p.read_bytes())),patch.object(session_remote,'process_identity',side_effect=FileNotFoundError if live is None else None,return_value=live),patch.object(session_remote,'group_exists',return_value=live is not None):
   return session_remote.inspect('fixture-review')
 def test_failed_remote_execution_can_still_confirm_absence(self):
  base,who=self.receipt_root();value=self.inspect(base)
  self.assertFalse(value['execution_valid']);self.assertTrue(value['cleanup_confirmed']);self.assertEqual(len(value['observations']),1)
 def test_live_identity_prevents_cleanup_confirmation(self):
  base,who=self.receipt_root();value=self.inspect(base,who)
  self.assertFalse(value['cleanup_confirmed']);self.assertTrue(value['observations'][0]['original_present'])
 def test_missing_end_retains_observations_but_not_confirmation(self):
  base,who=self.receipt_root(False);value=self.inspect(base)
  self.assertFalse(value['execution_valid']);self.assertFalse(value['cleanup_confirmed']);self.assertEqual(len(value['observations']),1)
 def test_missing_probe_identity_is_unconfirmed(self):
  base,who=self.receipt_root();path=base/'calibration-fixture-review/ended.json'
  value=json.loads(path.read_bytes());value['probe_calls']=1;path.write_text(json.dumps(value))
  result=self.inspect(base);self.assertFalse(result['cleanup_confirmed']);self.assertEqual(len(result['observations']),1)
 def test_failed_pre_with_complete_dead_identities_confirms_cleanup_only(self):
  base,who=self.receipt_root();path=base/'calibration-fixture-review/ended.json'
  value=json.loads(path.read_bytes());value['probe_calls']=1
  value['probe_cleanup']=[dict(pid=124,pgrp=124,start_ticks=457,exit=1,group_empty=True)]
  path.write_text(json.dumps(value));result=self.inspect(base)
  self.assertTrue(result['cleanup_confirmed']);self.assertFalse(result['execution_valid']);self.assertEqual(len(result['observations']),2)
 def test_detached_probe_has_original_absolute_expiry(self):
  self.assertTrue(hasattr(session_remote,'probe_wrapper'))
  code=session_remote.probe_wrapper('print(1)',70)
  self.assertIn('72',code);self.assertIn('signal.setitimer',code);self.assertIn('os.killpg',code)
  self.assertIn('--foreground',code)

if __name__=='__main__':unittest.main(verbosity=2)
