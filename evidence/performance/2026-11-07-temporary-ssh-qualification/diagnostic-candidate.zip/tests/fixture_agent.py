"""Finite local transport fault source; never used for live SSH commands."""
import json,os,pathlib,subprocess,sys,time
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
from session_wire import encode,RequestState
mode,run=sys.argv[1:];state=RequestState(run);count=0
def send(seq,op,payload):
 sys.stdout.buffer.write(encode(dict(v=1,run=('wrong-run' if mode=='wrong-run' else run),seq=seq,op=op,payload=payload)));sys.stdout.buffer.flush()
if mode=='exit':raise SystemExit(7)
if mode=='oversize':sys.stdout.buffer.write(b'x'*8193+b'\n');sys.stdout.buffer.flush();time.sleep(1);raise SystemExit()
if mode=='stuck-child':
 subprocess.Popen([sys.executable,'-B','-c','import time;time.sleep(30)'],creationflags=subprocess.DETACHED_PROCESS)
 time.sleep(30)
send(0,'READY',dict(identity_pid=os.getpid()))
while True:
 wire=sys.stdin.buffer.readline(8193)
 if not wire:raise SystemExit(2)
 op=state.consume(wire);seq=state.next-1
 if op=='CLOSE':send(seq,op,dict(probe_count=count));break
 count+=1;send(seq,op,dict(identity_pid=os.getpid(),probe_count=count))
