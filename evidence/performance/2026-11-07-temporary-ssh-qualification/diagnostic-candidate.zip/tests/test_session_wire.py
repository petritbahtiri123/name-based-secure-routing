import importlib,importlib.util,json,pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))

class WireTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('session_wire'),'strict session wire implementation missing')
  self.w=importlib.import_module('session_wire')
 def request(self,op='PRE',seq=1,run='cal-test'):
  return json.dumps(dict(v=1,run=run,seq=seq,op=op)).encode()+b'\n'
 def test_exact_pre_post_close_sequence_then_no_reuse(self):
  state=self.w.RequestState('cal-test')
  for seq,op in enumerate(('PRE','POST','CLOSE'),1):self.assertEqual(state.consume(self.request(op,seq)),op)
  with self.assertRaises(ValueError):state.consume(self.request('CLOSE',3))
 def test_wrong_sequence_poison_cannot_be_repaired_by_retry(self):
  state=self.w.RequestState('cal-test')
  with self.assertRaises(ValueError):state.consume(self.request('POST',2))
  with self.assertRaises(ValueError):state.consume(self.request())
 def test_wrong_run_and_extra_field_rejected(self):
  for wire in (self.request(run='different'),b'{"v":1,"run":"cal-test","seq":1,"op":"PRE","command":"true"}\n'):
   with self.assertRaises(ValueError):self.w.RequestState('cal-test').consume(wire)
 def test_boolean_or_float_identity_numbers_rejected(self):
  for key,value in [('v',True),('seq',True),('seq',1.0)]:
   r=dict(v=1,run='cal-test',seq=1,op='PRE');r[key]=value
   with self.assertRaises(ValueError):self.w.RequestState('cal-test').consume(json.dumps(r).encode()+b'\n')
 def test_duplicate_fields_nan_and_bad_utf8_rejected(self):
  for wire in (b'{"a":1,"a":2}\n',b'{"a":NaN}\n',b'{"a":"\xff"}\n'):
   with self.assertRaises(ValueError):self.w.decode(wire)
 def test_missing_newline_extra_frame_or_oversize_rejected(self):
  for wire in (b'{}',b'{}\n{}\n',b' '*8192+b'\n'):
   with self.assertRaises(ValueError):self.w.decode(wire)
 def test_json_root_must_be_object(self):
  for wire in (b'[]\n',b'null\n',b'true\n'):
   with self.assertRaises(ValueError):self.w.decode(wire)
 def test_reply_requires_exact_run_sequence_operation(self):
  reply=self.w.encode(dict(v=1,run='cal-test',seq=1,op='PRE',payload={'probes':[1,2,3]}))
  self.assertEqual(self.w.reply(reply,'cal-test',1,'PRE'),{'probes':[1,2,3]})
  for run,seq,op in [('bad',1,'PRE'),('cal-test',2,'PRE'),('cal-test',1,'POST')]:
   with self.assertRaises(ValueError):self.w.reply(reply,run,seq,op)
 def test_reply_refuses_extra_field_or_nonobject_payload(self):
  for extra,payload in [({'extra':0},{}),({},[])]:
   wire=self.w.encode(dict(v=1,run='cal-test',seq=0,op='READY',payload=payload,**extra))
   with self.assertRaises(ValueError):self.w.reply(wire,'cal-test',0,'READY')
 def test_run_is_exact_small_ascii_identifier(self):
  for run in ('', '../bad','a'*65,'with space','CAL','é'):
   with self.assertRaises(ValueError):self.w.RequestState(run)
 def test_encoding_is_bounded_and_rejects_nonfinite(self):
  with self.assertRaises(ValueError):self.w.encode({'data':'a'*8192})
  with self.assertRaises(ValueError):self.w.encode({'x':float('nan')})

if __name__=='__main__':unittest.main(verbosity=2)
