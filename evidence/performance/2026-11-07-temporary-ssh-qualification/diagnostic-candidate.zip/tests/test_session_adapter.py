import importlib,importlib.util,json,pathlib,sys,tempfile,unittest
from unittest.mock import patch,Mock
H=pathlib.Path(__file__).resolve().parents[1];sys.path[:0]=[str(H/'src'),str(H/'cells/controller')]

class AdapterTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('session_adapter'),'controller adapter missing')
  from activate import activate
  activate();self.m=importlib.import_module('session_adapter')
  self.root=pathlib.Path(tempfile.mkdtemp(prefix='adapter-',dir=H/'evidence'))
 def test_post_closes_before_pair_validation(self):
  events=[];client=Mock()
  client.exchange.side_effect=lambda op:events.append(op) or {'result':{'probes':[]}}
  with patch.object(self.m,'Client',return_value=client),patch.object(self.m,'guard_for',return_value=lambda:None),patch.object(self.m,'save_calibration',side_effect=lambda *a:events.append('save')),patch.object(self.m.internal_exchange,'validate_pair',side_effect=lambda *a:events.append('pair')):
   self.m.post(self.root,'fixture-adapter')
  self.assertEqual(events,['POST','save','CLOSE','pair'])
 def test_bad_clock_never_becomes_pair_success(self):
  client=Mock();client.exchange.return_value={'result':{}}
  with patch.object(self.m,'Client',return_value=client),patch.object(self.m,'guard_for',return_value=lambda:None),patch.object(self.m,'save_calibration',side_effect=ValueError('bad clock')),patch.object(self.m.internal_exchange,'validate_pair') as pair:
   with self.assertRaises(ValueError):self.m.post(self.root,'fixture-adapter')
  client.cancel.assert_called_once();pair.assert_not_called()

if __name__=='__main__':unittest.main(verbosity=2)
