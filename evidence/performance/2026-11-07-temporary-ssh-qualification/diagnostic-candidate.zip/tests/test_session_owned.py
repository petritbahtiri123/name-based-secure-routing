"""Real Windows process/pipe/Job fixtures; never connect to a VM."""
import importlib,importlib.util,json,pathlib,sys,tempfile,time,unittest
from unittest.mock import patch
H=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(H/'src'))

class OwnedTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('session_owner'),'owned temporary session missing')
  sys.path.insert(0,str(H/'cells/controller'))
  from activate import activate
  activate()
  self.m=importlib.import_module('session_owner')
  self.fixture_root=pathlib.Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=H/'evidence'));self.root=self.fixture_root/'session';self.owner=None
 def tearDown(self):
  if hasattr(self,'owner') and self.owner is not None:
   self.owner.abort('fixture finished')
   self.assertTrue(self.owner.wait_closed(2),'fixture ownership unconfirmed')
  # Retain exact fixture bytes and cleanup receipts, including failures.
 def start(self,mode='normal',seconds=2):
  command=[sys.executable,'-B',str(H/'tests/fixture_agent.py'),mode,'fixture-test']
  self.owner=self.m.OwnedSession(self.root,'fixture-test',command,guard=lambda:None,
      lifetime=8,request_seconds=seconds,transport='local-fixture')
  return self.owner
 def assert_closed(self,successful):
  self.assertTrue(self.owner.wait_closed(2));r=self.owner.receipt()
  self.assertFalse(r['owned_handles']);self.assertTrue(r['leader_reaped']);self.assertTrue(r['group_exit_observed'])
  self.assertEqual(r['status']=='CLOSED',successful)
 def test_pre_post_share_one_process_and_close_cleanly(self):
  o=self.start();pre=o.open_pre();post=o.client().exchange('POST')
  self.assertEqual(pre['identity_pid'],post['identity_pid'])
  self.assertEqual(pre['probe_count'],1);self.assertEqual(post['probe_count'],2)
  o.close();self.assert_closed(True)
 def test_wrong_identity_refused_and_whole_job_closed(self):
  o=self.start('wrong-run')
  with self.assertRaises((ValueError,RuntimeError)):o.open_pre()
  o.abort('expected reject');self.assert_closed(False)
  broker=json.loads((o.root/'broker-final.json').read_bytes())
  self.assertEqual(broker['status'],'FAILED');self.assertEqual(broker['error_type'],'ValueError')
 def test_statistics_failure_still_reaps_exact_job(self):
  o=self.start()
  with patch.object(o,'_snapshot',side_effect=OSError('fixture statistics unavailable')):
   with self.assertRaises(RuntimeError):o.open_pre()
   self.assert_closed(False)
  self.assertIn('OSError',o.receipt()['failure'])
 def test_oversized_reply_refused(self):
  o=self.start('oversize')
  with self.assertRaises((ValueError,RuntimeError)):o.open_pre()
  o.abort('expected reject');self.assert_closed(False)
 def test_dead_peer_never_looks_like_success(self):
  o=self.start('exit')
  with self.assertRaises((ValueError,RuntimeError)):o.open_pre()
  self.assert_closed(False)
 def test_late_reply_is_invalid_and_descendant_is_killed(self):
  o=self.start('stuck-child',seconds=.5)
  with self.assertRaises((TimeoutError,RuntimeError)):o.open_pre()
  o.abort('expected timeout');self.assert_closed(False)
 def test_duplicate_post_cannot_be_replayed(self):
  o=self.start();o.open_pre();o.client().exchange('POST')
  with self.assertRaises((ValueError,FileExistsError)):o.client().exchange('POST')
  o.abort('expected replay reject');self.assert_closed(False)
 def test_close_before_post_is_invalid(self):
  o=self.start();o.open_pre()
  with self.assertRaises((ValueError,RuntimeError)):o.close()
  o.abort('expected close order reject');self.assert_closed(False)

if __name__=='__main__':unittest.main(verbosity=2)
