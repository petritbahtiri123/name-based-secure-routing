import importlib,importlib.util,pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
import session_wire as w

class AgentTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('session_agent'),'finite session agent missing')
  self.a=importlib.import_module('session_agent');self.clock=[0];self.sent=[];self.ends=[];self.probes=[]
 def request(self,op,seq):return w.encode(dict(v=1,run='cal-test',seq=seq,op=op))
 def run_agent(self,frames,probe=None,receive=None,send=None):
  incoming=iter(frames)
  def receive_default(deadline):return next(incoming,b'')
  def probe_default():self.probes.append('probe');return {'probes':[1,2,3]}
  return self.a.serve('cal-test',receive or receive_default,send or self.sent.append,probe or probe_default,
      identity=lambda:{'pid':123,'start_ticks':45,'uid':1001},metrics=lambda:{'cpu_ns':int(self.clock[0]*100)},
      ended=self.ends.append,clock=lambda:self.clock[0],lifetime=70)
 def test_two_probes_close_and_receipt_once(self):
  self.run_agent([self.request('PRE',1),self.request('POST',2),self.request('CLOSE',3)])
  self.assertEqual(len(self.probes),2);self.assertEqual(len(self.sent),4)
  for seq,op in enumerate(('READY','PRE','POST','CLOSE')):w.reply(self.sent[seq],'cal-test',seq,op)
  self.assertEqual(len(self.ends),1);self.assertEqual(self.ends[0]['status'],'CLOSED')
 def test_eof_before_close_is_failure_and_no_extra_probe(self):
  with self.assertRaises(ValueError):self.run_agent([self.request('PRE',1)])
  self.assertEqual(len(self.probes),1);self.assertEqual(self.ends[0]['status'],'FAILED')
 def test_wrong_order_poisoned_before_work(self):
  with self.assertRaises(ValueError):self.run_agent([self.request('POST',2)])
  self.assertEqual(self.probes,[]);self.assertEqual(self.ends[0]['status'],'FAILED')
 def test_probe_failure_no_success_reply(self):
  def bad():raise RuntimeError('controlled probe failure')
  with self.assertRaises(RuntimeError):self.run_agent([self.request('PRE',1)],probe=bad)
  self.assertEqual(len(self.sent),1);self.assertEqual(self.ends[0]['status'],'FAILED')
 def test_original_lifetime_not_reset_by_frames(self):
  frames=iter([self.request('PRE',1),self.request('POST',2)])
  def receive(deadline):
   self.assertEqual(deadline,70);self.clock[0]+=36;return next(frames)
  with self.assertRaises(TimeoutError):self.run_agent([],receive=receive)
  self.assertEqual(len(self.probes),1);self.assertEqual(self.ends[0]['status'],'FAILED')
 def test_probe_crossing_deadline_cannot_return_success(self):
  def late():self.clock[0]=70;return {'probes':[]}
  with self.assertRaises(TimeoutError):self.run_agent([self.request('PRE',1)],probe=late)
  self.assertEqual(len(self.sent),1);self.assertEqual(self.ends[0]['status'],'FAILED')
 def test_clock_rollback_and_nonfinite_fail_closed(self):
  for value in (-1,float('nan')):
   self.clock[0]=0;self.sent=[];self.ends=[]
   def receive(deadline):self.clock[0]=value;return self.request('PRE',1)
   with self.assertRaises(ValueError):self.run_agent([],receive=receive)
   self.assertEqual(self.ends[0]['status'],'FAILED')
 def test_send_failure_still_records_failed_end(self):
  def fail(wire):raise BrokenPipeError('closed peer')
  with self.assertRaises(BrokenPipeError):self.run_agent([],send=fail)
  self.assertEqual(self.ends[0]['status'],'FAILED')

if __name__=='__main__':unittest.main(verbosity=2)
