import importlib,importlib.util,pathlib,sys,tempfile,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
class FileTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('session_files'),'bounded IPC files missing')
  self.m=importlib.import_module('session_files');self.temp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.temp.name)
 def tearDown(self):
  if hasattr(self,'temp'):self.temp.cleanup()
 def test_publish_read_exact_once(self):
  self.m.publish(self.root,'request-1',b'{"v":1}\n')
  self.assertEqual(self.m.read(self.root,'request-1'),b'{"v":1}\n')
  with self.assertRaises(FileExistsError):self.m.publish(self.root,'request-1',b'{"v":2}\n')
 def test_partial_file_is_not_ready(self):
  (self.root/'request-1.json').write_bytes(b'{')
  self.assertIsNone(self.m.read(self.root,'request-1'))
 def test_missing_or_oversized_ready_payload_is_failure(self):
  (self.root/'reply-1.ready').touch()
  with self.assertRaises(FileNotFoundError):self.m.read(self.root,'reply-1')
  (self.root/'reply-1.json').write_bytes(b'a'*8193)
  with self.assertRaises(ValueError):self.m.read(self.root,'reply-1')
 def test_path_escape_and_unexpected_slot_rejected(self):
  for slot in ('../x','request-0','request-4','reply-4','config',''):
   with self.assertRaises(ValueError):self.m.read(self.root,slot)
 def test_invalid_frame_is_never_published(self):
  with self.assertRaises(ValueError):self.m.publish(self.root,'reply-0',b'{}')
  self.assertEqual(list(self.root.iterdir()),[])
if __name__=='__main__':unittest.main(verbosity=2)
