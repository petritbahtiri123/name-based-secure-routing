"""Portable validation of emitted remote code and exact process identities."""
import importlib,importlib.util,json,pathlib,sys,unittest
H=pathlib.Path(__file__).resolve().parents[1]
sys.path[:0]=[str(H/'src'),str(H/'cells/controller')]

class RemoteTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('session_remote'),'remote session implementation missing')
  self.m=importlib.import_module('session_remote')
 def test_proc_stat_handles_spaces_and_parentheses(self):
  tail=['S','1','23','23']+['0']*15+['98765']+['0']*30
  self.assertEqual(self.m.parse_stat('42 (python ) child) '+' '.join(tail)),dict(pid=42,pgrp=23,start_ticks=98765))
 def test_bad_process_identity_refused(self):
  for text in ('','42 (x) S 1','0 (x) '+' '.join(['S']+['1']*45)):
   with self.subTest(text=text),self.assertRaises(ValueError):self.m.parse_stat(text)
 def test_receipt_requires_all_probe_groups_gone(self):
  identity=dict(pid=10,pgrp=10,start_ticks=11,uid=1001,gid=1001)
  records=[dict(pid=20,pgrp=20,start_ticks=21,exit=0,group_empty=False)]
  with self.assertRaises(ValueError):self.m.validate_end(dict(run='fixture-test',status='CLOSED',requests=3,probe_calls=2,identity=identity,probe_cleanup=records),'fixture-test')
 def test_payload_uses_identical_clock_code_and_finite_timeout(self):
  self.assertIsNotNone(importlib.util.find_spec('session_payload'),'payload implementation missing')
  p=importlib.import_module('session_payload');import internal_clock
  value=p.bundle('fixture-test');compile(value,'emitted-session','exec')
  self.assertIn(repr(internal_clock.payload()),value)
  command=p.command('fixture-test')
  self.assertEqual(command[:-1],p.SSH_PREFIX)
  self.assertIn('timeout --kill-after=2s 70s python3 -u -B -c ',command[-1])
  self.assertLess(sum(map(len,command)),28000)

if __name__=='__main__':unittest.main(verbosity=2)
