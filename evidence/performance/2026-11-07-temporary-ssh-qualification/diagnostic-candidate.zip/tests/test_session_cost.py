import importlib,importlib.util,pathlib,sys,unittest
H=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(H/'src'))
class CostTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('session_cost'),'impact gate missing')
  self.m=importlib.import_module('session_cost')
  self.a=dict(before_ns=0,after_ns=1000,cpu_100ns=0,monitor_cpu_ns=0,peak_job_memory_bytes=10)
  self.b=dict(before_ns=10_000_001_000,after_ns=10_000_002_000,cpu_100ns=10000,monitor_cpu_ns=10000,peak_job_memory_bytes=10)
  self.pre=dict(after=dict(monotonic_ns=0,cpu_ns=0,peak_rss_bytes=10))
  self.post=dict(before=dict(monotonic_ns=12_000_000_000,cpu_ns=10000,peak_rss_bytes=10))
 def check(self,post=3):return self.m.assess(self.a,self.b,self.pre,self.post,pre_seconds=9,post_seconds=post,terminal_peak_bytes=10)
 def test_finite_idle_screen_passes(self):self.assertEqual(self.check()['status'],'PASS_FINITE_IDLE_SCREEN')
 def test_post_at_original_deadline_cannot_pass(self):
  with self.assertRaises(ValueError):self.check(10)
 def test_predeclared_headroom_not_loosened(self):
  with self.assertRaises(ValueError):self.check(5.01)
 def test_idle_cpu_over_threshold_stops(self):
  self.b['cpu_100ns']=2_000_000
  with self.assertRaises(ValueError):self.check()
 def test_counter_rollback_refused(self):
  self.b['monitor_cpu_ns']=-1
  with self.assertRaises(ValueError):self.check()
if __name__=='__main__':unittest.main(verbosity=2)
