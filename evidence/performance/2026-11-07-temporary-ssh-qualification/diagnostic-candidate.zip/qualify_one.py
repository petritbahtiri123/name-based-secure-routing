"""One preregistered management-only session. Does not start NBSR workloads."""
import hashlib,json,pathlib,sys,time,traceback
H=pathlib.Path(__file__).resolve().parent;C=H/'cells/controller'
sys.path[:0]=[str(H/'src'),str(C)]
from activate import activate
activate()
import resource_boundary,session_adapter
from session_cost import assess

def main(label):
    if label not in ('q1','q2'):raise ValueError('at most two declared sessions')
    pins=json.loads((H/'qualification-inputs.json').read_bytes())
    if pins['review_status']!='READY_FOR_MANAGEMENT_QUALIFICATION':raise ValueError('review gate')
    for name,digest in pins['files'].items():
        if hashlib.sha256((H/name).read_bytes()).hexdigest()!=digest:raise ValueError('qualification source changed: '+name)
    if label=='q2' and json.loads((H/'management/q1/qualification.json').read_bytes())['status']!='PASS':raise ValueError('q1 must pass first')
    here=H/'management'/label;here.mkdir(parents=True,exist_ok=False)
    run='nbsr-cal-20261107-'+label;owner=None;error=None;remote=None;cost=None;raw={}
    counts=resource_boundary.check(starting=True)
    (here/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
    try:
        owner=session_adapter.create(here,run)
        pre=session_adapter.pre(owner,here);first=owner.sample()
        # No cached accounting: retain full fresh resource guards throughout.
        idle_end=time.monotonic()+10.05
        while time.monotonic()<idle_end:
            owner.guard()
            if owner.failure or owner.done.is_set():raise RuntimeError('session failed during idle')
            time.sleep(.02)
        last=owner.sample()
        post=owner.client().exchange('POST')
        session_adapter.save_calibration(here/'calibration-after.json',post)
        owner.close();session_adapter.internal_exchange.validate_pair(here)
        before=json.loads((owner.root/'pre-admission.json').read_bytes());after=json.loads((owner.root/'post-admission.json').read_bytes())
        raw=dict(first=first,last=last,pre=pre,post=post,pre_admission=before,post_admission=after)
        (here/'cost-inputs.json').write_text(json.dumps(raw,indent=2))
        terminal=owner.receipt()['last_sample'];raw['terminal_sample']=terminal
        (here/'cost-inputs.json').write_text(json.dumps(raw,indent=2))
        cost=assess(first,last,pre,post,pre_seconds=before['completed']-before['started'],post_seconds=after['completed']-after['started'],terminal_peak_bytes=terminal['peak_job_memory_bytes'])
    except BaseException as e:
        error=dict(type=type(e).__name__,message=str(e),traceback=traceback.format_exc(limit=16))
        if owner is not None:owner.abort('management qualification failed')
    finally:
        closed=owner is not None and owner.wait_closed(2)
        if owner is not None and owner.started is not None:
            try:remote=session_adapter.verify_remote(here,run,owner.deadline)
            except BaseException as e:
                (here/'remote-inspection-error.json').write_text(json.dumps(dict(type=type(e).__name__,message=str(e))))
                if error is None:error=dict(type=type(e).__name__,message=str(e))
        status='PASS' if error is None and closed and remote is not None and cost is not None else 'STOP_INVALID_OR_UNQUALIFIED'
        result=dict(status=status,run=run,error=error,local_closed=closed,remote_closed=remote is not None,cost=cost,benchmark_workloads=0)
        (here/'qualification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
    if status!='PASS':raise RuntimeError('qualification stopped; no replacement session or benchmark')

if __name__=='__main__':main(sys.argv[1])
