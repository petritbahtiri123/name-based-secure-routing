"""Emitted isolated Linux test: lose parent near deadline, no NBSR workload."""
import json,os,signal,subprocess,time
from session_remote import probe_wrapper,process_identity,group_exists

def run_fixture():
    start=time.monotonic();helper_end=start+.5;absolute_end=helper_end+2
    wrapper=probe_wrapper('import time;time.sleep(30)',helper_end)
    helper='import subprocess,time\np=subprocess.Popen('+repr(['python3','-u','-B','-c',wrapper])+',start_new_session=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\nprint(p.pid,flush=True)\ntime.sleep(30)\n'
    p=subprocess.Popen(['python3','-u','-B','-c',helper],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    identity=None;observed_exit=None;absent=None
    try:
        pid=int(p.stdout.readline(64));identity=process_identity(pid)
        # A helper with .5s of its original lifetime left starts the probe,
        # then dies abruptly; only the probe's independent deadline remains.
        p.kill();p.wait(timeout=1)
        while time.monotonic()<absolute_end+1:
            try:
                current=process_identity(pid)
                state=open('/proc/'+str(pid)+'/stat').read().rsplit(')',1)[1].split()[0]
                if state=='Z' or current['start_ticks']!=identity['start_ticks']:
                    observed_exit=observed_exit or time.monotonic()
            except FileNotFoundError:
                observed_exit=observed_exit or time.monotonic()
                if not group_exists(pid):absent=time.monotonic();break
            time.sleep(.01)
        if observed_exit is None or observed_exit>absolute_end+.15 or absent is None:raise RuntimeError('absolute watchdog or exact group cleanup failed')
        return dict(status='PASS_PARENT_LOSS_ABSOLUTE_EXPIRY',helper_exit=p.returncode,probe_identity=identity,
            absolute_deadline_seconds=absolute_end-start,exit_observed_seconds=observed_exit-start,
            group_absent_seconds=absent-start,observation_poll_seconds=.01,observation_allowance_seconds=.15,
            limitation='The .15s allowance is observation scheduling only; watchdog deadline remains original70+2 mapping, not extended.',endpoint_workloads=0)
    finally:
        if p.poll() is None:p.kill();p.wait(timeout=1)
        for stream in (p.stdout,p.stderr):stream.close()

if __name__=='__main__':print(json.dumps(run_fixture()),flush=True)
