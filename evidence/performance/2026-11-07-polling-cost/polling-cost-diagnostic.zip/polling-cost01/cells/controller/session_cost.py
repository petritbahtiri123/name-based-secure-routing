"""Predeclared finite idle-cost and POST headroom screen, not a capacity claim."""
import math

def assess(a,b,pre,post,*,pre_seconds,post_seconds,terminal_peak_bytes):
    def finite(value):
        if type(value) not in (int,float) or not math.isfinite(value):raise ValueError('finite cost measurement')
        return value
    def delta(x,y):
        d=finite(y)-finite(x)
        if d<0:raise ValueError('measurement counter rollback')
        return d
    # Conservative denominator excludes both sampling-call brackets.
    local_ns=delta(a['after_ns'],b['before_ns'])
    remote_ns=delta(pre['after']['monotonic_ns'],post['before']['monotonic_ns'])
    if min(local_ns,remote_ns)<10_000_000_000:raise ValueError('idle observation shorter than10s')
    result=dict(local_idle_seconds=local_ns/1e9,remote_idle_seconds=remote_ns/1e9,
        job_cpu_fraction=delta(a['cpu_100ns'],b['cpu_100ns'])*100/local_ns,
        monitor_cpu_fraction=delta(a['monitor_cpu_ns'],b['monitor_cpu_ns'])/local_ns,
        remote_cpu_fraction=delta(pre['after']['cpu_ns'],post['before']['cpu_ns'])/remote_ns,
        job_peak_bytes=max(finite(a['peak_job_memory_bytes']),finite(b['peak_job_memory_bytes']),finite(terminal_peak_bytes)),
        remote_peak_bytes=max(finite(pre['after']['peak_rss_bytes']),finite(post['before']['peak_rss_bytes']),finite(post.get('after',post['before'])['peak_rss_bytes'])),
        pre_seconds=finite(pre_seconds),post_seconds=finite(post_seconds))
    if not 0<=pre_seconds<=13 or not 0<=post_seconds<=5:raise ValueError('PRE13s/POST5s promotion screen')
    if any(result[k]>.01 for k in ('job_cpu_fraction','monitor_cpu_fraction','remote_cpu_fraction')):raise ValueError('added idle CPU exceeds1% onecore')
    if result['job_peak_bytes']>128*1024**2 or result['remote_peak_bytes']>32*1024**2:raise ValueError('session memory screen')
    result.update(status='PASS_FINITE_IDLE_SCREEN',control='No retained SSH ownership after old cold PRE; added cost compared with zero owned idle processes.',limitation='Two finite management observations, not proof of zero workload impact or maximum capacity.')
    return result
