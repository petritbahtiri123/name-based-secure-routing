"""Clamp an intentional polling sleep to an existing absolute deadline."""
import time

def bounded_pause(cap,deadline,*,clock=time.monotonic,sleeper=time.sleep):
    remaining=deadline-clock()
    if remaining>0:sleeper(min(cap,remaining))
