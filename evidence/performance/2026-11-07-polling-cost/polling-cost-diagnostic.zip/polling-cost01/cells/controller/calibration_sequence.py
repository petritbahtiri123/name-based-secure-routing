"""Additional fail-closed time budget; original endpoint/cleanup limits remain."""
import time
class Window:
    def __init__(self,anchor,clock=time.monotonic):
        self.anchor=anchor;self.clock=clock;self.phase_end=anchor+78;self.end=anchor+88
    def admit_pre(self):
        if not 0<=self.clock()-self.anchor<=15:raise TimeoutError('pre calibration/startup budget')
    def check_work(self):
        if self.clock()>=self.phase_end:raise TimeoutError('calibration workload phase budget')
    def post_budget(self):
        self.check_work()
        return min(10,self.end-self.clock())
    def finish(self):
        if self.clock()>=self.end:raise TimeoutError('calibration wall budget')
