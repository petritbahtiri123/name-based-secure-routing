"""Exact Job lifetime owner for one finite calibration connection."""
import ctypes,json,math,pathlib,sys,threading,time
from draining_owner import DrainingOwner
from consoleless_backend import ConsolelessBackend
from scripts.performance.windows_job_backend import Accounting,ExtendedLimits
from session_wire import encode,decode,run_id
from session_files import publish,read
from session_client import Client

class SessionJobOwner(DrainingOwner):
    def signal(self,name):
        if name!='KILL':return super().signal(name)
        if self.process is not None and not self.killed:
            self.backend.terminate(self.job,self.process,self.assigned)
            self.killed=True

class OwnedSession:
    def __init__(self,root,run,command,*,guard,lifetime=88,request_seconds=10,pre_seconds=None,transport='ssh',external_cancel=None):
        pre_seconds=request_seconds if pre_seconds is None else pre_seconds
        self.root=pathlib.Path(root);self.run=run_id(run);self.command=command;self.guard=guard
        if (type(lifetime) not in (int,float) or not math.isfinite(lifetime) or not 4<lifetime<=88
                or type(request_seconds) not in (int,float) or not math.isfinite(request_seconds) or not 0<request_seconds<=10
                or type(pre_seconds) not in (int,float) or not math.isfinite(pre_seconds) or not 0<pre_seconds<=15):
            raise ValueError('finite ownership/request bounds')
        if transport not in ('ssh','local-fixture'):raise ValueError('session transport')
        self.lifetime=lifetime;self.seconds=request_seconds;self.pre_seconds=pre_seconds;self.transport=transport
        self.external_cancel=None if external_cancel is None else pathlib.Path(external_cancel)
        self.owner=None;self.thread=None;self.done=threading.Event();self.failure=None;self.final=None;self.latest=None
        self.started=None

    def _cancel_file(self,path):
        try:
            with path.open('xb'):pass
        except FileExistsError:pass

    def _fail(self,reason):
        self.failure=self.failure or reason
        if self.external_cancel is not None and self.external_cancel.parent.is_dir():
            try:self._cancel_file(self.external_cancel)
            except OSError:self.failure+='; coordinator cancellation write failed'

    def _snapshot(self,cpu_start):
        before=time.monotonic_ns();a=Accounting();m=ExtendedLimits();k=self.owner.backend.kernel
        self.owner.backend._check(k.QueryInformationJobObject(self.owner.job,1,ctypes.byref(a),ctypes.sizeof(a),None))
        self.owner.backend._check(k.QueryInformationJobObject(self.owner.job,9,ctypes.byref(m),ctypes.sizeof(m),None))
        return dict(before_ns=before,after_ns=time.monotonic_ns(),cpu_100ns=a.TotalUserTime+a.TotalKernelTime,
            active=a.ActiveProcesses,peak_job_memory_bytes=m.PeakJobMemoryUsed,monitor_cpu_ns=time.thread_time_ns()-cpu_start)

    def open_pre(self):
        if self.started is not None:raise ValueError('session cannot be restarted')
        self.root.mkdir(exist_ok=False)
        self.started=time.monotonic();self.deadline=self.started+self.lifetime
        config=dict(run=self.run,started=self.started,deadline=self.deadline,request_seconds=self.seconds,pre_seconds=self.pre_seconds,
            transport=self.transport,command=self.command)
        with (self.root/'config.json').open('x') as f:json.dump(config,f)
        publish(self.root,'request-1',encode(dict(v=1,run=self.run,seq=1,op='PRE')))
        self.owner=SessionJobOwner([sys.executable,'-B',str(pathlib.Path(__file__).with_name('session_broker.py')),str(self.root/'config.json')],
            backend=ConsolelessBackend(),cancel=lambda:self._cancel_file(self.root/'cancel'),deadline=self.deadline)
        try:
            self.guard()
            if time.monotonic()>=self.started+self.pre_seconds:raise TimeoutError('initial request before creation')
            self.owner.start()
        except BaseException as e:self._fail(type(e).__name__+': '+str(e))
        try:
            self.thread=threading.Thread(target=self._monitor,name='nbsr-session-job-owner',daemon=True);self.thread.start()
        except BaseException as e:
            self._fail('monitor startup: '+type(e).__name__)
            if self.thread is None or self.thread.ident is None:
                self.thread=None;self._monitor()
        try:
            if self.failure:raise RuntimeError(self.failure)
            value=self.client().pre()
            with (self.root/'pre-admission.json').open('x') as f:
                json.dump(dict(run=self.run,started=self.started,completed=time.monotonic(),deadline=self.started+self.pre_seconds),f)
            return value
        except BaseException:
            self.abort('PRE failed');self.wait_closed(2);raise

    def _monitor(self):
        cpu_start=time.thread_time_ns();code=None;live=self.owner.owned;reaped=False;stats=[];previous=self.started
        try:
            while self.owner.owned:
                now=time.monotonic()
                if not math.isfinite(now) or now<previous:self._fail('owner clock uncertainty')
                previous=now
                close_requested=(self.root/'request-3.ready').exists()
                if ((self.root/'cancel').exists() or (self.external_cancel is not None and self.external_cancel.exists())):
                    self._fail('session cancelled')
                if now>=self.deadline-(.25 if close_requested else 2):self._fail('session lifetime exhausted')
                if self.failure:
                    try:self.owner.signal('KILL')
                    except BaseException as e:self._fail('owned termination: '+type(e).__name__)
                try:
                    code,live=self.owner.observe()
                    if code is not None and code!=0:
                        self._fail('broker nonzero exit')
                        if live:self.owner.signal('KILL')
                    if code is not None and not live:
                        if not self.failure:
                            if self.owner.job is not None:self.latest=self._snapshot(cpu_start)
                            wire=read(self.root,'broker-final')
                            broker=None if wire is None else decode(wire)
                            if (not broker or broker.get('status')!='CLOSED' or broker.get('run')!=self.run
                                    or broker.get('responses')!=4 or broker.get('ssh_exit')!=0 or broker.get('readers_stopped') is not True):
                                self._fail('broker terminal receipt not complete')
                        self.owner.reap();reaped=True
                        break
                    if self.owner.job is not None and not self.failure:self.latest=self._snapshot(cpu_start)
                except BaseException as e:
                    self._fail(type(e).__name__+': '+str(e))
                    try:self.owner.signal('KILL')
                    except BaseException as kill_error:self._fail('owned termination: '+type(kill_error).__name__)
                if now>=self.deadline:break
                time.sleep(.02)
            if self.owner.owned:self._fail('owned cleanup unconfirmed at original deadline')
            elapsed=time.monotonic()-self.started
            if elapsed>=self.lifetime:self._fail('original session lifetime exceeded')
            self.final=dict(run=self.run,status='CLOSED' if not self.failure and reaped else 'FAILED',failure=self.failure,
                exit_code=code,owned_handles=self.owner.owned,leader_reaped=reaped,group_exit_observed=not live,
                elapsed_seconds=elapsed,drain_failure=self.owner.drain_failure,job_drain=self.owner.drain_events,
                last_sample=self.latest,monitor_cpu_ns=time.thread_time_ns()-cpu_start)
            publish(self.root,'ownership-final',encode(self.final))
        except BaseException as e:
            self._fail('owner monitor failure: '+type(e).__name__)
            try:self.owner.signal('KILL')
            except BaseException:pass
        finally:self.done.set()

    def client(self):return Client(self.root,self.run,guard=self.guard)

    def sample(self):
        begin=time.monotonic_ns();limit=time.monotonic()+.5
        while time.monotonic()<limit:
            if self.failure or self.done.is_set():raise RuntimeError('cannot sample inactive/failed session')
            value=self.latest
            if value is not None and value['before_ns']>=begin:return dict(value)
            time.sleep(.005)
        raise TimeoutError('fresh Job statistics unavailable')

    def close(self):
        if self.done.is_set():
            if self.final is None or self.final['status']!='CLOSED':raise RuntimeError('session failed')
            return self.final
        self.client().exchange('CLOSE')
        if not self.wait_closed(2) or self.final['status']!='CLOSED':raise RuntimeError('session close unconfirmed')
        return self.final

    def abort(self,reason):
        if self.done.is_set() or self.started is None:return
        self._cancel_file(self.root/'cancel')

    def wait_closed(self,seconds):
        if self.started is None:return True
        if not self.done.wait(seconds):return False
        if self.thread is not None:self.thread.join(timeout=.1)
        return self.owner is not None and not self.owner.owned and (self.thread is None or not self.thread.is_alive())

    def receipt(self):
        if self.final is None:raise RuntimeError('missing ownership receipt')
        return self.final
