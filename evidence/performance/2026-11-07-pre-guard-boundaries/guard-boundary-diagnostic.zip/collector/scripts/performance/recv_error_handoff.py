"""Explicit coordinator-to-endpoint binding for the reviewed error diagnostic."""
from pathlib import PurePosixPath
from scripts.performance.linux_b5_ceiling import require
from scripts.performance.recv_error_collection import declaration,workload

def validate_config(config):
    keys=('recv_errors_run','recv_errors_mode')
    if not any(k in config for k in keys):return None
    require(all(k in config for k in keys),'paired receive-error activation required')
    decl=declaration(config[keys[0]],config[keys[1]])
    require(decl is not None and 'correlation_run' not in config,'conflicting diagnostic activation')
    require(config.get('post_close_reports') is True,'receive-error cleanup required')
    require(not any(config.get(k) for k in ('paired_live_guards','source_live_guard','diagnostic_seconds')),'conflicting observer/duration')
    for role in ('source','destination'):
        workload(dict(path=config['path'],cores=config[role]['cores'],payload_bytes=config['payload'],streams=config['streams'],outstanding=config['depth'],benchmark_seconds=config['benchmark_seconds'],origin_record=True,diagnostic_rate=config['diagnostic_rate']))
    return decl

def collector_config(config):
    decl=validate_config(config)
    if decl is None:return None
    result=dict(decl)
    for role,name in [('source','perf_rust_source'),('destination','wp8_interop_server')]:
        for key in ('output','authority'):result[role+'_'+key]=config[role][key]
        result[role+'_executable']=str(PurePosixPath(config[role]['binaries'])/name)
    return result

def require_finalizer(config,callback):
    active=validate_config(config)
    require((active is None and callback is None) or (active is not None and callable(callback)),'receive-error finalizer/activation mismatch')

def finish(config,output,result,endpoints,callback):
    require_finalizer(config,callback)
    if callback is None:return
    callback(output,result)
    value=result.get('recv_errors')
    require(isinstance(value,dict) and value.get('vm_qualified') is False,'receive-error finalization missing')
    require(value['diagnostic']['mode']==config['recv_errors_mode'],'receive-error final mode')
    for role in ('source','destination'):
        require(value['collection_receipts'][role]['index_sha256']==endpoints[role]['index_sha256'],'receive-error captured/live index mismatch')
