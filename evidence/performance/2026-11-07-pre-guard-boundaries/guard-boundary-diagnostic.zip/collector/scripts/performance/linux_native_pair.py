"""Read-only integrity/join gate for transferred finite native peer evidence.

Checksums detect corruption; they are not signatures or remote attestation.
This gate neither authenticates a host nor classifies sustainable capacity.
"""

import argparse
from scripts.performance import native_debug_correctness as debug
import json
import math
from pathlib import Path, PurePosixPath
import re

from scripts.performance.linux_native_duration import bounds
from scripts.performance.linux_b5_ceiling import require
NAMES={'direct':'perf_direct_peer','nbsr':'perf_rust_source','server':'wp8_interop_server'}
from scripts.performance.linux_loopback import digest, validate_matrix
from scripts.performance.linux_native_peer import measurement_contract, validate_endpoint, validate_fixed_work, validate_post_close
from scripts.performance.p2a_established import validate_repeat
from scripts.performance.linux_native_paced import read_paced
from scripts.performance.linux_native_source_observer import replay, read_records, validate_resource


def read(root, name):
    return json.loads((root / name).read_bytes())


def verify_index(root):
    require(not root.is_symlink(), 'symlink evidence root')
    root = root.resolve()
    files = set()
    for path in root.rglob('*'):
        require(not path.is_symlink(), 'symlink evidence entry')
        if path.is_file() and path.name != 'checksums.sha256':
            files.add(path.relative_to(root).as_posix())
        elif path.is_file() and path.parent != root:
            files.add(path.relative_to(root).as_posix())
    indexed = set()
    for line in (root / 'checksums.sha256').read_text().splitlines():
        expected, separator, name = line.partition('  ')
        relative = PurePosixPath(name)
        require(separator and re.fullmatch('[0-9a-f]{64}', expected)
                and name and not relative.is_absolute() and '..' not in relative.parts
                and '\\' not in name and ':' not in name and relative.as_posix() == name
                and name not in indexed and name != 'checksums.sha256', 'invalid/duplicate checksum entry')
        path = (root / name).resolve()
        require(path.is_relative_to(root) and path.is_file() and digest(path) == expected,
                'checksum mismatch: ' + name)
        indexed.add(name)
    require(indexed == files and indexed, 'checksum index is not a complete inventory')
    return digest(root / 'checksums.sha256')


def correlation_overrides(role, cell, output_root, config):
    if config is None:
        return {}
    from scripts.performance.correlation_handoff import validate_config
    from scripts.performance.correlation_collection import NAMES as SIDECARS
    run = validate_config(config)
    require(run is not None, 'explicit correlation configuration required')
    expected_cell = dict(path=config['path'], payload_bytes=config['payload'],
        streams=config['streams'], outstanding=config['depth'], cores=config[role]['cores'],
        benchmark_seconds=config['benchmark_seconds'], diagnostic_rate=config['diagnostic_rate'],origin_record=True)
    require(cell == expected_cell, 'correlation cell mismatch')
    endpoint = PurePosixPath(config[role]['output'])
    require(endpoint.is_absolute() and '..' not in endpoint.parts
            and str(endpoint) == config[role]['output'], 'invalid correlation output pin')
    expected_root = endpoint / 'peer'
    require(output_root == str(expected_root), 'correlation output pin mismatch')
    return {'NBSR_CORRELATION_RUN': run,
            'NBSR_CORRELATION_FILE': str(expected_root / SIDECARS[role][0])}


def check_peer(root, role, source_sha, *, debug_correctness_manifest_sha256=None, correlation_config=None, recv_errors_config=None):
    pin = debug.validate_pin(debug_correctness_manifest_sha256)
    index = verify_index(root)
    require(not any((root / n).exists() for n in ('failure.json', 'forced-cleanup.json')),
            'failed/forced peer cannot be accepted')
    env, result, build = (read(root, n) for n in ('environment.json', 'result.json', 'build-manifest.json'))
    require(env['role'] == result['role'] == role and env['repository_sha'] == source_sha,
            'peer role/source mismatch')
    cell = env['cell']
    require(cell['path'] in ('direct','nbsr'), 'matched release path')
    validate_matrix(dict(schema='nbsr-linux-loopback-v1', cores=[cell['cores']],
        workloads=[{k: cell[k] for k in ('payload_bytes', 'streams', 'outstanding')}],
        warmup_seconds=3, duration_seconds=20))
    warmup, duration = measurement_contract(cell)
    require(env['warmup_seconds'] == warmup and env['duration_seconds'] == duration, 'finite measurement mode mismatch')
    debug.validate_build(build, source_sha, env['binary_sha256'], pin)
    require(env.get(debug.FIELD) == pin and result.get(debug.FIELD) == pin, 'debug mode mismatch')
    debug.validate_workload(cell, env.get('post_close_reports', False), pin)
    if pin is not None:
        require(all(env.get(k) == v and result.get(k) == v for k, v in debug.qualification(pin).items())
                and 'application_gbps' not in result, 'debug benchmark claim rejected')
    require(set(env['binary_sha256']) == set(NAMES.values())
            and all(re.fullmatch('[0-9a-f]{64}', h) for h in env['binary_sha256'].values()),
            'invalid binary hashes')
    certs = env['certificates_sha256']
    require(set(certs) == {'ca.der', role + '.der'}
            and all(re.fullmatch('[0-9a-f]{64}', h) for h in certs.values()), 'invalid certificate hashes')
    name = NAMES['direct'] if cell['path'] == 'direct' else NAMES['nbsr' if role == 'source' else 'server']
    receipt=read(root,'executed-binary.json')
    require(receipt['sha256']==env['binary_sha256'][name] and receipt['bytes']==build['binary_sizes'][name] and receipt['proc_exe_verified'] is True, 'executed binary receipt mismatch')
    command = read(root, 'command.json')
    argv = command['argv']
    cpus = env['linux_environment']['selected_cpus']
    require(len(cpus) == cell['cores'] and len(set(cpus)) == len(cpus), 'CPU pool mismatch')
    require(len(argv) > 4 and PurePosixPath(argv[0]).name == 'taskset'
            and argv[1:3] == ['--cpu-list', ','.join(map(str, cpus))]
            and PurePosixPath(argv[3]).name == name, 'executable/affinity command mismatch')
    def option(key, expected):
        require(argv.count(key) == 1 and argv.index(key) + 1 < len(argv)
                and argv[argv.index(key) + 1] == str(expected), 'command mismatch: ' + key)
    option('--p2a-runtime-workers', cell['cores'])
    paced = 'diagnostic_rate' in cell
    paired_live = env.get('paired_live_guards', False)
    require(type(paired_live) is bool and (not paired_live or (paced
            and not env.get('live_socket_observer', False))), 'invalid paired live mode')
    observed = env.get('source_live_guard', False)
    require(not paired_live or observed == (role == 'source'), 'paired source observer mismatch')
    require(type(observed) is bool and (not observed or (role == 'source' and paced
            and not env.get('live_socket_observer', False))), 'invalid source observer mode')
    if observed:
        require(result.get('source_live_guard') == replay(root, payload_bytes=cell['payload_bytes'], diagnostic_seconds=cell.get('diagnostic_seconds')),
                'source live guard summary mismatch')
    else:
        require('source_live_guard' not in result and not any((root / name).exists() for name in
                ('live-events.ndjson', 'live-observed-stdout', 'live-result.json')), 'undeclared source live observer')
    if paired_live and role == 'destination':
        samples = list(read_records(root / 'destination-live-resources.ndjson', bounds(cell.get('diagnostic_seconds'))['resources']))
        previous = None
        for sample in samples:
            require(sample.get('role') == 'destination', 'owned destination resource role mismatch')
            validate_resource(root, sample, previous)
            previous = sample
        report = result.get('destination_live_resources', {})
        require(samples and report.get('resource_collection_complete') is True
                and type(report.get('samples')) is int and report['samples'] == len(samples),
                'destination resource collection incomplete')
    else:
        require('destination_live_resources' not in result
                and not (root / 'destination-live-resources.ndjson').exists(), 'undeclared destination resources')
    if paced:
        require(env.get('post_close_reports') is True and env.get('phase_control_endpoint') is None,
                'paced mode requires reports without phase observer')
    paced_flags = ('--p2a-groups', '--p2a-progress-seconds', '--b5-rate-numerator', '--b5-rate-denominator')
    if paced and role == 'source':
        option('--b5-diagnostics', 0)
        option('--b5-boundary-pairs', 0)
        require('--b5-timer-cpu' not in argv, 'uniform CPU0 arm')
        option('--b5-runtime-cpu-clock', 0)
        option('--b5-origin-record', 1)
        require(cell.get('origin_record') is True, 'origin measurement declaration')
        for flag, value in zip(paced_flags, (1, 1, *cell['diagnostic_rate'])):
            option(flag, value)
    elif cell.get('benchmark_seconds')==300 and role=='source':
        option('--p2a-progress-seconds',1)
        require(not any(flag in argv for flag in ('--p2a-groups','--b5-rate-numerator','--b5-rate-denominator')),'undeclared pacing')
    else:
        require(not any(flag in argv for flag in paced_flags), 'undeclared paced command')
    phase_control = env.get('phase_control_endpoint')
    if phase_control is not None:
        require(role == 'source' and validate_endpoint(phase_control, allow_zero=False)[0] == '127.0.0.1',
                'invalid phase control endpoint')
        option('--p2a-counter-control', phase_control)
    else:
        require('--p2a-counter-control' not in argv, 'undeclared phase observer')
    option('--benchmark-client-bind' if role == 'source' else '--benchmark-listen', env['bind'])
    validate_endpoint(env['bind'], allow_zero=True)
    overrides = {'NBSR_P2A_STREAMS': str(cell['streams'])} if role == 'destination' and cell['path'] == 'nbsr' else {}
    overrides.update(correlation_overrides(role, cell, env['output_root'], correlation_config))
    from scripts.performance.recv_error_collection import overrides as recv_overrides
    declared = None if recv_errors_config is None else {k:recv_errors_config[k] for k in ('run','mode')}
    overrides.update(recv_overrides(role, cell, env['output_root'], declared))
    require(command['environment_overrides'] == overrides, 'experiment overrides mismatch')
    if role == 'source':
        for key, value in {'--endpoint': env['endpoint'], '--payload-bytes': cell['payload_bytes'],
                '--p2a-streams': cell['streams'], '--p2a-outstanding-per-stream': cell['outstanding'],
                '--p2a-warmup-seconds': warmup}.items():
            option(key, value)
        if duration is None:
            option('--p2a-operations-per-stream', cell['operations_per_stream'])
            require('--p2a-duration-seconds' not in argv, 'fixed workload also specifies duration')
        else:
            option('--p2a-duration-seconds', duration)
            require('--p2a-operations-per-stream' not in argv, 'timed workload also specifies operations')
    elif cell['path'] == 'direct':
        option('--p2a-streams', cell['streams'])
    exit_record, pid = read(root, 'exit.json'), read(root, 'pid.json')
    requested = env.get('post_close_reports', False)
    cleanup = validate_post_close(root, cell, role, pid['pid'], requested)
    if requested and cell['path'] == 'nbsr':
        original = PurePosixPath(env['output_root'])
        require(original.is_absolute() and '..' not in original.parts, 'invalid original output root')
        option('--p2a-cleanup-report', str(original / 'cleanup.json'))
    else:
        require('--p2a-cleanup-report' not in argv, 'undeclared cleanup observer')
    require(result.get('runtime_ownership_cleanup', 'NOT_MEASURED') == cleanup, 'cleanup claim mismatch')
    require(result['status'] == debug.status('PASS_FINITE_PEER', pin) and result['exit_code'] == exit_record['exit_code'] == 0
            and result['final_sample'] == exit_record['final_sample'] and pid['owns_process_group'] is True,
            'peer exit contract failed')
    first = previous = last = first_sample = None
    from scripts.performance.timer_identity import offline_context, validate_record
    affinity_context = offline_context(root)
    with (root / 'resources.ndjson').open() as stream:
        for line in stream:
            sample = json.loads(line)
            validate_record(sample, affinity_context)
            first_sample = sample if first_sample is None else first_sample
            if env.get('live_socket_observer', False):
                require(type(sample.get('timestamp_ns')) is int and sample['timestamp_ns'] >= 0
                        and (last is None or sample['timestamp_ns'] >= last['timestamp_ns']),
                        'resource clock regressed or unavailable')
            identity = sample['pid'], sample['start_ticks']
            first = identity if first is None else first
            require(sample['pid'] == pid['pid'] and identity == first, 'sample PID identity mismatch')
            require(type(sample['cpu_ns']) is int and sample['cpu_ns'] >= 0
                    and (previous is None or sample['cpu_ns'] >= previous), 'CPU counter regressed')
            require(sample['affinity'] == cpus, 'sample affinity mismatch')
            require(last is None or last['state'] != 'Z', 'sample after terminal exit')
            previous, last = sample['cpu_ns'], sample
    require(last is not None and last['state'] == 'Z' and last == exit_record['final_sample'],
            'terminal sample mismatch')
    require(type(env.get('live_socket_observer', False)) is bool, 'invalid live socket observer mode')
    if env.get('live_socket_observer', False):
        from scripts.performance.linux_socket_ownership import validate_binding, validate_history
        from scripts.performance.linux_udp_failure import read_bounded
        observed = read(root, 'socket-ownership.json')
        local = observed['sockets'][0]['local']
        require(local[0] == validate_endpoint(env['bind'], allow_zero=True)[0], 'observed bind mismatch')
        validate_binding(observed, pid=last['pid'], start_ticks=last['start_ticks'], binary=argv[3], local=local)
        validate_history(observed, read_bounded(root / 'socket-observations.ndjson'),
                         resource_start_ns=first_sample['timestamp_ns'], resource_end_ns=last['timestamp_ns'])
    from scripts.performance.recv_error_collection import admit_peer
    admit_peer(root,role,env,recv_errors_config)
    return env, result, index


def analyze_pair(source, destination, *, source_sha, debug_correctness_manifest_sha256=None, correlation_config=None, recv_errors_config=None):
    pin = debug.validate_pin(debug_correctness_manifest_sha256)
    require(re.fullmatch('[0-9a-f]{40}', source_sha), 'full expected source SHA required')
    require(correlation_config is None or correlation_config.get('source_sha') == source_sha,
            'correlation source pin mismatch')
    source, destination = Path(source), Path(destination)
    require(source.resolve() != destination.resolve(), 'distinct peer roots required')
    try:
        src, result, src_index = check_peer(source, 'source', source_sha, debug_correctness_manifest_sha256=pin, correlation_config=correlation_config, recv_errors_config=recv_errors_config)
        dst, _, dst_index = check_peer(destination, 'destination', source_sha, debug_correctness_manifest_sha256=pin, correlation_config=correlation_config, recv_errors_config=recv_errors_config)
        require(src['cell'] == dst['cell'] and src['binary_sha256'] == dst['binary_sha256']
                and src.get('paired_live_guards', False) == dst.get('paired_live_guards', False)
                and src.get('post_close_reports', False) == dst.get('post_close_reports', False)
                and src.get('live_socket_observer', False) == dst.get('live_socket_observer', False)
                and src['certificates_sha256']['ca.der'] == dst['certificates_sha256']['ca.der'],
                'peer workload/build/authority mismatch')
        ready = read(destination, 'ready.json')
        address, port = validate_endpoint(ready['endpoint'], allow_zero=False)
        require(ready == read(source, 'input-readiness.json') and ready['alpn'] == 'nbsr-quic-1'
                and address == validate_endpoint(dst['bind'], allow_zero=True)[0]
                and src['endpoint'] == ready['endpoint'] and dst['endpoint'] is None,
                'readiness/endpoint mismatch')
        if dst.get('live_socket_observer', False):
            require(any(row['local'] == [address, port]
                        for row in read(destination, 'socket-ownership.json')['sockets']),
                    'destination readiness socket was not observed')
        cell = src['cell']
        row = read(source, 'validated-result.json')
        extra = {}
        if 'diagnostic_rate' in cell:
            require(row == read_paced(source / 'stdout', cell), 'paced source summary mismatch')
            extra = dict(workload_mode='PACED_DIAGNOSTIC', achieved_offered_ratio=row['achieved_offered_ratio'],
                         drift_failures=row['drift_failures'], live_private_growth='NOT_MEASURED')
            if src.get('source_live_guard', False):
                extra.update(live_private_growth='SOURCE_ONLY_DIAGNOSTIC',
                             source_live_guard=result['source_live_guard'], destination_private_growth='NOT_MEASURED')
        else:
            require(row == json.loads((source / 'stdout').read_text().strip().splitlines()[-1])
                    and validate_repeat(row), 'source result mismatch/invalid')
        validate_fixed_work(row, cell)
        require(all(row[k] == cell[k] for k in ('path', 'payload_bytes', 'streams'))
                and row['outstanding_per_stream'] == cell['outstanding']
                and type(row['measured_ns']) is int and row['measured_ns'] > 0
                and row['completed_operations'] == result['completed_operations'], 'source workload/count mismatch')
        gbps = 16 * cell['payload_bytes'] * row['completed_operations'] / row['measured_ns']
        if pin is None:
            require(math.isclose(result['application_gbps'], gbps, rel_tol=1e-12), 'goodput arithmetic mismatch')
        else:
            extra.update(debug.qualification(pin))
        if cell['path'] == 'direct':
            require((destination / 'completion.ack').is_file(), 'missing Direct completion ACK')
        else:
            server = read(destination, 'server-result.json')
            require(server['status'] == 'PASS' and server['streams'] == cell['streams'], 'server result mismatch')
        return dict(status=debug.status('PASS_FINITE_PAIR_INTEGRITY', pin), source_sha=source_sha, cell=cell,
            source_index_sha256=src_index, destination_index_sha256=dst_index, **({'application_gbps': gbps} if pin is None else {}),
            strict_stable_capacity='NOT_PROVEN', external_hardware='NOT_PROVEN',
            observer_qualification='NOT_PROVEN', runtime_ownership_cleanup=result.get('runtime_ownership_cleanup', 'NOT_MEASURED'),
            authenticity='checksums are not signatures or remote attestation', **extra)
    except (KeyError, IndexError, TypeError, OSError) as error:
        raise ValueError('incomplete/malformed native pair: ' + str(error)) from error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--source-sha', required=True)
    parser.add_argument('--debug-correctness-manifest-sha256')
    args = parser.parse_args()
    print(json.dumps(analyze_pair(args.source, args.destination, source_sha=args.source_sha,
        debug_correctness_manifest_sha256=args.debug_correctness_manifest_sha256), indent=2))


if __name__ == '__main__':
    main()
