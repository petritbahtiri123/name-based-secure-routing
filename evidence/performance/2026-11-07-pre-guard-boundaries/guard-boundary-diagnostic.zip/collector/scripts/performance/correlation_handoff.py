"""Explicit non-secret correlation identity; never an inherited environment opt-in."""
import argparse
from scripts.performance.correlation_collection import identity
from scripts.performance.request_correlation import need


def run_id(value):
    identity(value)
    return value


def validate_config(config):
    if 'correlation_run' not in config:
        return None
    run = run_id(config['correlation_run'])
    for key, expected in dict(path='nbsr', payload=1024, streams=8, depth=1,
            benchmark_seconds=20, diagnostic_rate=[16000, 1], post_close_reports=True).items():
        need(type(config.get(key)) is type(expected) and config[key] == expected,
             'correlation workload ' + key)
    for role in ('source', 'destination'):
        need(type(config[role]['cores']) is int and config[role]['cores'] == 1,
             'correlation CPU')
    need('diagnostic_seconds' not in config, 'conflicting correlation duration')
    return run


class RunArgument(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        if getattr(namespace, self.dest, None) is not None:
            parser.error('duplicate correlation run')
        try:
            run = run_id(values)
        except ValueError:
            parser.error('invalid correlation run identity')
        setattr(namespace, self.dest, run)


def endpoint_run(args):
    run = getattr(args, 'correlation_run', None)
    if run is None:
        return None
    config = {key: getattr(args, key, None) for key in (
        'path', 'payload', 'streams', 'depth', 'benchmark_seconds',
        'diagnostic_rate', 'post_close_reports')}
    config.update(correlation_run=run, source={'cores':args.cores}, destination={'cores':args.cores})
    validate_config(config)
    need(getattr(args, 'operations_per_stream', None) is None
         and getattr(args, 'diagnostic_seconds', None) is None,
         'conflicting correlation work contract')
    return run
