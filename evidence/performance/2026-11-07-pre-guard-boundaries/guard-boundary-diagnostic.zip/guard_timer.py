"""Bounded in-memory call boundaries; no logging, worker or changed guard result."""
import threading,time
from contextlib import contextmanager

class GuardTimer:
    def __init__(self,*,clock=time.monotonic_ns,thread=threading.get_ident,limit=64):
        if type(limit) is not int or not 1<=limit<=64:raise ValueError('trace cap')
        self.clock=clock;self.thread=thread;self.thread_id=thread();self.limit=limit
        self.rows=[];self.invalid=False;self.previous=None
    def now(self):
        try:value=self.clock()
        except BaseException:self.invalid=True;raise
        if type(value) is not int or value<0 or (self.previous is not None and value<self.previous):
            self.invalid=True;raise ValueError('trace clock uncertainty')
        self.previous=value;return value
    def wrap(self,kind,fn):
        if kind not in ('guard','resource_check'):raise ValueError('fixed trace kind')
        def measured(*args,**kwargs):
            if self.invalid or self.thread()!=self.thread_id or len(self.rows)>=self.limit:
                self.invalid=True;raise RuntimeError('invalid trace, thread or record cap')
            row=dict(sequence=len(self.rows)+1,kind=kind,begin_ns=self.now(),end_ns=None,error_type=None)
            self.rows.append(row);primary=None
            try:return fn(*args,**kwargs)
            except BaseException as error:primary=error;row['error_type']=type(error).__name__;raise
            finally:
                try:row['end_ns']=self.now()
                except BaseException as clock_error:
                    self.invalid=True
                    if primary is None:raise
                    primary.add_note('Boundary recorder exit-clock failure: '+type(clock_error).__name__)
        return measured

@contextmanager
def observe_guards(owner,resource_module,timer):
    original_guard=owner.guard;original_check=resource_module.check
    try:
        resource_module.check=timer.wrap('resource_check',original_check)
        owner.guard=timer.wrap('guard',original_guard)
        yield
    finally:
        owner.guard=original_guard;resource_module.check=original_check
