"""Relate current guard intervals to local broker timestamps; no historical replay."""
import math

def analyze(events,anchor,broker,pre_status):
    if type(anchor) not in (int,float) or not math.isfinite(anchor):raise ValueError('anchor')
    origin=round(anchor*1e9);guards=[];resources=[]
    for seq,row in enumerate(events,1):
        if (row['sequence']!=seq or type(row['begin_ns']) is not int or type(row['end_ns']) is not int
                or not origin<=row['begin_ns']<=row['end_ns'] or row['error_type'] is not None):raise ValueError('incomplete/error/clock trace')
        if row['kind']=='guard':guards.append(row)
        elif row['kind']=='resource_check':resources.append(row)
        else:raise ValueError('trace kind')
    if not guards or len(guards)!=len(resources):raise ValueError('one complete resource interval per guard')
    rows=[];used=set();previous=origin
    for number,g in enumerate(guards,1):
        if g['begin_ns']<previous:raise ValueError('overlapping sequential guards')
        previous=g['end_ns'];matching=[r for r in resources if g['begin_ns']<=r['begin_ns']<=r['end_ns']<=g['end_ns']]
        if len(matching)!=1 or matching[0]['sequence'] in used:raise ValueError('resource nesting')
        r=matching[0];used.add(r['sequence']);wall=g['end_ns']-g['begin_ns'];resource=r['end_ns']-r['begin_ns']
        rows.append(dict(guard=number,phase='before_start' if number==1 else 'waiting_for_PRE',begin_s=(g['begin_ns']-origin)/1e9,
            end_s=(g['end_ns']-origin)/1e9,wall_s=wall/1e9,resource_check_s=resource/1e9,other_guard_s=(wall-resource)/1e9))
    if len(used)!=len(resources):raise ValueError('unpaired resource interval')
    stamps={}
    for e in broker:
        if type(e['monotonic']) not in (int,float) or not math.isfinite(e['monotonic']):raise ValueError('broker clock')
        key=(e['event'],e['op'],e['seq'])
        if key in stamps:raise ValueError('duplicate broker event')
        stamps[key]=e['monotonic']-anchor
    ready=stamps.get(('reply','READY',0));reply=stamps.get(('reply','PRE',1));request=stamps.get(('request','PRE',1))
    if ready is not None and ready<rows[0]['end_s']:raise ValueError('READY before owned launch')
    if reply is not None and (request is None or ready is None or not ready<=request<=reply):raise ValueError('broker PRE order')
    containing=next((r['guard'] for r in rows if reply is not None and r['begin_s']<=reply<=r['end_s']),None)
    crossing=[r['guard'] for r in rows if r['begin_s']<10<=r['end_s']]
    if pre_status=='ACCEPTED_WITHIN_ORIGINAL_PRE_WINDOW' and rows[-1]['end_s']>=10:raise ValueError('accepted after cutoff')
    if pre_status not in ('ACCEPTED_WITHIN_ORIGINAL_PRE_WINDOW','REJECTED_AT_ORIGINAL_PRE_DEADLINE'):raise ValueError('noncomparable PRE status')
    if reply is None:finding='NO_PRE_REPLY_OBSERVED'
    elif containing in crossing and pre_status=='REJECTED_AT_ORIGINAL_PRE_DEADLINE':finding='CURRENT_GUARD_CROSSED_PRE_DEADLINE_WITH_REPLY_BUFFERED'
    elif containing is not None:finding='REPLY_BUFFERED_DURING_GUARD_WITHOUT_DEADLINE_CROSSING'
    else:finding='REPLY_OUTSIDE_OBSERVED_GUARD_INTERVALS'
    total=sum(r['wall_s'] for r in rows);resources_total=sum(r['resource_check_s'] for r in rows)
    return dict(finding=finding,pre_status=pre_status,guards=rows,guard_count=len(rows),guard_total_s=total,resource_check_total_s=resources_total,
        resource_fraction_of_guard_time=resources_total/total if total else None,ready_s=ready,pre_request_s=request,pre_reply_s=reply,
        reply_inside_guard=containing,deadline_crossing_guards=crossing,
        reply_to_containing_guard_end_s=None if containing is None else rows[containing-1]['end_s']-reply,
        after_initial_guard_to_ready_s=None if ready is None else ready-rows[0]['end_s'],
        last_guard_margin_to_cutoff_s=10-rows[-1]['end_s'],
        limitations=['Current instrumented observation only; cannot reconstruct historical exit or guard times.',
            'Resource-check wall time includes traversal, its thread join and scheduling; it does not isolate disk I/O,CPU or contention.',
            'Between initial guard and READY are owned launch/client setup and the existing SSH route; this is not a packet-level network measurement.',
            'Broker uses monotonic seconds and guards use monotonic nanoseconds; conversion/float rounding is submicrosecond at this observation scale.'])
