import hashlib,json,os,pathlib,sys,time,uuid
T=pathlib.Path(__file__).resolve().parent;H=T/'pre-guard-boundaries01';C=H/'cells/controller';sys.path.insert(0,str(C))
import bounded,resource_boundary
sys.path.insert(0,str(H));from capture_admission import process_identity
pins=json.loads((H/'capture-inputs.json').read_bytes())
if pins['status']!='READY_FOR_ONE_DIAGNOSTIC_PRE':raise ValueError('capture gate')
for name,digest in pins['files'].items():
 if hashlib.sha256((H/name).read_bytes()).hexdigest()!=digest:raise ValueError('capture input changed: '+name)
if hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()!=pins['outer_runner_sha256']:raise ValueError('outer runner changed')
if (H/'capture').exists() or (H/'evidence/capture-command').exists():raise ValueError('no replacement capture')
token=uuid.uuid4().hex;who=process_identity(os.getpid());plan=json.loads((H/'plan.json').read_bytes())
with (H/'attempt.json').open('x') as f:json.dump(dict(run=plan['live']['run'],token=token,parent_pid=os.getpid(),parent_created=who['created'],created=time.monotonic(),one_attempt=True,utc=time.time(),replacement=False),f)
counts=resource_boundary.check(starting=True);(C/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
print('ONE_PRE_GUARD_BOUNDARY_CAPTURE_START; no POST or NBSR workload',flush=True)
bounded.run([sys.executable,'-u','-B',str(H/'supervised_entry.py'),token],H/'evidence/capture-command',60)
