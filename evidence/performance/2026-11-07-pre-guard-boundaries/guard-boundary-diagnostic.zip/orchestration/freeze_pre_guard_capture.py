import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;H=T/'pre-guard-boundaries01'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
parent=read(H/'parent-inputs.json')
for name,digest in parent.items():assert sha(H/name)==digest,name
for name in ('tests-final-command','meter-final-command'):
 s=read(H/'evidence'/name/'supervision.json')
 assert s['status']=='LOCAL_WORKER_COMPLETED' and not s['owned_handles'] and s['leader_reaped'] and s['group_exit_observed'] and s['drain_failure'] is None
assert 'Ran 26 tests' in (H/'evidence/tests-final-command/stderr.log').read_text()
meter=read(H/'evidence/meter-qualification-after-review.json');assert meter['status']=='PASS_FINITE_RECORDER_SCREEN' and meter['local_identity_api']['alive']
paths={H/n for n in parent}
paths.update(H.glob('*.py'));paths.update((H/'tests').glob('*.py'))
paths.update(H/n for n in ('plan.json','parent-inputs.json','evidence/meter-qualification-after-review.json','cells/controller/LIVE-DISABLED.json'))
for p in paths:
 if p.suffix=='.py':compile(p.read_bytes(),str(p),'exec')
value=dict(status='READY_FOR_ONE_DIAGNOSTIC_PRE',files={p.relative_to(H).as_posix():sha(p) for p in sorted(paths)},outer_runner_sha256=sha(T/'run_pre_guard_capture.py'),
 review='GPT-6 Astra found3 Important issues; author fixed all in one regression pass.26 focused tests passed; no second-review verdict claimed.',
 final_meter_max_recorded_batch_ns=max(x['elapsed_ns'] for x in meter['rows'] if x['mode']=='recorded'),
 threshold_batch_ns=10_000_000,maximum_attempts=1,benchmark_allowed=False,
 scope='Private child admission binds live parent+creation time, exact bounded request and atomic consuming child identity; public harness files are not an adversarial local security boundary.')
with (H/'capture-inputs.json').open('x') as f:json.dump(value,f,indent=2)
progress=read(H/'progress.json');progress.update(completed=['recorder RED/GREEN','finite meter qualification','independent review fixes','26 tests','final meter requalification'],active='one diagnostic PRE capture',
 review=dict(model='GPT-6 Astra',important=3,fixes=['Original resource exception preserved and clock failures latched','One supervised parent/child claim atomically consumed; direct and stale invocations rejected','Cancellation,closure,remote inspection and evidence are attempted independently'],minor='Ledger now updated',
 declined='Actual timing/cleanup, historical cause and benchmark qualification still require evidence; this capture cannot promote the candidate.'))
(H/'progress.json').write_text(json.dumps(progress,indent=2));print(json.dumps(dict(status=value['status'],inputs=len(value['files']),meter_max_ns=value['final_meter_max_recorded_batch_ns'],manifest_sha256=sha(H/'capture-inputs.json'))))
