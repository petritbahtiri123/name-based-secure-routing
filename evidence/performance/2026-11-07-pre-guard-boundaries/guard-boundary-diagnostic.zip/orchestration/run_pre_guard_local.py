import pathlib,sys,json
T=pathlib.Path(__file__).resolve().parent;H=T/'pre-guard-boundaries01';C=H/'cells/controller';sys.path.insert(0,str(C))
import bounded,resource_boundary
mode=sys.argv[1];assert mode in ('tests','meter','tests-final','meter-final')
argv=[sys.executable,'-B','-m','unittest','discover','-s',str(H/'tests'),'-v'] if mode.startswith('tests') else [sys.executable,'-B',str(H/'qualify_meter.py')]+(['after-review'] if mode=='meter-final' else [])
counts=resource_boundary.check(starting=True);(C/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
bounded.run(argv,H/'evidence'/(mode+'-command'),30)
