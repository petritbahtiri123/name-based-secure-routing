import hashlib,json,pathlib,sys
T=pathlib.Path(__file__).resolve().parent;H=T/'pre-guard-boundaries01';C=H/'capture';sys.path.insert(0,str(H))
from analyze_trace import analyze
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins=read(H/'capture-inputs.json')
for name,digest in pins['files'].items():assert sha(H/name)==digest,name
assert sha(T/'run_pre_guard_capture.py')==pins['outer_runner_sha256']
timeline=read(C/'timeline.json');assert timeline['status']=='TRACE_CAPTURED' and not timeline['cleanup_errors']
broker=read(C/'calibration-session/broker-final.json');owner=read(C/'calibration-session/ownership-final.json');remote=read(C/'calibration-remote-observation.json')
analysis=analyze(timeline['events'],read(C/'calibration-session/config.json')['started'],broker['events'],timeline['pre_status'])
assert analysis==read(H/'analysis.json')
assert analysis['finding']=='REPLY_BUFFERED_DURING_GUARD_WITHOUT_DEADLINE_CROSSING' and timeline['pre_status']=='REJECTED_AT_ORIGINAL_PRE_DEADLINE'
assert 'self.ready();self.check(deadline)' in timeline['primary_error']['traceback']
assert owner['status']=='FAILED' and not owner['owned_handles'] and owner['leader_reaped'] and owner['group_exit_observed']
assert remote['status']=='REMOTE_FAILED_CLEANUP_CONFIRMED' and remote['cleanup_confirmed'] and not remote['execution_valid'] and not remote['errors']
assert len(remote['observations'])==2 and all(not r['original_present'] and not r['group_present'] for r in remote['observations'])
commands={}
for p in list((H/'evidence').glob('*command/supervision.json'))+[C/'calibration-remote-absence/supervision.json']:
 v=read(p);assert v['status']=='LOCAL_WORKER_COMPLETED' and not v['owned_handles'] and v['leader_reaped'] and v['group_exit_observed'] and v['drain_failure'] is None
 commands[p.parent.relative_to(H).as_posix()]={k:v[k] for k in ('status','elapsed_seconds','owned_handles','leader_reaped','group_exit_observed')}
assert len(commands)==6
probe=read(C/'calibration-session/reply-1.json')['payload']['result'];assert probe['exit']==0 and probe['reader_stopped'] and not probe.get('failure')
history=read(T/'post-control-timing01/candidate02-timeline.json')['events'];tails=[]
for row in history:
 if row['kind']=='resource_check' and not row['starting']:
  children=[x for x in history if x['kind']=='snapshot' and x['check']==row['check']]
  tails.append((row['end_ns']-max(x['end_ns'] for x in children))/1e9)
summary=dict(status='PRE_OBSERVATION_DELAY_MEASURED_BENCHMARK_STILL_BLOCKED',diagnostic_capture='TRACE_CAPTURED',pre_execution=timeline['pre_status'],
 analysis=analysis,failure_site='Final client check after PRE and READY validation; the last guard itself ended8.3425ms before10s.',
 local_tests=26,review=dict(model='GPT-6 Astra',important_findings=3,addressed='Exception preservation, one supervised invocation/consuming-child gate, independent cleanup/evidence error paths; RED/GREEN coverage and26 tests. No second-review verdict claimed.'),
 meter=read(H/'evidence/meter-qualification-after-review.json'),
 attempts=dict(cold_pre=1,read_only_cleanup_ssh=1,replacements=0,post=0,endpoint_workloads=0),
 cleanup=dict(local_closed=True,local_closed_seconds=owner['elapsed_seconds'],remote_confirmed=True,remote_execution_valid=False,remote_identities=remote['observations']),
 original_exchange_seconds=10,clock_probe_rtts_ns=[r['local_after_ns']-r['local_before_ns'] for r in probe['probes']],commands=commands,
 source_provenance=dict(copied_parent_files=len(read(H/'parent-inputs.json')),copied_parent_bytes_unchanged=True,capture_inputs=len(pins['files']),capture_manifest_sha256=sha(H/'capture-inputs.json')),
 historical_context=dict(source='post-control-timing01/candidate02-timeline.json',sha256=sha(T/'post-control-timing01/candidate02-timeline.json'),
 note='Read existing per-root profiling instead of repeating it. Historical tail after last snapshot, including recovery rglob and bookkeeping, is only the following values; do not promise a second-scale gain from removing that small tail.',tail_seconds=tails),
 decisions=['No further VM attempt or qualification replacement; the targeted discriminator has been captured.',
 'Do not remove final validation or accept the buffered PRE retroactively; no tested fix or benchmark pass is established.',
 'A broader change to separate full historical-artifact auditing from the critical polling loop changes the controller guard contract and needs Petriti approval before implementation. Preserve current10s and prove resource-cap enforcement before any new VM qualification.',
 'After completing a valid benchmark, limit follow-up protocol work to2-3 small documented/verifiable improvements; broader work remains deferred as Petriti requested.'],
 architectural_proposal_not_implemented=dict(scope='Prototype a split resource guard: full retained-history audit before/after a bounded operation, fresh disk/memory/active-output/growth checks during critical waiting; original10s remains.',
 required_proof='Cannot promote unless retained7GiB,arm32MiB,output16MiB,disk11/10GiB,memory2GiB enforcement remains sound under concurrent writes and read failures. No stale active-run counts or silent cache assumptions.',
 qualification='Fault/equivalence tests first, bounded local wall/CPU screen and fresh management headroom qualification before any32/16 throughput trial.',
 limitation='This is a reviewable direction proposal, not an implemented or proved-safe replacement. Stop and obtain approval; abandon it if exact caps cannot be established.'),
 branch='codex/nbsr-v3-wp0-wp1',base_commit='1de1232d4a0a608f0a03b362af1187f481de5ee6')
(H/'summary.json').write_text(json.dumps(summary,indent=2))
progress=read(H/'progress.json');progress.update(completed=progress['completed']+['one diagnostic PRE captured','independent local/remote cleanup','offline timing analysis'],active='preserve and document; await approval for broader guard-contract change')
(H/'progress.json').write_text(json.dumps(progress,indent=2))
(H/'orchestration').mkdir(exist_ok=False)
for name in ('prepare_pre_guard_timing.py','run_pre_guard_local.py','run_pre_guard_capture.py','freeze_pre_guard_capture.py','finalize_pre_guard_evidence.py'):(H/'orchestration'/name).write_bytes((T/name).read_bytes())
files={p.relative_to(H).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(H.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='final-evidence-index.json'}
with (H/'final-evidence-index.json').open('x') as f:json.dump(dict(files=files,total_bytes=sum(r['bytes'] for r in files.values())),f,indent=2)
print(json.dumps(dict(status=summary['status'],files=len(files),index_sha256=sha(H/'final-evidence-index.json'),guard_total_s=analysis['guard_total_s'],resource_fraction=analysis['resource_fraction_of_guard_time'],historical_tail_s=tails)))
