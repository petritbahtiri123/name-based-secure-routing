"""Fresh, one-shot discriminator; never alter or repeat the sealed qualification."""
import hashlib,json,pathlib
T=pathlib.Path(__file__).resolve().parent;OLD=T/'temporary-ssh-session01';H=T/'pre-guard-boundaries01'
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((OLD/'final-evidence-index.json').read_bytes())=='9b492e1470c7a527eeb45f8126ba4ccefd6ad0f77f3faf50266033c36ea7868f'
index=json.loads((OLD/'final-evidence-index.json').read_bytes())['files'];pins=json.loads((OLD/'qualification-inputs.json').read_bytes())['files']
H.mkdir(exist_ok=False);(H/'evidence').mkdir();(H/'tests').mkdir();used={}
for name,digest in pins.items():
 if not name.startswith(('cells/controller/','collector/')):continue
 data=(OLD/name).read_bytes();assert sha(data)==digest==index[name]['sha256']
 p=H/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);used[name]=digest
disabled=H/'cells/controller/LIVE-DISABLED.json'
if not disabled.exists():disabled.write_text(json.dumps(dict(live_enabled=False,reason='Diagnostic only; no endpoint workload authorized by this plan.')))
plan=dict(status='AUTHORIZED_DIAGNOSTIC_PREPARATION',parent='temporary-ssh-session01',parent_index_sha256=sha((OLD/'final-evidence-index.json').read_bytes()),
 authorization='Parent explicitly authorized measuring resource-check timing boundaries to isolate PRE delay; preserve10s, no blind repetition, no new architecture/direction.',
 discriminator='Record whole-guard and resource-check entry/exit on the exact current candidate, and relate those intervals to existing broker READY/PRE timestamps. Previous broad root profiling/optimization is not repeated.',
 unchanged='All copied controller, resource checks, SSH options, clock code, owner, client and protocol sources are byte-identical to the sealed parent. Wrap calls without changing their result, exception, order or deadline.',
 instrumentation=dict(storage='In-memory only while PRE runs; write after owned cleanup',maximum_records=64,clock='monotonic_ns',nesting='Whole guard plus its existing resource_boundary.check; no per-file or per-root tracing',thread='Single calling thread; reject cross-thread use'),
 meter_qualification=dict(local_blocks=4,calls_per_block=64,control='Same no-op calls without recorder',screen='Every64-call recorded batch<=10ms including call/loop cost; no subtraction or negative overhead claim',maximum_batch_ns=10_000_000,limitation='Finite local overhead screen, not a future scheduling guarantee'),
 live=dict(maximum_attempts=1,run='nbsr-cal-pre-20261107-p1',pre_seconds=10,session_seconds=88,remote_seconds=70,remote_kill_grace_seconds=2,outer_command_seconds=60,
 post=False,endpoint_workloads=0,normal_finish='After PRE result or failure, deliberately cancel this diagnostic session and independently verify exact local Job and remote identity/group absence. This cannot qualify throughput or temporary SSH impact.',replacement=False),
 stop=['Any local test or meter screen failure prevents VM attempt','No live attempt before independent scoped review and exact source pins','One attempt only regardless of PRE passing/failing','Unknown cleanup, invalid trace, resource failure or changed input blocks further action'],
 interpretation=['Capture can be informative even when PRE is rejected; retain both statuses separately','A response inside a guard interval plus a guard ending at/after10s directly demonstrates present acceptance-observation delay','If no late event occurs, report remaining headroom and measured intervals without declaring historical cause solved','Resource check boundary includes filesystem traversal, its thread join and scheduling; it cannot separate I/O versus CPU versus contention'],
 existing_branch='codex/nbsr-v3-wp0-wp1',base_commit='1de1232d4a0a608f0a03b362af1187f481de5ee6')
(H/'plan.json').write_text(json.dumps(plan,indent=2));(H/'parent-inputs.json').write_text(json.dumps(used,indent=2))
(H/'progress.json').write_text(json.dumps(dict(completed=[],active='recorder regressions',rulings=['Use one fresh trace as a discriminator, not a qualification retry; oldq1/q2 remain sealed.','Keep original guard scheduling and source bytes; only call-boundary observation is added.','Retain evidence and use canonical narrative note; existing branch only.']),indent=2))
print(json.dumps(dict(status='PREPARED_DISABLED',copied_pinned_files=len(used),maximum_new_pre_attempts=1)))
