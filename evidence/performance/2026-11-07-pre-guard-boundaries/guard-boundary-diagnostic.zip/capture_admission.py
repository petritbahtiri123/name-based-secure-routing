"""One supervised invocation, not an authentication boundary against local users."""
import ctypes,json,math,os,pathlib,re,sys,time
from ctypes import wintypes as W

def process_identity(pid):
    if os.name!='nt' or type(pid) is not int or pid<=0:raise ValueError('Windows parent PID required')
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.OpenProcess.argtypes=[W.DWORD,W.BOOL,W.DWORD];k.OpenProcess.restype=W.HANDLE
    k.GetProcessTimes.argtypes=[W.HANDLE]+[ctypes.POINTER(W.FILETIME)]*4;k.GetProcessTimes.restype=W.BOOL
    k.GetExitCodeProcess.argtypes=[W.HANDLE,ctypes.POINTER(W.DWORD)];k.GetExitCodeProcess.restype=W.BOOL
    k.CloseHandle.argtypes=[W.HANDLE];k.CloseHandle.restype=W.BOOL
    handle=k.OpenProcess(0x1000,False,pid)
    if not handle:raise OSError('parent query handle unavailable')
    try:
        created,ended,kernel,user=(W.FILETIME() for _ in range(4));code=W.DWORD()
        if not k.GetProcessTimes(handle,ctypes.byref(created),ctypes.byref(ended),ctypes.byref(kernel),ctypes.byref(user)) or not k.GetExitCodeProcess(handle,ctypes.byref(code)):raise OSError('parent identity query failed')
        return dict(created=(created.dwHighDateTime<<32)|created.dwLowDateTime,alive=code.value==259)
    finally:
        if not k.CloseHandle(handle):raise OSError('parent query handle close failed')

def read(path):
    if path.is_symlink():raise ValueError('admission symlink')
    with path.open('rb') as f:wire=f.read(131073)
    if len(wire)>131072:raise ValueError('admission input size')
    return json.loads(wire)

def consume(root,token,*,clock=time.monotonic,identity=process_identity):
    root=pathlib.Path(root)
    if type(token) is not str or not re.fullmatch('[0-9a-f]{32}',token):raise ValueError('invocation token')
    claim=read(root/'attempt.json');request=read(root/'evidence/capture-command/request.json');plan=read(root/'plan.json')
    if claim['token']!=token or claim['run']!=plan['live']['run']:raise ValueError('attempt identity')
    expected=[sys.executable,'-u','-B',str(root/'supervised_entry.py'),token]
    if request['argv']!=expected or request['output']!=str((root/'evidence/capture-command').resolve()):raise ValueError('supervised request binding')
    now=clock();started=request['started'];claimed=claim['created']
    if any(type(n) not in (int,float) or not math.isfinite(n) for n in (now,started,claimed)) or not claimed<=started<=now:raise ValueError('admission clock order')
    deadline=started+60
    if now>=deadline:raise TimeoutError('original outer deadline')
    current=identity(claim['parent_pid'])
    if not current['alive'] or current['created']!=claim['parent_created']:raise ValueError('original outer parent absent/reused')
    child=identity(os.getpid())
    with (root/'child-admission.json').open('x') as f:json.dump(dict(token=token,request_started=started,outer_deadline=deadline,parent_pid=claim['parent_pid'],parent_created=claim['parent_created'],child_pid=os.getpid(),child_created=child['created'],consumed=now),f)
    return deadline

def validate_consumed(root,deadline,*,clock=time.monotonic,identity=process_identity,pid=None):
    value=read(pathlib.Path(root)/'child-admission.json');pid=os.getpid() if pid is None else pid
    if value['outer_deadline']!=deadline or value['child_pid']!=pid:raise ValueError('consuming child required')
    child=identity(pid);parent=identity(value['parent_pid']);now=clock()
    if not child['alive'] or child['created']!=value['child_created'] or not parent['alive'] or parent['created']!=value['parent_created']:raise ValueError('consumed invocation is no longer live')
    if not value['consumed']<=now<deadline:raise TimeoutError('original consumed invocation deadline')
