"""Private supervised entry; validates and consumes exactly one outer claim."""
import pathlib,sys
from capture_admission import consume
if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Use the one-shot outer capture runner')
    deadline=consume(pathlib.Path(__file__).resolve().parent,sys.argv[1])
    from capture_pre import main
    main(deadline)
