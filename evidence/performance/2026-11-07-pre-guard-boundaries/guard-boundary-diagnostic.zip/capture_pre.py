"""One diagnostic PRE, then deliberate cancellation and independent absence proof."""
import hashlib,json,pathlib,sys,time,traceback
H=pathlib.Path(__file__).resolve().parent;C=H/'cells/controller';sys.path.insert(0,str(C))
from activate import activate
activate()
import resource_boundary,session_adapter
from guard_timer import GuardTimer,observe_guards

def finish_cleanup(owner,here,run,deadline,*,verify=session_adapter.verify_remote):
    result=dict(local_closed=False,remote=None,errors=[],inspection_gate_refusal=None)
    def error(stage,e):result['errors'].append(dict(stage=stage,type=type(e).__name__,message=str(e)[:256]))
    if owner is None:return result
    try:owner.abort('planned diagnostic ends after PRE; no POST/workload')
    except BaseException as e:error('abort',e)
    try:result['local_closed']=owner.wait_closed(2)
    except BaseException as e:error('wait_closed',e)
    if owner.started is not None:
        try:result['remote']=verify(here,run,min(owner.deadline,deadline))
        except BaseException as e:
            result['inspection_gate_refusal']=dict(type=type(e).__name__,message=str(e)[:256])
            path=here/'calibration-remote-observation.json'
            if isinstance(e,ValueError) and str(e)=='remote calibration cleanup incomplete' and path.exists():
                try:
                    value=json.loads(path.read_bytes());sup=json.loads((here/'calibration-remote-absence/supervision.json').read_bytes())
                    if (value.get('run')==run and value.get('status')=='REMOTE_FAILED_CLEANUP_CONFIRMED'
                            and value.get('cleanup_confirmed') is True and value.get('execution_valid') is False
                            and not value.get('errors') and sup['status']=='LOCAL_WORKER_COMPLETED'
                            and not sup['owned_handles'] and sup['leader_reaped'] and sup['group_exit_observed']):result['remote']=value
                    else:error('remote_receipt_gate',ValueError('cleanup not independently confirmed'))
                except BaseException as parse_error:error('remote_receipt_parse',parse_error)
            else:error('remote_inspection',e)
    return result

def main(outer_deadline):
    from capture_admission import validate_consumed
    validate_consumed(H,outer_deadline)
    pins=json.loads((H/'capture-inputs.json').read_bytes())
    if pins['status']!='READY_FOR_ONE_DIAGNOSTIC_PRE':raise ValueError('review/meter gate')
    for name,digest in pins['files'].items():
        if hashlib.sha256((H/name).read_bytes()).hexdigest()!=digest:raise ValueError('changed capture input: '+name)
    plan=json.loads((H/'plan.json').read_bytes());run=plan['live']['run']
    here=H/'capture';here.mkdir(exist_ok=False)
    timer=GuardTimer();owner=None;primary=None;remote=None;inspection_error=None;pre_status='NOT_STARTED';local_closed=False
    try:
        counts=resource_boundary.check(starting=True)
        (here/'LOCAL-ADMISSION.json').write_text(json.dumps(dict(retained_bytes=counts['task'])))
        owner=session_adapter.create(here,run)
        try:
            with observe_guards(owner,resource_boundary,timer):session_adapter.pre(owner,here)
            pre_status='ACCEPTED_WITHIN_ORIGINAL_PRE_WINDOW'
        except BaseException as e:
            primary=dict(type=type(e).__name__,message=str(e),traceback=traceback.format_exc(limit=16))
            pre_status='REJECTED_AT_ORIGINAL_PRE_DEADLINE' if isinstance(e,TimeoutError) and str(e)=='original session/request deadline' else 'FAILED_OTHER'
    except BaseException as e:
        primary=dict(type=type(e).__name__,message=str(e),traceback=traceback.format_exc(limit=16))
    finally:
        cleanup=finish_cleanup(owner,here,run,outer_deadline)
        local_closed=cleanup['local_closed'];remote=cleanup['remote'];inspection_error=cleanup['inspection_gate_refusal']
        trace_valid=not timer.invalid and bool(timer.rows) and all(r['end_ns'] is not None and r['end_ns']>=r['begin_ns'] for r in timer.rows)
        capture_ok=(not cleanup['errors'] and trace_valid and local_closed and remote is not None and remote.get('cleanup_confirmed') is True
            and pre_status in ('ACCEPTED_WITHIN_ORIGINAL_PRE_WINDOW','REJECTED_AT_ORIGINAL_PRE_DEADLINE'))
        result=dict(status='TRACE_CAPTURED' if capture_ok else 'STOP_INVALID_OR_PARTIAL_TRACE',run=run,pre_status=pre_status,
            original_pre_seconds=10,trace_valid=trace_valid,events=timer.rows,primary_error=primary,inspection_gate_refusal=inspection_error,
            local_closed=local_closed,remote_cleanup_confirmed=remote is not None and remote.get('cleanup_confirmed') is True,
            cleanup_errors=cleanup['errors'],
            endpoint_workloads=0,post_run=False,deliberate_end='Cancel after PRE; this is not a successful PRE/POST qualification or a replacement for q1.')
        wire=json.dumps(result,indent=2).encode()
        if len(wire)>65536:raise ValueError('trace output cap')
        with (here/'timeline.json').open('xb') as f:f.write(wire)
        print(json.dumps({k:result[k] for k in ('status','pre_status','local_closed','remote_cleanup_confirmed','endpoint_workloads')}),flush=True)
    if not capture_ok:raise RuntimeError('one-shot diagnostic stopped; no replacement')

if __name__=='__main__':raise SystemExit('Private capture function; use the one-shot supervised outer runner')
