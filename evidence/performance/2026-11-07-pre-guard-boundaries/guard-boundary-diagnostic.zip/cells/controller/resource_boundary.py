import pathlib,shutil,json
from concurrent.futures import ThreadPoolExecutor

from accounting import snapshot

OLD=pathlib.Path('C:/Users/bajra/Documents/Codex/2026-10-19/task')

PREVIOUS=pathlib.Path('C:/Users/bajra/Documents/Codex/2026-10-24/task-2')

CURRENT=pathlib.Path('C:/Users/bajra/Documents/Codex/2026-11-07/task')
ARCHIVED_CURRENT=pathlib.Path('C:/Users/bajra/Documents/Codex/2026-11-03/task')
FOLLOWUP=pathlib.Path('C:/Users/bajra/Documents/Codex/2026-10-28/task')

def check(*,starting,groups=None):

 if shutil.disk_usage(CURRENT).free<(11 if starting else 10)*1024**3:raise RuntimeError('local disk reserve')

 counts=snapshot(CURRENT,groups or {})
 # Limit overlap to the two largest independent archival walks.
 with ThreadPoolExecutor(max_workers=1,thread_name_prefix='nbsr-metadata') as pool:
  archived=pool.submit(snapshot,ARCHIVED_CURRENT,{})
  previous=snapshot(PREVIOUS,{})['task']
  archival=archived.result()['task']
 counts['task']+=archival+snapshot(FOLLOWUP,{})['task']+previous+snapshot(OLD,{})['task']+int(json.loads((OLD/'retained-test-bytes.json').read_text(encoding='utf-8-sig'))['bytes'])

 counts['task']+=sum(p.stat().st_size for p in pathlib.Path('C:/Users/bajra/Documents/Codex/2026-11-03/task/verified-runtime-recovery').rglob('*') if p.is_file())
 if 'artifacts' in counts:counts['artifacts']=counts['task']

 if counts['task']>7*1024**3:raise RuntimeError('whole retained local artifact cap')

 return counts

