"""Offline companion reader. Does not replace the benchmark acceptance validator."""

import argparse
import json
from pathlib import Path

SCHEMA = "nbsr-paced-diagnostic-v1"
SCHEMA_V2 = "nbsr-paced-diagnostic-v2"
SCHEMA_V3 = "nbsr-paced-diagnostic-v3"
SCHEMA_V4 = "nbsr-paced-diagnostic-v4"
SCHEMA_V5 = "nbsr-paced-diagnostic-v5"
READ_FIELDS = ("covered", "unknown", "pending", "ready", "wakes", "coalesced", "wake_polls", "wake_delay_ns", "poll_ns", "elapsed_ns", "budget_min_ns", "crossed")
STAGE_MAXIMA = ("read_to_validation_max_ns", "validation_to_call_max_ns", "completion_lock_max_ns")
STAGE_COUNTS = ("completion_stage_count", "read_return_before_boundary")
EXPIRATION_FIELDS = ("expired_observed_full", "expired_observed_pending", "expired_observed_available")
COUNTERS = ("offered", "reserved", "issued", "completed", "missed", "unreserved_current")
HISTOGRAMS = ("wake_recording_delay", "timer_wake", "task_wake", "reservation_to_issue", "response")


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def integer(value, maximum=2**64 - 1):
    require(type(value) is int and 0 <= value <= maximum, "invalid diagnostic integer")
    return value


def histogram(value):
    require(type(value) is dict and set(value) == {"count", "max_ns", "log2_ns_bins"}, "invalid histogram shape")
    count, maximum = integer(value["count"]), integer(value["max_ns"])
    bins = value["log2_ns_bins"]
    require(type(bins) is list and len(bins) == 65, "invalid histogram bins")
    require(sum(integer(v) for v in bins) == count, "histogram count mismatch")
    require(
        (not count and maximum == 0) or (count and bins[maximum.bit_length()] > 0 and not any(bins[maximum.bit_length() + 1 :])),
        "histogram maximum mismatch",
    )
    rank, cumulative = (count * 99 + 99) // 100, 0
    for index, number in enumerate(bins):
        cumulative += number
        if count and cumulative >= rank:
            return min((1 << index) - 1, maximum)
    return None


def summarize(records):
    pending, final, windows, previous_end, previous_missed, previous_completed = None, False, 0, 0, 0, 0
    shape = None
    largest, totals = [], dict(missed_unattributed=0, responses=0)
    maximums = {name: 0 for name in HISTOGRAMS}
    expiration = {name: 0 for name in EXPIRATION_FIELDS}
    diagnostic_schema = None
    previous_counts = dict.fromkeys(COUNTERS, 0)
    accounting = None
    expected_read = None
    read_totals = [dict.fromkeys(READ_FIELDS, 0) for _ in range(3)]
    read_coverage = dict(reads=0, complete=0, residual_max_ns=0)
    stages = dict.fromkeys(STAGE_MAXIMA + STAGE_COUNTS, 0)
    boundary = dict(full=0, pending=0, available=0, unknown=0)
    for row in records:
        require(type(row) is dict and not final, "invalid record or record after final")
        schema = row.get("schema")
        require(expected_read is None or schema == "nbsr-paced-read-v1", "missing read-phase record")
        if schema == "nbsr-paced-read-v1":
            require(expected_read is not None, "unexpected read-phase record")
            require(row.get("event") == "diagnostic", "read-phase event")
            require(all(integer(row[k]) == expected_read[k] for k in ("window_index", "start_ns", "end_ns")), "read-phase correlation")
            reads = integer(row["reads"], expected_read["response"]["count"])
            complete = integer(row["complete"], reads)
            residual = integer(row["residual_max_ns"])
            require(complete > 0 or residual == 0, "residual without coverage")
            require(type(row["phases"]) is list and len(row["phases"]) == 3, "read phase shape")
            covered_sum = 0
            for values, total in zip(row["phases"], read_totals):
                require(type(values) is list and len(values) == len(READ_FIELDS), "read phase fields")
                p = dict(zip(READ_FIELDS, (integer(v) for v in values)))
                require(p["covered"] + p["unknown"] == reads and p["ready"] == p["covered"] and complete <= p["covered"], "read phase coverage")
                require(p["crossed"] <= p["covered"] and p["coalesced"] <= p["wakes"] and p["wake_polls"] <= p["wakes"] - p["coalesced"] <= p["wake_polls"] + p["covered"], "read phase counters")
                covered_sum += p["covered"]
                require(p["poll_ns"] <= p["elapsed_ns"] and p["wake_delay_ns"] <= p["elapsed_ns"], "read phase duration")
                require(p["wake_polls"] > 0 or p["wake_delay_ns"] == 0, "wake delay without observation")
                require(p["covered"] > 0 or all(v == 0 for k,v in p.items() if k != "unknown"), "uncovered phase observations")
                previous = total["covered"]
                for k,v in p.items():
                    if k == "budget_min_ns":
                        if p["covered"]: total[k] = min(total[k],v) if previous else v
                    elif k.endswith("_ns"): total[k] = max(total[k],v)
                    else: total[k] += v
            require(complete >= max(0, covered_sum - 2 * reads), "complete coverage contradiction")
            read_coverage["reads"] += reads
            read_coverage["complete"] += complete
            read_coverage["residual_max_ns"] = max(read_coverage["residual_max_ns"], residual)
            expected_read = None
        elif schema == "nbsr-b5-grouped-progress-v1":
            require(pending is None, "missing diagnostic window")
            counts = {name: integer(row[name]) for name in COUNTERS}
            require(
                counts["offered"] == counts["reserved"] + counts["missed"] + counts["unreserved_current"]
                and counts["completed"] <= counts["issued"] <= counts["reserved"],
                "slot accounting mismatch",
            )
            require(all(counts[k] >= previous_counts[k] for k in COUNTERS if k != "unreserved_current"), "accounting counter regression")
            previous_counts = counts
            pending = row
        elif schema in (SCHEMA, SCHEMA_V2, SCHEMA_V3, SCHEMA_V4, SCHEMA_V5):
            require(pending is not None, "diagnostic without matching progress")
            require(diagnostic_schema is None or diagnostic_schema == schema, "diagnostic version changed")
            diagnostic_schema = schema
            has_expiration = any(k in row for k in EXPIRATION_FIELDS)
            require(has_expiration == (schema in (SCHEMA_V2, SCHEMA_V3, SCHEMA_V4, SCHEMA_V5)), "expiration schema mismatch")
            require(("boundary_expired" in row) == (schema in (SCHEMA_V3, SCHEMA_V4, SCHEMA_V5)), "boundary schema mismatch")
            if schema in (SCHEMA_V3, SCHEMA_V4, SCHEMA_V5):
                b = row["boundary_expired"]
                require(type(b) is dict and set(b) == set(boundary), "boundary shape mismatch")
                require(sum(integer(b[k]) for k in boundary) == integer(row["missed_unattributed"]), "boundary reconciliation mismatch")
                for k in boundary:
                    boundary[k] += b[k]
            if has_expiration:
                require(all(k in row for k in EXPIRATION_FIELDS), "incomplete expiration observations")
                require(
                    sum(integer(row[k]) for k in EXPIRATION_FIELDS) == integer(row["missed_unattributed"]),
                    "expiration observation mismatch",
                )
                for k in EXPIRATION_FIELDS:
                    expiration[k] += row[k]
            present = [k in row for k in STAGE_MAXIMA + STAGE_COUNTS]
            require(all(present) if schema in (SCHEMA_V4, SCHEMA_V5) else not any(present), "stage schema mismatch")
            if schema in (SCHEMA_V4, SCHEMA_V5):
                count = integer(row["completion_stage_count"], integer(row["response"]["count"]))
                integer(row["read_return_before_boundary"], count)
                for k in STAGE_MAXIMA:
                    value = integer(row[k])
                    require(count > 0 or value == 0, "stage maximum without observations")
                    stages[k] = max(stages[k], value)
                for k in STAGE_COUNTS:
                    stages[k] += row[k]
            windows += 1
            require(windows <= 7202, "diagnostic window bound")
            for key in (
                "window_index",
                "start_ns",
                "end_ns",
                "partitions",
                "depth",
                "all_full_ns",
                "read_at_capacity",
                "missed_unattributed",
            ):
                integer(row[key])
            require(
                row["event"] == "diagnostic"
                and row["window_index"] == windows
                and row["window_index"] == pending["window_index"]
                and row["start_ns"] == previous_end == pending["interval_start_ns"]
                and row["end_ns"] == pending["interval_end_ns"] > previous_end,
                "uncorrelated diagnostic window",
            )
            span = row["end_ns"] - row["start_ns"]
            partitions, depth = row["partitions"], row["depth"]
            require(1 <= partitions <= 256 and 1 <= depth <= 64, "invalid workload shape")
            require(shape is None or shape == (partitions, depth), "workload changed")
            shape = (partitions, depth)
            for key, bound in [
                ("outstanding_request_ns", span * partitions * depth),
                ("pending_write_ns", span * partitions),
                ("full_partition_ns", span * partitions),
                ("all_full_ns", span),
            ]:
                integer(row[key], bound)
            quantiles = {name: histogram(row[name]) for name in HISTOGRAMS}
            for name in HISTOGRAMS:
                maximums[name] = max(maximums[name], row[name]["max_ns"])
            require(row["missed_unattributed"] == integer(pending["missed"]) - previous_missed, "missed delta mismatch")
            require(row["response"]["count"] == integer(pending["completed"]) - previous_completed, "completion delta mismatch")
            previous_end, previous_missed, previous_completed = row["end_ns"], pending["missed"], pending["completed"]
            totals["missed_unattributed"] += row["missed_unattributed"]
            totals["responses"] += row["response"]["count"]
            largest.append(
                dict(
                    window_index=windows,
                    start_ns=row["start_ns"],
                    end_ns=row["end_ns"],
                    missed=row["missed_unattributed"],
                    average_outstanding=row["outstanding_request_ns"] / span,
                    average_pending_writes=row["pending_write_ns"] / span,
                    full_partition_fraction=row["full_partition_ns"] / (span * partitions),
                    all_full_fraction=row["all_full_ns"] / span,
                    response_p99_upper_ns=quantiles["response"],
                    response_max_ns=row["response"]["max_ns"],
                    timer_wake_max_ns=row["timer_wake"]["max_ns"],
                    task_wake_max_ns=row["task_wake"]["max_ns"],
                    issue_delay_max_ns=row["reservation_to_issue"]["max_ns"],
                )
            )
            largest.sort(key=lambda value: (-value["missed"], value["window_index"]))
            del largest[10:]
            expected_read = row if schema == SCHEMA_V5 else None
            pending = None
        elif schema == "nbsr-b5-grouped-final-v1":
            require(windows > 0 and pending is None, "missing diagnostic windows")
            require(
                integer(row["measurement_duration_ns"]) + integer(row["drain_duration_ns"]) == previous_end
                and integer(row["missed"]) == previous_missed
                and integer(row["completed"]) == previous_completed
                and shape == (integer(row["groups"]) * integer(row["streams_per_group"]), integer(row["outstanding_per_stream"])),
                "final diagnostic reconciliation failed",
            )
            counts = {name: integer(row[name]) for name in COUNTERS}
            require(counts == previous_counts, "final counter mismatch")
            require(
                counts["reserved"] == counts["issued"] == counts["completed"]
                and counts["unreserved_current"] == 0
                and counts["offered"] == counts["issued"] + counts["missed"],
                "unresolved final accounting",
            )
            require(
                row.get("evidence_valid") is True
                and row.get("all_groups_joined") is True
                and all(integer(row[k]) == 0 for k in ("errors", "timeouts", "collector_overflow_count")),
                "failed or incomplete run: request failures remain unresolved",
            )
            accounting = dict(
                scheduled=counts["offered"],
                issued=counts["issued"],
                completed=counts["completed"],
                failed_requests=0,
                unissued=counts["missed"],
                unresolved_issued=0,
                issued_completion_integrity=True,
                offered_load_achieved=counts["missed"] == 0,
                scope="Complete successful final only; omission is not network loss. No acceptance threshold changed.",
            )
            final = True
        else:
            require(row.get("event") == "diagnostic" and pending is None, "unknown or interleaved record")
    require(final and pending is None and expected_read is None, "incomplete diagnostic evidence")
    return dict(
        schema="nbsr-paced-diagnostic-summary-v1",
        windows=windows,
        totals=totals,
        maximum_delay_ns=maximums,
        largest_missed_windows=largest,
        accounting=accounting,
        expiration_observations=expiration if diagnostic_schema in (SCHEMA_V2, SCHEMA_V3, SCHEMA_V4, SCHEMA_V5) else None,
        boundary_expired=boundary if diagnostic_schema in (SCHEMA_V3, SCHEMA_V4, SCHEMA_V5) else None,
        completion_stages=stages if diagnostic_schema in (SCHEMA_V4, SCHEMA_V5) else None,
        read_phases=read_totals if diagnostic_schema == SCHEMA_V5 else None,
        read_coverage=read_coverage if diagnostic_schema == SCHEMA_V5 else None,
        interpretation="Observed pressure and delays; missed-slot cause remains unattributed.",
    )


def read_records(path):
    consumed = 0
    with path.open("rb") as stream:
        for _ in range(32768):
            line = stream.readline(65537)
            if not line:
                return
            consumed += len(line)
            require(len(line) <= 65536 and consumed <= 32 * 1024**2 and line.endswith(b"\n"), "diagnostic input bound/framing")
            yield json.loads(line)
        require(not stream.read(1), "diagnostic record bound")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stdout", type=Path)
    args = parser.parse_args()
    print(json.dumps(summarize(read_records(args.stdout)), indent=2))
