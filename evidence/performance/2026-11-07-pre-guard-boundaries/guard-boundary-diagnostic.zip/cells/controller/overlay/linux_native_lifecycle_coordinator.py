"""Coordinate a bounded native lifecycle cell over private management streams."""

from pathlib import PurePosixPath
import json
import queue
import re
import subprocess
import threading
import time

from scripts.performance.linux_native_duration import bounds
from scripts.performance.linux_native_cycle_limits import cycle_bounds
from scripts.performance.linux_b5_ceiling import require
from scripts.performance.linux_native_lifecycle import validate_cpu_pool, validate_bundle_mode, bundle_counts, validate_runtime_workers
from scripts.performance.linux_native_lifecycle_control import LIVE_BUNDLE_COUNTS, decode_object
from scripts.performance.linux_native_lifecycle_remote import remote_command, remote_path
from scripts.performance.linux_native_peer import validate_endpoint
from scripts.performance.process_cancellation import not_cancelled


SEQUENCES = dict(source=('prepared', 'readiness_transferred', 'active', 'released', 'acked', 'complete'),
                 destination=('ready', 'active', 'released', 'report_ready', 'report_released', 'complete'))


def require_relay_cleanup(outcomes):
    """Local cleanup is a prerequisite, never proof of remote endpoint cleanup."""
    require(isinstance(outcomes, dict) and set(outcomes) == set(SEQUENCES)
            and all(isinstance(row, dict) and type(row.get('exit_code')) is int
                    and row['exit_code'] == 0 and row.get('local_relay_forced') is False
                    and row.get('local_relay_reaped') is True
                    and row.get('local_cleanup_errors') == []
                    and row.get('remote_cleanup') == 'REQUIRES_EVIDENCE'
                    for row in outcomes.values()), 'relay cleanup failed')


def endpoint_arguments(config, role):
    target = config[role]
    argv = ['python3', '-B', '-m', 'scripts.performance.linux_native_lifecycle_endpoint', '--role', role]
    for field in ('binaries', 'build_manifest', 'authority', 'lifecycle', 'output', 'bind', 'cores'):
        argv.extend(['--' + field.replace('_', '-'), str(target[field])])
    for field in ('count', 'rate', 'shards'):
        argv.extend(['--' + field, str(config[field])])
    if 'runtime_workers' in target:
        argv.extend(['--runtime-workers', str(target['runtime_workers'])])
    if 'cpu_pool' in target:
        argv.extend(['--cpu-pool', ','.join(map(str, target['cpu_pool']))])
    if role == 'source':
        address, _ = validate_endpoint(config['destination']['bind'], allow_zero=True)
        argv.extend(['--destination-address', address])
    if 'bundle_mode' in config:
        argv.extend(['--bundle-mode', config['bundle_mode']])
    return argv + (['--memory-observer'] if config.get('memory_observer', False) else [])


def validate_config(value):
    require(isinstance(value, dict) and set(value) - {'memory_observer', 'bundle_mode'} == {'schema', 'source_sha', 'count', 'rate', 'shards', 'source', 'destination'},
            'invalid coordinator fields')
    validate_bundle_mode(value.get('bundle_mode', 'idle-bundles'))
    require(type(value.get('memory_observer', False)) is bool, 'boolean memory observer required')
    require(value['schema'] == 'nbsr-native-lifecycle-coordinator-v1'
            and isinstance(value['source_sha'], str) and re.fullmatch('[0-9a-f]{40}', value['source_sha']), 'invalid source/schema')
    for field, choices in [('count', bundle_counts(value.get('bundle_mode', 'idle-bundles'))), ('shards', (1, 2))]:
        require(type(value[field]) is int and value[field] in choices, 'invalid ' + field)
    require(type(value['rate']) is int and 1 <= value['rate'] <= 1000, 'invalid offered rate')
    for role in SEQUENCES:
        target = value[role]
        require(isinstance(target, dict) and set(target) - {'cpu_pool', 'runtime_workers'} == {'transport', 'host', 'checkout', 'binaries',
            'build_manifest', 'authority', 'lifecycle', 'output', 'bind', 'cores'}, 'invalid role configuration')
        remote_command(target, ['true'])  # Validation only; no remote operation.
        for field in ('binaries', 'build_manifest', 'authority', 'lifecycle', 'output'):
            remote_path(target[field])
        require(type(target['cores']) is int and target['cores'] in (1, 2, 4), 'invalid cores')
        if 'runtime_workers' in target:
            require(role == 'destination', 'explicit runtime workers supported only for destination')
            validate_runtime_workers(target['runtime_workers'], target['cores'])
        if 'cpu_pool' in target:
            validate_cpu_pool(target['cpu_pool'], target['cores'])
        _, port = validate_endpoint(target['bind'], allow_zero=True)
        require(role != 'source' or port == 0, 'source requires ephemeral bind')
        output = PurePosixPath(target['output'])
        require(not output.is_relative_to(PurePosixPath(target['checkout'])), 'output inside checkout')
        for field in ('authority', 'lifecycle'):
            private = PurePosixPath(target[field])
            require(not output.is_relative_to(private) and not private.is_relative_to(output), 'private/output overlap')
    source, destination = value['source'], value['destination']
    if (source['transport'], source['host']) == (destination['transport'], destination['host']):
        for field in ('output', 'lifecycle'):
            a, b = PurePosixPath(source[field]), PurePosixPath(destination[field])
            require(not a.is_relative_to(b) and not b.is_relative_to(a), 'same-host role paths overlap')
    return value


def drive(start, wait, send, finish, *, sleep):
    start('source')
    wait('source', 'prepared')
    start('destination')
    ready = wait('destination', 'ready')
    send('source', dict(op='readiness', value=ready['value']))
    wait('source', 'readiness_transferred')
    wait('source', 'active')
    wait('destination', 'active')
    sleep(2)
    send('destination', dict(op='release'))
    wait('destination', 'released')
    send('source', dict(op='release'))
    wait('source', 'released')
    wait('source', 'acked')
    wait('destination', 'report_ready')
    sleep(2)
    send('destination', dict(op='report_release'))
    wait('destination', 'report_released')
    wait('source', 'complete')
    wait('destination', 'complete')
    finish('source')
    finish('destination')


class EventLedger:
    def __init__(self, count):
        require(type(count) is int and count in LIVE_BUNDLE_COUNTS, 'invalid event count')
        self.count = count
        self.positions = dict.fromkeys(SEQUENCES, 0)
        self.last_time = dict.fromkeys(SEQUENCES, -1)
        self.received = {}

    def accept(self, role, wire):
        require(role in SEQUENCES, 'invalid role')
        value = decode_object(wire)
        position = self.positions[role]
        require(position < len(SEQUENCES[role]), 'event after completion')
        name = SEQUENCES[role][position]
        require(value.get('schema') == 'nbsr-native-lifecycle-control-v1'
                and value.get('role') == role and value.get('event') == name, 'event role/schema/order mismatch')
        fields = {'schema', 'role', 'event', 'timestamp_ns'}
        if name in ('active', 'released', 'acked', 'complete'):
            fields.add('count')
            require(type(value.get('count')) is int and value['count'] == self.count, 'event count mismatch')
        if name == 'ready':
            fields.add('value')
            require(isinstance(value.get('value'), dict), 'readiness object required')
        require(set(value) == fields and type(value.get('timestamp_ns')) is int
                and value['timestamp_ns'] >= 0 and value['timestamp_ns'] >= self.last_time[role], 'event fields/clock mismatch')
        self.positions[role] += 1
        self.last_time[role] = value['timestamp_ns']
        self.received[role, name] = value
        return value

    def eof(self, role):
        if self.positions[role] != len(SEQUENCES[role]):
            raise InterruptedError(role + ' control EOF before completion')


class Manager:
    """Own local management relays; remote cleanup requires endpoint evidence."""

    def __init__(self, count, output, *, timeout=120, cleanup_timeout=15, check_cancelled=not_cancelled,
                 ledger=None, on_receive=None, diagnostic_seconds=None, lifecycle_cycles=None):
        require(0 < timeout <= 120 and 0 < cleanup_timeout <= 15, 'invalid management deadline')
        cycle_limits = None
        if lifecycle_cycles is not None:
            cycle_limits = cycle_bounds(lifecycle_cycles)
            require(diagnostic_seconds is None and timeout == 120 and type(count) is int
                    and count == lifecycle_cycles and ledger is not None, 'invalid mixed cycle controller mode')
        self.ledger = EventLedger(count) if ledger is None else ledger
        require(on_receive is None or callable(on_receive), 'invalid event callback')
        self.on_receive = on_receive
        self.output = output
        limits = bounds(diagnostic_seconds)
        require(diagnostic_seconds is None or timeout == 120, 'long workload keeps fixed control allowance')
        controller_seconds = timeout if diagnostic_seconds is None else limits['controller_seconds']
        if cycle_limits is not None:
            controller_seconds = cycle_limits['controller_seconds']
        self.deadline = time.monotonic() + controller_seconds
        self.cleanup_timeout = cleanup_timeout
        self.check_cancelled = check_cancelled
        self.children, self.readers, self.errors = {}, {}, {}
        self.messages = queue.Queue(maxsize=32)
        self.stop = threading.Event()
        self.eof_roles = set()
        self.log = (output / 'management.ndjson').open('x', encoding='utf-8', newline='\n')

    def record(self, **value):
        self.log.write(json.dumps(dict(timestamp_ns=time.monotonic_ns(), **value), allow_nan=False) + '\n')
        self.log.flush()

    def check(self):
        self.check_cancelled()
        if time.monotonic() >= self.deadline:
            raise TimeoutError('management deadline')

    def start_command(self, role, command):
        self.check()
        require(role in SEQUENCES and role not in self.children, 'duplicate/unknown role')
        self.record(action='start', role=role, command=command)
        errors = (self.output / (role + '-stderr.log')).open('xb')
        self.errors[role] = errors
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors, bufsize=0)
        self.children[role] = child

        def read():
            try:
                while not self.stop.is_set():
                    wire = child.stdout.readline(65537)
                    value = wire if wire else None
                    while not self.stop.is_set():
                        try:
                            self.messages.put((role, value), timeout=.05)
                            break
                        except queue.Full:
                            pass
                    if not wire or len(wire) > 65536 or not wire.endswith(b'\n'):
                        break
            except (OSError, ValueError) as error:
                if not self.stop.is_set():
                    try:
                        self.messages.put((role, error), timeout=.1)
                    except queue.Full:
                        pass

        reader = threading.Thread(target=read, daemon=True)
        self.readers[role] = reader
        reader.start()
        return child

    def pump(self, delay=.02):
        self.check()
        try:
            role, wire = self.messages.get(timeout=delay)
        except queue.Empty:
            return
        if isinstance(wire, BaseException):
            raise InterruptedError('management reader failed') from wire
        if wire is None:
            self.ledger.eof(role)
            self.eof_roles.add(role)
            self.record(action='eof', role=role)
            return
        require(len(wire) <= 65536 and wire.endswith(b'\n'), 'bounded newline event required')
        value = self.ledger.accept(role, wire)
        self.record(action='receive', role=role, value=value)
        if self.on_receive is not None:
            self.on_receive(role, value)

    def wait(self, role, event):
        while (role, event) not in self.ledger.received:
            self.pump()
        self.check()
        return self.ledger.received[role, event]

    def send(self, role, value):
        self.check()
        wire = (json.dumps(value, allow_nan=False) + '\n').encode()
        require(len(wire) <= 65536, 'control message too large')
        child = self.children[role]
        result = queue.Queue(maxsize=1)

        def write():
            try:
                view = memoryview(wire)
                while view:
                    count = child.stdin.write(view)
                    require(count is not None and count > 0, 'control write failed')
                    view = view[count:]
                child.stdin.flush()
                result.put(None)
            except (OSError, ValueError) as error:
                result.put(error)

        threading.Thread(target=write, daemon=True).start()
        while True:
            self.check()
            try:
                error = result.get(timeout=.02)
                break
            except queue.Empty:
                # pump() may forward telemetry through send(). Do not start a
                # second writer while this ordered control frame is pending.
                # Deadlines/cancellation remain checked on every bounded wait;
                # the bounded reader queue retains incoming frames until return.
                continue
        if error is not None:
            raise InterruptedError('control write failed') from error
        self.record(action='send', role=role, value=value)

    def sleep(self, seconds):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            self.pump(min(.02, max(0, deadline - time.monotonic())))

    def finish(self, role):
        child = self.children[role]
        while child.poll() is None or role not in self.eof_roles:
            self.pump()
        require(child.returncode == 0, 'endpoint relay failed: ' + role)
        self.record(action='exit', role=role, code=child.returncode)

    def close(self):
        # EOF reaches cooperative remote controllers. Never kill remote PIDs by name.
        outcomes = {
            role: dict(exit_code=None, local_relay_forced=False, local_relay_reaped=False,
                       local_cleanup_errors=[], remote_cleanup='UNCONFIRMED')
            for role in dict.fromkeys((*self.children, *self.errors))
        }
        # Retain ownership and partial outcomes even if an uncatchable failure interrupts us.
        self.cleanup_outcomes = outcomes
        failed = object()

        def error(role, stage, exception):
            row = outcomes[role]
            entry = dict(stage=stage, error_type=type(exception).__name__[:64])
            if entry not in row['local_cleanup_errors'] and len(row['local_cleanup_errors']) < 16:
                row['local_cleanup_errors'].append(entry)
            row['remote_cleanup'] = 'UNCONFIRMED'

        def attempt(role, stage, operation):
            try:
                return operation()
            except Exception as exception:
                # Cleanup failures must not prevent attempts for another owned relay.
                # Catchable cancellation is deferred by Cancellation, not raised here.
                error(role, stage, exception)
                return failed

        for role, child in self.children.items():
            attempt(role, 'stdin_close', lambda: child.stdin.close())
        deadline = time.monotonic() + self.cleanup_timeout
        pending = {role for role, child in self.children.items() if attempt(role, 'poll', child.poll) is None}
        while pending and time.monotonic() < deadline:
            time.sleep(.02)
            pending = {role for role in pending if attempt(role, 'poll', self.children[role].poll) is None}
        self.stop.set()
        for role, child in self.children.items():
            code = attempt(role, 'poll', child.poll)
            forced = code is None or code is failed
            outcomes[role]['local_relay_forced'] = forced
            if forced:
                attempt(role, 'terminate', child.terminate)
                attempt(role, 'wait', lambda: child.wait(timeout=5))
                code = attempt(role, 'poll', child.poll)
                if code is None or code is failed:
                    attempt(role, 'kill', child.kill)
                    attempt(role, 'wait', lambda: child.wait(timeout=5))
                    code = attempt(role, 'poll', child.poll)
            if type(code) is int:
                outcomes[role].update(exit_code=code, local_relay_reaped=True)
            reader = self.readers.get(role)
            # Popen can succeed before thread construction/start fails. The child is
            # still ours, but a nonexistent/unstarted reader cannot be joined.
            if reader is not None and reader.ident is not None:
                attempt(role, 'reader_join', lambda: reader.join(timeout=2))
                if attempt(role, 'reader_alive', reader.is_alive) is True:
                    error(role, 'reader_join', TimeoutError())
            attempt(role, 'stdout_close', lambda: child.stdout.close())
        for role, errors in self.errors.items():
            attempt(role, 'stderr_close', errors.close)
        for row in outcomes.values():
            if (row['local_relay_reaped'] and row['exit_code'] == 0
                    and not row['local_relay_forced'] and not row['local_cleanup_errors']):
                row['remote_cleanup'] = 'REQUIRES_EVIDENCE'

        def log_failure(stage, exception):
            if not outcomes:
                outcomes['_manager'] = dict(exit_code=None, local_relay_forced=False,
                    local_relay_reaped=False, local_cleanup_errors=[], remote_cleanup='UNCONFIRMED')
            for role in outcomes:
                error(role, stage, exception)

        try:
            self.record(action='cleanup', outcomes=outcomes)
        except Exception as exception:
            log_failure('management_record', exception)
        finally:
            try:
                self.log.close()
            except Exception as exception:
                log_failure('management_close', exception)
        return outcomes
