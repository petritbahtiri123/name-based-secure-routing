"""Opt-in timer identity protocol. No scheduling mutations or broad CPU exemptions."""
import json
from pathlib import Path
import threading
import time

FIELDS = ('pid', 'start_ticks', 'timer_tid', 'timer_start_ticks', 'timer_cpu', 'other_cpu')
SCHEMAS = ('nbsr-timer-identity-v1', 'nbsr-timer-applied-v1',
           'nbsr-timer-affinity-ready-v1', 'nbsr-affinity-measurement-started-v1',
           'nbsr-timer-finished-v1')


def identity(record, cpu, pid):
    result = {key: record[key] for key in FIELDS}
    if (any(type(v) is not int for v in result.values()) or type(cpu) is not int
            or cpu not in (0, 1) or result['timer_cpu'] != cpu
            or result['other_cpu'] != 0 or result['pid'] != pid or pid <= 0
            or result['timer_tid'] <= 0 or result['timer_tid'] == pid
            or result['start_ticks'] <= 0 or result['timer_start_ticks'] <= 0):
        raise ValueError('invalid timer identity/arm')
    return result


def validate_sample(sample, expected):
    """Same recorded per-thread contract for live and offline consumers."""
    ident = identity(expected['identity'], expected['identity']['timer_cpu'], sample['pid'])
    if (sample['start_ticks'] != ident['start_ticks'] or sample.get('affinity') != [0]
            or sample.get('timer_affinity') != expected or expected['phase'] not in ('active', 'finished')):
        raise ValueError('timer sample identity/phase')
    rows = sample['thread_affinity']
    tids = [r['tid'] for r in rows]
    if len(tids) != len(set(tids)) or ident['pid'] not in tids or tids != sample['thread_ids']:
        raise ValueError('thread inventory mismatch')
    if ident['timer_tid'] not in tids and expected['phase'] != 'finished' and sample['state'] != 'Z':
        raise ValueError('active timer missing')
    for row in rows:
        if (type(row.get('tid')) is not int or row['tid'] <= 0
                or type(row.get('start_ticks')) is not int or row['start_ticks'] <= 0
                or type(row.get('mask')) is not list
                or any(type(cpu) is not int for cpu in row['mask'])):
            raise ValueError('invalid thread identity/mask types')
        timer = row['tid'] == ident['timer_tid']
        if row['mask'] != ([ident['timer_cpu']] if timer else [0]):
            raise ValueError('thread mask mismatch')
        if timer and row['start_ticks'] != ident['timer_start_ticks']:
            raise ValueError('timer TID reused')
        if row['tid'] == ident['pid'] and row['start_ticks'] != ident['start_ticks']:
            raise ValueError('process PID reused')


class Transcript:
    """Bounded incremental reader, shared by owner and resource observer."""
    def __init__(self, path, cpu, pid):
        self.path, self.cpu, self.pid = Path(path), cpu, pid
        self.offset, self.pending, self.records = 0, b'', []
        self.lock = threading.Lock()

    def poll(self):
        with self.lock:
            with self.path.open('rb') as stream:
                stream.seek(self.offset)
                chunk = stream.read(4 * 1024 * 1024 + 1 - self.offset)
            self.offset += len(chunk)
            if self.offset > 4 * 1024 * 1024:
                raise ValueError('affinity transcript cap')
            lines = (self.pending + chunk).split(b'\n')
            self.pending = lines.pop()
            if len(self.pending) > 65536:
                raise ValueError('affinity line cap')
            for line in lines:
                if len(line) > 65536:
                    raise ValueError('affinity line cap')
                r = json.loads(line)
                if r.get('schema') not in SCHEMAS:
                    continue
                n = len(self.records)
                if n >= len(SCHEMAS) or r['schema'] != SCHEMAS[n]:
                    raise ValueError('duplicate/out-of-order timer receipt')
                if type(r.get('monotonic_ns')) is not int or r['monotonic_ns'] < 0:
                    raise ValueError('timer receipt clock')
                if n and r['monotonic_ns'] < self.records[-1]['monotonic_ns']:
                    raise ValueError('timer receipt clock regressed')
                if n != 3:
                    current = identity(r, self.cpu, self.pid)
                    if n and current != identity(self.records[0], self.cpu, self.pid):
                        raise ValueError('timer receipt identity changed')
                if n == 3 and r['monotonic_ns'] - self.records[2]['monotonic_ns'] > 10_000_000:
                    raise ValueError('measurement bracket')
                if n == 4 and r['monotonic_ns'] < self.records[2]['monotonic_ns'] + 20_000_000_000:
                    raise ValueError('early timer finish')
                self.records.append(r)
            return list(self.records)

    def snapshot(self):
        records = self.poll()
        if len(records) < 2:
            raise ValueError('timer not acknowledged/applied')
        return dict(identity=identity(records[0], self.cpu, self.pid),
                    phase='finished' if len(records) == 5 else 'active')


def requested_cpu(command):
    if '--b5-timer-cpu' not in command:
        return None
    if command.count('--b5-timer-cpu') != 1:
        raise ValueError('ambiguous timer arm')
    pos = command.index('--b5-timer-cpu')
    if pos + 1 == len(command) or command[pos + 1] not in ('0', '1'):
        raise ValueError('invalid timer arm')
    return int(command[pos + 1])


def handshake(child, cpus, output, cpu, *, deadline, check_cancelled,
              sample_fn=None, clock=time.monotonic, sleep=time.sleep, proc_root=Path('/proc')):
    from scripts.performance.linux_loopback import sample_process
    sample_fn = sample_fn or sample_process
    if cpus != [0] or child.stdin is None:
        raise ValueError('timer handshake requires owned pipe and CPU0 base')
    reader = Transcript(output / 'stdout', cpu, child.pid)
    limit = min(deadline, clock() + 2.0)
    def check_budget():
        check_cancelled()
        if clock() >= limit:
            raise TimeoutError('timer startup handshake deadline')
    def wait_count(count):
        while True:
            check_budget()
            records = reader.poll()
            if len(records) == count:
                return records[-1]
            if len(records) > count:
                raise ValueError('timer progressed before release')
            sleep(.001)
    try:
        first = wait_count(1)
        ident = identity(first, cpu, child.pid)
        # Timer is blocked on its owned stdin pipe and still CPU0 here.
        initial = sample_fn(child.pid, cpus)
        if initial['start_ticks'] != ident['start_ticks'] or ident['timer_tid'] not in initial['thread_ids']:
            raise ValueError('startup owned identity mismatch')
        from scripts.performance.linux_loopback import parse_proc_stat
        text = (proc_root / str(child.pid) / 'task' / str(ident['timer_tid']) / 'stat').read_text()
        if int(text.split(' ', 1)[0]) != ident['timer_tid'] or parse_proc_stat(text, 1, 1)['start_ticks'] != ident['timer_start_ticks']:
            raise ValueError('startup timer identity mismatch')
        check_budget()
        child.stdin.write(b'A'); child.stdin.flush()
        wait_count(2)
        applied = sample_fn(child.pid, cpus, timer_affinity=reader)
        check_budget()
        child.stdin.write(b'R'); child.stdin.flush()
        (output / 'timer-handshake.json').write_text(json.dumps(dict(identity=ident, before=initial, before_timer_start_ticks=ident['timer_start_ticks'], applied=applied)))
        check_budget()
        return reader
    finally:
        child.stdin.close()


def offline_context(root, *, allow_legacy_missing_command=False):
    command_path = root / 'command.json'
    command = (json.loads(command_path.read_bytes())['argv'] if command_path.exists()
               else [] if allow_legacy_missing_command else json.loads(command_path.read_bytes())['argv'])
    cpu = requested_cpu(command)
    if cpu is None:
        if (root / 'timer-handshake.json').exists():
            raise ValueError('undeclared timer handshake proof')
        with (root / 'stdout').open('rb') as stream:
            wire = stream.read(4 * 1024 * 1024 + 1)
        if len(wire) > 4 * 1024 * 1024:
            raise ValueError('affinity transcript cap')
        for line in wire.splitlines():
            if json.loads(line).get('schema') in (SCHEMAS[0], SCHEMAS[1], SCHEMAS[4]):
                raise ValueError('undeclared timer handshake receipt')
        return None
    env = json.loads((root / 'environment.json').read_bytes())
    if env['role'] != 'source' or env['linux_environment']['selected_cpus'] != [0]:
        raise ValueError('timer affinity role/base mismatch')
    pid = json.loads((root / 'pid.json').read_bytes())['pid']
    reader = Transcript(root / 'stdout', cpu, pid)
    records = reader.poll()
    if len(records) != 5 or reader.pending:
        raise ValueError('incomplete timer lifecycle')
    proof = json.loads((root / 'timer-handshake.json').read_bytes())
    ident = identity(records[0], cpu, pid)
    if proof['identity'] != ident or proof['before']['pid'] != pid or proof['before']['start_ticks'] != ident['start_ticks'] or proof['before']['affinity'] != [0] or ident['timer_tid'] not in proof['before']['thread_ids']:
        raise ValueError('invalid startup evidence')
    if (proof.get('before_timer_start_ticks') != ident['timer_start_ticks']
            or not records[0]['monotonic_ns'] <= proof['before']['timestamp_ns'] <= records[1]['monotonic_ns']
            or not records[1]['monotonic_ns'] <= proof['applied']['timestamp_ns'] <= records[2]['monotonic_ns']):
        raise ValueError('handshake proof identity/timing')
    validate_sample(proof['applied'], dict(identity=ident, phase='active'))
    validate_record(proof['applied'], reader)
    return reader


def validate_record(sample, context):
    if context is None:
        if 'timer_affinity' in sample or 'thread_affinity' in sample:
            raise ValueError('undeclared timer evidence')
        return
    ident = identity(context.records[0], context.cpu, context.pid)
    phase = sample.get('timer_affinity', {}).get('phase')
    if phase == 'finished' and sample['timestamp_ns'] < context.records[4]['monotonic_ns']:
        raise ValueError('sample claims future finish')
    if sample['timestamp_ns'] < context.records[1]['monotonic_ns']:
        raise ValueError('sample before timer applied')
    validate_sample(sample, dict(identity=ident, phase=phase))

