"""Offline bounded identity join; local durations never establish deadline overlap."""
import struct
import hashlib
import json

def window_accounting(client):
    data=client.get('window_accounting')
    if data is None:return {'status':'unavailable','rows':[]}
    need(type(data) is dict and set(data)=={'rows','overflow'},'window accounting shape')
    uint(data['overflow']);need(type(data['rows']) is list and len(data['rows'])<=128,'window rows bound')
    prior={}
    for r in data['rows']:
        need(type(r) is list and len(r)==13,'window row shape')
        p,start,end,gap,pending,response,inflight,unknown,permits,issues,completed,first,coverage=r
        for v in r[:11]:uint(v)
        need(p<8 and start<end and end-start<=10000000,'window bounds')
        need(any(e[0]==p and e[3]<=start and end<=e[4] for e in client['rows']),'window expiration join')
        need(start>=prior.get(p,0),'window overlap');prior[p]=end
        need(type(coverage) is bool and sum(r[3:8])==end-start,'window conservation')
        if coverage:
            need(response==0 or completed>0,'response without completion')
            need(max(permits,issues,completed)-min(permits,issues,completed)<=1,'depth-one counts')
        need((coverage and unknown==0) or (not coverage and unknown==end-start),'window coverage')
        if first is not None:uint(first);need(start<=first<end and permits>0,'first permit')
        else:need(permits==0,'missing first permit')
    return {'status':'observed','rows':data['rows'],'overflow':data['overflow'], 'scope':'Partition-local observed occupancy, not network time; multi-window expiry attribution remains interval-level.'}

def need(ok,message):
    if not ok: raise ValueError(message)
def uint(v):
    need(type(v) is int and 0<=v<2**64,'integer');return v

def client_timings(client, keys):
    if client['schema']=='nbsr-correlation-client-v1': return {},0
    rows=client.get('timings');need(type(rows) is list and len(rows)<=128,'timing bound')
    overflow=uint(client.get('timing_overflow'));table={}
    for row in rows:
        need(type(row) is list and len(row)==5,'timing shape')
        stream,seq,issued,status,data=row
        key=(uint(stream),uint(seq));uint(issued);uint(status)
        need(key in keys and key not in table and status in (0,1,2),'timing identity/status')
        value=dict(status=['pending','missing','complete'][status],issued_ns=issued)
        if status!=2: need(data is None,'missing timing payload')
        else:
            need(type(data) is list and len(data)==7,'timing payload')
            read,validated,entry,observed,response,residual,phases=data
            for v in data[:6]:uint(v)
            need(issued<=read<=validated<=entry<=observed,'timing order')
            need(type(phases) is list and len(phases)==3,'timing phases')
            for phase in phases:
                need(type(phase) is list and len(phase)==12,'phase shape')
                for v in phase:uint(v)
                need((phase[0],phase[1]) in ((1,0),(0,1)),'phase coverage')
                covered,unknown,pending,ready,wakes,coalesced,wake_polls,wake_delay,poll,elapsed,budget,crossed=phase
                need(ready==covered and crossed<=covered,'phase readiness')
                need(coalesced<=wakes and wake_polls<=wakes-coalesced<=wake_polls+covered,'phase wake counters')
                need(poll<=elapsed and wake_delay<=elapsed,'phase duration')
                need(wake_polls>0 or wake_delay==0,'phase wake delay without observation')
                need(covered>0 or all(v==0 for i,v in enumerate(phase) if i!=1),'uncovered phase observations')
            # Existing coordinator clock sampled after acquiring its lock;
            # this is not mutex release, packet arrival, or wire transmission.
            value.update(read_return_ns=read,validated_ns=validated,completion_entry_ns=entry,completion_observed_ns=observed,response_ns=response,residual_ns=residual,phases=phases)
            if any(p[0]!=1 for p in phases):value['status']='partial'
        table[key]=value
    if client['schema']=='nbsr-correlation-client-v3':
        rows=client.get('issuance');need(type(rows) is list and len(rows)==len(table),'issuance coverage')
        seen=set()
        for row in rows:
            need(type(row) is list and len(row)==5,'issuance shape')
            stream,seq,permit,start,previous=row;key=(uint(stream),uint(seq))
            need(key in table and key not in seen,'issuance identity');seen.add(key)
            if permit is None:
                need(start is None and previous is None,'unknown issuance')
                table[key]['issuance']=dict(status='missing');continue
            uint(permit);uint(start);need(start<=permit<=table[key]['issued_ns'],'issuance order')
            eligible=start;prior=None
            if previous is not None:
                need(type(previous) is list and len(previous)==6,'preceding shape')
                ps,pq,issued,read,observed,response=previous
                for v in [ps,pq,issued,observed,response]:uint(v)
                need(ps==stream and pq+1==seq and issued<=observed<=permit,'preceding identity/order')
                if read is not None:uint(read);need(issued<=read<=observed,'preceding read order')
                eligible=max(start,observed)
                prior=dict(stream=ps,sequence=pq,issued_ns=issued,read_return_ns=read,completion_observed_ns=observed,response_ns=response)
            table[key]['issuance']=dict(status='observed',permit_ns=permit,window_start_ns=start,eligible_lower_bound_ns=eligible,eligibility_to_permit_ns=permit-eligible,permit_to_issue_ns=table[key]['issued_ns']-permit,previous=prior,scope='Capacity/window lower bound, not task runnable time; prior history before previous request is unobserved.')
    need(len(keys)-len(table)==overflow,'unexplained timing coverage')
    return table,overflow

def correlate(client,server,run):
    need(type(run) is str and len(run)==32 and all(c in '0123456789abcdef' for c in run),'run identity')
    need(client.get('schema') in ('nbsr-correlation-client-v1','nbsr-correlation-client-v2','nbsr-correlation-client-v3') and client.get('run')==run,'client identity')
    need(type(server) is bytes and 80<=len(server)<=80+400000*32,'server size')
    need(server[:8]==b'NBSRCOR1' and server[8:40]==run.encode(),'server identity')
    attempted,invalid,overflow,ignored,count=struct.unpack('<QQQQQ',server[40:80])
    need(count<=400000 and len(server)==80+count*32 and attempted==count+invalid+overflow+ignored,'server counts')
    need(invalid==overflow==0,'incomplete server coverage')
    table={}
    for stream,seq,a,b in struct.iter_unpack('<QQQQ',server[80:]):
        key=(stream,seq);need(key not in table,'duplicate server identity');need(a+b<2**64,'duration overflow');table[key]=(a,b)
    need(type(client['rows']) is list and len(client['rows'])<=4096,'client bound')
    need(uint(client['overflow'])==0,'incomplete client coverage')
    total=matched=unknown=0;matches=[];ends={}
    for row in client['rows']:
        need(type(row) is list and len(row)==6,'expiration shape')
        part,first,end,after,through,key=row
        for v in row[:5]:uint(v)
        need(part<8 and first<end and after<through,'expiration range')
        prior=ends.get(part,(0,0));need(first>=prior[0] and after>=prior[1],'overlapping expiration ranges');ends[part]=(end,through)
        n=end-first;total+=n
        if key is None:unknown+=n;continue
        need(type(key) is list and len(key)==2,'key shape');key=tuple(uint(v) for v in key)
        need(key in table,'missing server identity');a,b=table[key];matched+=n
        matches.append(dict(partition=part,slot_range=[first,end],boundary_interval=[after,through],stream=key[0],sequence=key[1],server_read_to_write_ns=a,server_write_ns=b,server_turnaround_ns=a+b))
    need(total==uint(client['expired']),'expired reconciliation')
    timings,overflow=client_timings(client,{(m['stream'],m['sequence']) for m in matches})
    coverage=dict(complete_slots=0,partial_slots=0,missing_slots=unknown,overflow_requests=overflow)
    for m in matches:
        timing=timings.get((m['stream'],m['sequence']))
        m['client_timing']=timing
        category=timing['status'] if timing else 'missing'
        bucket=category if category in ('complete','partial') else 'missing'
        coverage[bucket+'_slots']+=m['slot_range'][1]-m['slot_range'][0]
    return dict(window_accounting=window_accounting(client),matched_slots=matched,unidentified_slots=unknown,matches=matches,client_timing_coverage=coverage,causal_overlap_established=False)


def validate_bundle(client_bytes,server,manifest,expected,final):
    # expected pins and final must come from the independently validated run receipt.
    need(type(client_bytes) is bytes and len(client_bytes)<=1024*1024,'client size')
    fields=('run','connections','streams','depth','rate','payload','duration_seconds','source_sha256','client_binary_sha256','server_binary_sha256','client_sha256','server_sha256')
    need(all(k in expected and manifest.get(k)==expected[k] for k in fields),'provenance mismatch')
    for k in fields[-5:]:
        v=expected[k];need(type(v) is str and len(v)==64 and all(c in '0123456789abcdef' for c in v),'provenance digest')
    for k,v in dict(connections=1,streams=8,depth=1,rate=16000,payload=1024,duration_seconds=20).items():
        need(type(expected[k]) is int and expected[k]==v,'workload envelope')
    need(manifest.get('client_sha256')==hashlib.sha256(client_bytes).hexdigest(),'client digest')
    need(type(server) is bytes and manifest.get('server_sha256')==hashlib.sha256(server).hexdigest(),'server digest')
    need(final.get('integrity_complete') is True,'incomplete final accounting')
    for k in ('scheduled','issued','completed','unissued','failed','unresolved'):uint(final[k])
    need(final['scheduled']==320000 and final['scheduled']==final['issued']+final['unissued'],'scheduled reconciliation')
    need(final['issued']==final['completed'] and final['failed']==final['unresolved']==0,'completion reconciliation')
    client=json.loads(client_bytes)
    need(type(client) is dict and client.get('expired')==final['unissued'],'final expiration reconciliation')
    result=correlate(client,server,expected['run'])
    result['provenance_verified']=True
    return result
