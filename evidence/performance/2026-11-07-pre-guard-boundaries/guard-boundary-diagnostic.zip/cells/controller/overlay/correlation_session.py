"""Correlation hooks: no transport/process creation; callers retain ownership."""
import hashlib
import json
from pathlib import Path
from scripts.performance.correlation_collection import identity,collect,validate_collected,NAMES
from scripts.performance.request_correlation import need

def small(path,cap):
    need(not path.is_symlink() and path.is_file() and path.stat().st_size<=cap,'metadata size/type')
    with path.open('rb') as f:data=f.read(cap+1)
    need(len(data)<=cap,'metadata bound');return data

class Session:
    def __init__(self,pins):
        self.pins=dict(pins);identity(self.pins['run']);self.receipts={}
        for key in ['source_sha256','client_binary_sha256','server_binary_sha256','build_manifest_sha256']:
            v=self.pins[key];need(type(v) is str and len(v)==64 and all(c in '0123456789abcdef' for c in v),'trusted pin')
    def validate_config(self,config):
        from scripts.performance.correlation_handoff import validate_config
        need(validate_config(config)==self.pins['run'],'activation run pin')
        for k,v in dict(path='nbsr',payload=1024,streams=8,depth=1,benchmark_seconds=20,diagnostic_rate=[16000,1],post_close_reports=True).items():need(config.get(k)==v,'activation workload '+k)
        for role in NAMES:need(config[role]['cores']==1,'activation CPU')
        for k,v in dict(connections=1,streams=8,depth=1,rate=16000,payload=1024,duration_seconds=20).items():need(type(self.pins.get(k)) is int and self.pins[k]==v,'pinned workload')
    def capture(self,role,root,verify_index):
        need(role in NAMES and role not in self.receipts,'duplicate/invalid role')
        root=Path(root);index=verify_index(root);peer=root/'peer'
        build=small(peer/'build-manifest.json',1024*1024)
        need(hashlib.sha256(build).hexdigest()==self.pins['build_manifest_sha256'],'build manifest pin')
        build=json.loads(build)
        need(build.get('patch_sha256')==self.pins['source_sha256'],'source pin')
        for name,key in [('perf_rust_source','client_binary_sha256'),('wp8_interop_server','server_binary_sha256')]:
            need(build['binary_sha256'][name]==self.pins[key],'build binary pin')
        executed=json.loads(small(peer/'executed-binary.json',4096))
        binary=self.pins['client_binary_sha256' if role=='source' else 'server_binary_sha256']
        need(executed.get('proc_exe_verified') is True and executed.get('sha256')==binary,'executed binary')
        receipt=json.loads(small(peer/'correlation-file.json',4096))
        need(receipt.get('schema')=='nbsr-correlation-file-v1' and receipt.get('run')==self.pins['run'] and receipt.get('role')==role and receipt.get('name')==NAMES[role][0],'receipt identity')
        data=collect(role,peer,receipt['sha256']);need(receipt.get('bytes')==len(data),'receipt bytes')
        need(verify_index(root)==index,'index changed during capture')
        self.receipts[role]=dict(index_sha256=index,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
        return dict(self.receipts[role])
    def finish(self,root,final,verify_index):
        need(set(self.receipts)==set(NAMES),'both captured endpoints required');root=Path(root)
        for role,row in self.receipts.items():need(verify_index(root/role)==row['index_sha256'],'captured index changed')
        expected=dict(self.pins,client_sha256=self.receipts['source']['sha256'],server_sha256=self.receipts['destination']['sha256'])
        result=validate_collected(root/'source'/'peer',root/'destination'/'peer',dict(expected),expected,final)
        result['collection_receipts']=self.receipts.copy()
        result['trust_scope']='Locally pinned build and captured verified SSH collection indexes; not remote attestation.'
        return result

def activate(base,run):
    identity(run);need(not getattr(base,'_correlation_active',False),'duplicate activation configuration')
    original=base.config
    def config():
        value=dict(original())
        need('correlation_run' not in value or value['correlation_run']==run,'activation run pin')
        value['correlation_run']=run
        from scripts.performance.correlation_handoff import validate_config
        validate_config(value)
        return value
    base.config=config;base._correlation_active=True
