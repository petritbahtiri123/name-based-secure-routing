"""Strict sidecar validation; authentication by the enclosing archive is separate."""
import json,ipaddress
def integer(x,minimum=0,maximum=2**64-1):
    if type(x) is not int or not minimum<=x<=maximum:raise ValueError('invalid integer')
    return x
def object_pairs(rows):
    d={}
    for k,v in rows:
        if k in d:raise ValueError('duplicate key')
        d[k]=v
    return d
def validate(blob, *, run, pid, start_ticks, origin_ns, domain='b5-client-monotonic',expected_sockets=None,measurement_end_ns=None):
    if not isinstance(blob,bytes) or not 1<=len(blob)<=65536:raise ValueError('size')
    try:
        if domain not in ('b5-client-monotonic','fixture-monotonic'):raise ValueError('unsupported clock domain')
        if not isinstance(expected_sockets,list) or not 1<=len(expected_sockets)<=4:raise ValueError('external socket identity required')
        for e in expected_sockets:
            if set(e)!={'generation','fd','inode','local'}:raise ValueError('expected socket fields')
            integer(e['generation'],1,4);integer(e['fd'],0,2**31-1);integer(e['inode'],1)
        if domain=='b5-client-monotonic' and measurement_end_ns is None:raise ValueError('measurement end required')
        if measurement_end_ns is not None and integer(measurement_end_ns)<=origin_ns:raise ValueError('invalid measurement span')
        v=json.loads(blob,object_pairs_hook=object_pairs)
        if set(v)!=set('schema complete run role pid start_ticks clock started_ns ended_ns origin_ns registration_failures sockets'.split()):raise ValueError('fields')
        if v['schema']!='nbsr-recv-errors-v1' or v['complete'] is not True:raise ValueError('incomplete')
        for key,want in [('run',run),('role','source'),('pid',pid),('start_ticks',start_ticks),('clock',domain),('origin_ns',origin_ns)]:
            if v[key]!=want or type(v[key]) is not type(want):raise ValueError('identity')
        integer(v['pid'],1,2**32-1);integer(v['start_ticks'],1);integer(v['registration_failures'])
        start=integer(v['started_ns']);end=integer(v['ended_ns']);integer(origin_ns)
        if start>end or v['registration_failures']!=0:raise ValueError('coverage')
        if domain=='b5-client-monotonic' and not start<=origin_ns<=end:raise ValueError('origin coverage')
        if not isinstance(v['sockets'],list) or len(v['sockets'])!=len(expected_sockets):raise ValueError('socket count')
        total=0;events=[]
        for n,s in enumerate(v['sockets'],1):
            if set(s)!=set('generation fd inode local registered_ns retired_ns total overflow unknown events'.split()):raise ValueError('socket fields')
            if integer(s['generation'],1)!=n:raise ValueError('generation')
            if {key:s[key] for key in expected_sockets[n-1]}!=expected_sockets[n-1]:raise ValueError('external socket mismatch')
            integer(s['fd'],0,2**31-1);integer(s['inode'],1)
            host,port=s['local'].rsplit(':',1);ipaddress.ip_address(host.strip('[]'));integer(int(port),0,65535)
            a=integer(s['registered_ns']);b=integer(s['retired_ns'])
            if not start<=a<=b<=end:raise ValueError('lifetime')
            if measurement_end_ns is not None and not a<=origin_ns<measurement_end_ns<=b:raise ValueError('socket does not cover measurement')
            for f in ['total','overflow','unknown']:integer(s[f])
            if s['overflow'] or s['unknown'] or not isinstance(s['events'],list) or len(s['events'])>128 or s['total']!=len(s['events']):raise ValueError('loss or total')
            if sorted(integer(e['sequence'],1) for e in s['events'])!=list(range(1,s['total']+1)):raise ValueError('sequence')
            for e in s['events']:
                if set(e)!={'sequence','ns','errno'}:raise ValueError('event fields')
                if not a<=integer(e['ns'])<=b:raise ValueError('event lifetime')
                if integer(e['errno'],1,4095)==11:raise ValueError('WouldBlock not eligible')
                events.append(dict(socket_generation=n,**e))
            total+=s['total']
        measured=None if measurement_end_ns is None else [e for e in events if origin_ns<=e['ns']<measurement_end_ns]
        return dict(total=total,events=events,socket_count=len(v['sockets']),coverage=[start,end],measurement_events=measured,coverage_scope='FIXTURE_IDENTITY_ONLY' if measurement_end_ns is None else 'EXPECTED_MEASUREMENT_SOCKETS')
    except (KeyError,TypeError,AttributeError,UnicodeError,json.JSONDecodeError) as e:raise ValueError('malformed sidecar') from e
