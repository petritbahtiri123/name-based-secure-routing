"""Explicit bounded sidecar hooks; no process creation or remote operations."""
import hashlib
import json
import os
from pathlib import Path
import stat
from scripts.performance.request_correlation import need

NAMES={'source':('correlation-client.json',1024*1024),'destination':('correlation-server.bin',80+400000*32)}
def identity(run):
    need(type(run) is str and len(run)==32 and all(c in '0123456789abcdef' for c in run),'run identity')

def prepare(role,root,run,cell):
    if run is None:return {}
    identity(run)
    need(role in NAMES,'role')
    root=Path(root);need(root.is_absolute() and not root.is_symlink(),'output root')
    for k,v in dict(path='nbsr',cores=1,payload_bytes=1024,streams=8,outstanding=1,benchmark_seconds=20,diagnostic_rate=[16000,1]).items():
        need(cell.get(k)==v,'correlation workload '+k)
    need('operations_per_stream' not in cell,'fixed work unsupported')
    path=root/NAMES[role][0];need(not os.path.lexists(path),'fresh sidecar required')
    return dict(NBSR_CORRELATION_RUN=run,NBSR_CORRELATION_FILE=str(path))

def read_bounded(role,root):
    need(role in NAMES,'role');name,cap=NAMES[role];root=Path(root)
    need(not root.is_symlink(),'root link');path=root/name
    info=path.lstat();need(stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_size<=cap,'sidecar type/size')
    with path.open('rb') as f:
        opened=os.fstat(f.fileno());need((opened.st_dev,opened.st_ino)==(info.st_dev,info.st_ino),'sidecar changed')
        data=f.read(cap+1);after=os.fstat(f.fileno())
    need(len(data)<=cap and len(data)==info.st_size and (opened.st_size,opened.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'unstable sidecar')
    return data

def collect(role,root,expected_sha256):
    # Digest must come from an independently pinned endpoint index/receipt.
    need(type(expected_sha256) is str and len(expected_sha256)==64 and all(c in '0123456789abcdef' for c in expected_sha256),'digest')
    data=read_bounded(role,root)
    need(hashlib.sha256(data).hexdigest()==expected_sha256,'sidecar digest')
    return data

def seal(role,root,run):
    identity(run);data=read_bounded(role,root)
    if role=='source':
        value=json.loads(data);need(value.get('schema') in ('nbsr-correlation-client-v1','nbsr-correlation-client-v2','nbsr-correlation-client-v3') and value.get('run')==run,'client identity')
    else:need(len(data)>=80 and data[:8]==b'NBSRCOR1' and data[8:40]==run.encode(),'server identity')
    receipt=dict(schema='nbsr-correlation-file-v1',run=run,role=role,name=NAMES[role][0],bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    with (Path(root)/'correlation-file.json').open('x',encoding='utf-8') as f:json.dump(receipt,f)
    return receipt


def validate_collected(source_root,destination_root,manifest,expected,final):
    from scripts.performance.request_correlation import validate_bundle
    client=collect('source',source_root,expected['client_sha256'])
    server=collect('destination',destination_root,expected['server_sha256'])
    return validate_bundle(client,server,manifest,expected,final)
