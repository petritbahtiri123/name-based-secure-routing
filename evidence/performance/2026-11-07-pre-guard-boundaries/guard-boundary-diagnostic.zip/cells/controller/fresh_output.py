"""Count only this run's fresh evidence trees; sampled, not a quota."""
import os,stat

def count_output(root, *, max_entries=100_000):
    """Count a fresh output tree, failing on unreadable or unexpected entries."""
    root = os.fspath(root)
    if not os.path.isabs(root) or type(max_entries) is not int or max_entries <= 0:
        raise ValueError('invalid output root')
    info = os.lstat(root)
    if not stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode):
        raise ValueError('output root is not a directory')
    total = 0
    entries = 0
    pending = [root]
    while pending:
        with os.scandir(pending.pop()) as children:
            for child in children:
                entries += 1
                if entries > max_entries:
                    raise ValueError('output entry limit')
                info = child.stat(follow_symlinks=False)
                if stat.S_ISDIR(info.st_mode):
                    pending.append(child.path)
                elif stat.S_ISREG(info.st_mode) and info.st_size >= 0:
                    total += info.st_size
                else:
                    raise ValueError('unexpected output entry')
    return total
