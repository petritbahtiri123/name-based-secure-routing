"""Exclusive bounded public harness IPC. No hostile-local-process trust claim."""
import os
import pathlib
from session_wire import decode,MAX_FRAME

SLOTS={'reply-0','reply-1','reply-2','reply-3','request-1','request-2','request-3',
       'broker-final','ownership-final'}

def paths(root,slot):
    if slot not in SLOTS:raise ValueError('fixed IPC slot required')
    root=pathlib.Path(root)
    info=root.lstat()
    if root.is_symlink() or getattr(info,'st_file_attributes',0)&0x400 or not root.is_dir():
        raise ValueError('IPC root identity')
    return root/(slot+'.json'),root/(slot+'.ready')

def publish(root,slot,wire):
    decode(wire);body,ready=paths(root,slot)
    if os.path.lexists(ready):raise FileExistsError('IPC slot already published')
    with body.open('xb') as stream:stream.write(wire)
    with ready.open('xb'):pass

def read(root,slot):
    body,ready=paths(root,slot)
    if not os.path.lexists(ready):return None
    for path in (body,ready):
        info=path.lstat()
        if path.is_symlink() or getattr(info,'st_file_attributes',0)&0x400 or not path.is_file():
            raise ValueError('IPC file identity')
    if ready.stat().st_size:raise ValueError('invalid ready marker')
    with body.open('rb') as stream:wire=stream.read(MAX_FRAME+1)
    decode(wire)
    return wire
