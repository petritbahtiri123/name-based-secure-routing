"""In-memory payload built from exact task-local sources and existing clock code."""
import base64,pathlib,shlex
import internal_clock
from session_wire import run_id
SSH_PREFIX=['ssh','-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','-o','ConnectionAttempts=1','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2','nbsr-client']

def bundle(run,*,inspect=False):
    run_id(run);root=pathlib.Path(__file__).parent
    lines=['import sys,types,json']
    for name in ('session_wire','session_agent','session_remote'):
        code=(root/(name+'.py')).read_text();compile(code,name,'exec')
        lines.append('m=types.ModuleType('+repr(name)+');sys.modules['+repr(name)+']=m;exec('+repr(code)+',m.__dict__)')
    lines.append('print(json.dumps(m.inspect('+repr(run)+')))' if inspect else 'm.main('+repr(run)+','+repr(internal_clock.payload())+')')
    return '\n'.join(lines)

def command(run,*,inspect=False):
    # Compress only source packaging, not protocol data. No files are installed.
    import zlib
    encoded=base64.b64encode(zlib.compress(bundle(run,inspect=inspect).encode())).decode()
    loader="import base64,zlib;exec(zlib.decompress(base64.b64decode('"+encoded+"')))"
    remote=shlex.join(['timeout','--kill-after=2s','8s' if inspect else '70s','python3','-u','-B','-c',loader])
    result=SSH_PREFIX+[remote]
    if sum(map(len,result))>28000:raise ValueError('SSH command size')
    return result
