"""Calibration-only bridge across the existing parent/coordinator boundary."""
import ctypes,json,pathlib,time
import bounded,resource_boundary,internal_clock,internal_exchange
from session_owner import OwnedSession
from session_client import Client
from session_payload import command

def guard_for(here):
    here=pathlib.Path(here)
    def guard():
        counts=resource_boundary.check(starting=False,groups={'artifacts':[here.parent],'output':[here/'calibration-session']})
        admission=json.loads((here/'LOCAL-ADMISSION.json').read_text())
        if counts['task']-admission['retained_bytes']>32*1024**2:raise RuntimeError('whole arm growth cap')
        m=bounded.MemoryStatus();m.length=ctypes.sizeof(m)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)) or min(m.available,m.page_available)<2*1024**3:raise RuntimeError('laptop memory reserve')
        if counts['artifacts']>7*1024**3 or counts['output']>16*1024**2:raise RuntimeError('artifact/output cap')
    return guard

def create(here,run):
    here=pathlib.Path(here);resource_boundary.check(starting=True)
    return OwnedSession(here/'calibration-session',run,command(run),guard=guard_for(here),
        external_cancel=here/'run01-trial/cancel')

def save_calibration(path,payload):
    result=payload['result']
    if result.get('failure') or result.get('exit')!=0 or result.get('reader_stopped') is not True:
        raise ValueError('internal clock failed')
    internal_clock.envelope(result['probes'],result['probes'],90_000_000_000)
    with pathlib.Path(path).open('x') as f:json.dump(result,f,indent=2)
    return result

def pre(owner,here):
    here=pathlib.Path(here);result=owner.open_pre()
    save_calibration(here/'calibration-before.json',result)
    from calibration_sequence import Window
    Window(owner.started).admit_pre()
    with (here/'calibration-anchor.json').open('x') as f:json.dump(dict(local_monotonic=owner.started),f)
    return result

def post(here,run):
    here=pathlib.Path(here);client=Client(here/'calibration-session',run,guard=guard_for(here))
    try:
        result=client.exchange('POST');save_calibration(here/'calibration-after.json',result)
        client.exchange('CLOSE')
        return internal_exchange.validate_pair(here)
    except BaseException:client.cancel();raise

def verify_remote(here,run,deadline):
    here=pathlib.Path(here);remaining=deadline-time.monotonic()
    if remaining<=0:raise TimeoutError('original finalization budget expired before calibration cleanup check')
    output=here/'calibration-remote-absence'
    bounded.run(command(run,inspect=True),output,min(10,remaining),consoleless=True)
    wire=(output/'stdout.log').read_bytes()
    if len(wire)>8192:raise ValueError('remote receipt output cap')
    value=json.loads(wire)
    with (here/'calibration-remote-observation.json').open('x') as f:json.dump(value,f,indent=2)
    if time.monotonic()>=deadline:raise TimeoutError('original finalization budget expired during calibration cleanup check')
    if value['status']!='REMOTE_CLOSED' or value['run']!=run:raise ValueError('remote calibration cleanup incomplete')
    with (here/'calibration-remote-closed.json').open('x') as f:json.dump(value,f,indent=2)
    return value
