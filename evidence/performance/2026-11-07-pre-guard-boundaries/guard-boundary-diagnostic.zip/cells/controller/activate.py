import os,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[1]/'collector' if os.name=='nt' else pathlib.Path('/home/petritbahtiri24/nbsr-sphere-20261016-01/repo')

def validate_environment(env):
 for key in env:
  upper=key.upper()
  if upper in ("LD_PRELOAD","LD_AUDIT") or (upper.startswith("NBSR_") and any(x in upper for x in ("BPF","TRACE","COLLECTOR","CPU_CLOCK"))):
   raise RuntimeError("conflicting diagnostic environment: "+key)

def activate():
 validate_environment(os.environ)
 sys.path.insert(0,str(REPO))
 import scripts.performance
 scripts.performance.__path__.insert(0,str(HERE/'overlay'))
