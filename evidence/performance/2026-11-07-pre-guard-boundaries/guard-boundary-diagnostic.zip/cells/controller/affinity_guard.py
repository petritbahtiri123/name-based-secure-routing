"""Bounded read-only native-thread observations; no scheduling mutations."""
import json,os,pathlib,time
def validate_masks(rows,receipt,cpu):
 if receipt['timer_cpu']!=cpu or receipt['other_cpu']!=0:raise ValueError('affinity arm receipt')
 tids=[r['tid'] for r in rows]
 if len(tids)!=len(set(tids)) or receipt['timer_tid'] not in tids or receipt['pid'] not in tids:raise ValueError('native thread coverage')
 for r in rows:
  expected=[cpu] if r['tid']==receipt['timer_tid'] else [0]
  if r['mask']!=expected:raise ValueError('native thread mask')
  if r['tid']==receipt['timer_tid'] and r['start_ticks']!=receipt['timer_start_ticks']:raise ValueError('timer identity')
  if r['tid']==receipt['pid'] and r['start_ticks']!=receipt['start_ticks']:raise ValueError('native identity')
def start_ticks(p):return int(p.read_text().rsplit(')',1)[1].split()[19])
def validate_coverage(samples,lo,hi):
 if not 0<=hi-lo<=10_000_000:raise ValueError('measurement start bracket')
 times=[s['monotonic']*1e9 for s in samples]
 if len(times)<18 or any(b<=a or b-a>2e9 for a,b in zip(times,times[1:])):raise ValueError('affinity sample timing')
 if times[0]>hi+2e9 or times[-1]<lo+18e9 or times[-1]-times[0]<17e9:raise ValueError('affinity edge coverage')
 if len({int((t-hi)//1e9) for t in times if hi<=t<lo+20e9})<18:raise ValueError('affinity distinct measurement buckets')
class Watch:
 def __init__(self,peer,cpu):self.peer=pathlib.Path(peer);self.cpu=cpu;self.receipt=None;self.samples=[];self.final=False;self.started=None
 def poll(self):
  stdout=self.peer/'stdout'
  if not stdout.exists():return
  if stdout.stat().st_size>4*1024**2:raise ValueError('stdout cap')
  lines=stdout.read_text().splitlines();records=[]
  for s in lines:
   try:r=json.loads(s)
   except json.JSONDecodeError:continue
   if r.get('schema')=='nbsr-timer-affinity-ready-v1':records.append(r)
   if r.get('schema')=='nbsr-affinity-measurement-started-v1':
    if self.started is not None and self.started!=r:raise ValueError('measurement receipt changed')
    self.started=r
   if r.get('schema')=='nbsr-b5-grouped-final-v1':self.final=True
  if len(records)>1:raise ValueError('duplicate affinity readiness')
  if not records:return
  receipt=records[0]
  if self.receipt is not None and receipt!=self.receipt:raise ValueError('affinity receipt changed')
  self.receipt=receipt
  now=time.monotonic()
  if self.started is None:return
  lo=receipt['monotonic_ns'];hi=self.started['monotonic_ns']
  if not 0<=hi-lo<=10_000_000:raise ValueError('measurement start bracket')
  if self.final or now*1e9>=lo+20_000_000_000:return
  pid=json.loads((self.peer/'pid.json').read_text())['pid']
  if receipt['pid']!=pid:raise ValueError('owned native PID mismatch')
  rows=[]
  try:
   for p in (pathlib.Path('/proc')/str(pid)/'task').iterdir():
    tid=int(p.name);row=dict(tid=tid,start_ticks=start_ticks(p/'stat'),mask=sorted(os.sched_getaffinity(tid)))
    if row['mask']!=([self.cpu] if tid==receipt['timer_tid'] else [0]):raise ValueError('native thread mask')
    if tid==receipt['timer_tid'] and row['start_ticks']!=receipt['timer_start_ticks']:raise ValueError('timer identity')
    if tid==receipt['pid'] and row['start_ticks']!=receipt['start_ticks']:raise ValueError('native identity')
    rows.append(row)
  except (FileNotFoundError,ProcessLookupError):
   if time.monotonic()*1e9>=lo+20_000_000_000:return
   raise
  finished=time.monotonic()
  if finished*1e9>=lo+20_000_000_000:return
  if not 0<=finished-now<=.05:raise ValueError('affinity scan duration')
  validate_masks(rows,receipt,self.cpu)
  if len(self.samples)>=64:raise ValueError('affinity sample cap')
  self.samples.append(dict(monotonic=finished,scan_start=now,threads=rows))
 def finish(self):
  self.poll()
  if self.receipt is None or self.started is None or not self.final:raise ValueError('incomplete affinity coverage')
  validate_coverage(self.samples,self.receipt['monotonic_ns'],self.started['monotonic_ns'])
  return dict(receipt=self.receipt,started=self.started,samples=self.samples,coverage='pre-ready native check plus periodic host observations; not continuous tracing')
