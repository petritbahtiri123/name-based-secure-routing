import pathlib,sys,json,hashlib,shlex,time
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));import bounded,plan
def sealed_inputs():
 pins=json.loads((HERE/'staging-inventory.json').read_text())
 if not isinstance(pins,dict) or not pins:raise ValueError('sealed staging inventory required')
 for name,digest in pins.items():
  path=pathlib.PurePosixPath(name)
  if path.is_absolute() or '..' in path.parts or str(path)!=name or '\\' in name or ':' in name or not (len(path.parts)==1 or (len(path.parts)==2 and path.parts[0]=='overlay')):raise ValueError('unapproved staging member')
  source=HERE/name
  if source.is_symlink() or not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest()!=digest:raise ValueError('staging input changed')
 required={'overlay/recv_error_handoff.py','overlay/recv_error_collection.py','overlay/recv_error_validate.py','overlay/linux_socket_ownership.py','overlay/linux_native_finite_run.py','release-pins.json','release-build-manifest.json'}
 if not required<=pins.keys():raise ValueError('incomplete diagnostic staging inventory')
 return sorted(n for n in pins if '/' not in n),sorted(n.split('/',1)[1] for n in pins if n.startswith('overlay/')),pins
def ssh(role,argv):return ['ssh','-T','--',plan.HOSTS[role],shlex.join(argv)]
def call(role,action):return [plan.ROOT+'/venv/bin/python','-B',plan.CONTROL+'/remote_ops.py',action,role]
def run(role,step,argv,work=20):return bounded.run(argv,HERE/('step-'+role+'-'+step),work)
def prepare(roles=('source','destination')):
 PUBLIC,OVERLAY,pins=sealed_inputs()
 prepared=[]
 try:
  for role in roles:
   manifest=json.loads((HERE/'release-build-manifest.json').read_text())
   create="import pathlib,os,hashlib,shutil; p=pathlib.Path("+repr(plan.ROOT)+"); assert str(p.resolve(strict=True))==str(p) and p.stat().st_uid==os.getuid()==1001; assert shutil.disk_usage(p).free>=10*1024**3+256*1024**2 and shutil.disk_usage('/run').free>=32*1024**2; b=pathlib.Path("+repr(plan.config()[role]['binaries'])+"); h="+repr(manifest['binary_sha256'])+"; assert all(not (b/n).is_symlink() and hashlib.sha256((b/n).read_bytes()).hexdigest()==v for n,v in h.items()); q=pathlib.Path("+repr(plan.CONTROL)+"); q.mkdir(mode=0o700,exist_ok=False); (q/'overlay').mkdir(mode=0o700)"
   run(role,'create-control',ssh(role,['python3','-B','-c',create]))
   run(role,'transfer-control',['scp',*[str(HERE/n) for n in PUBLIC],plan.HOSTS[role]+':'+plan.CONTROL+'/'],90)
   run(role,'transfer-overlay',['scp',*[str(HERE/'overlay'/n) for n in OVERLAY],plan.HOSTS[role]+':'+plan.CONTROL+'/overlay/'],90)
   check="import pathlib,hashlib,json; p=pathlib.Path("+repr(plan.CONTROL)+"); pins="+repr(pins)+"; assert all(not (p/n).is_symlink() and hashlib.sha256((p/n).read_bytes()).hexdigest()==h for n,h in pins.items()); print(json.dumps({'verified_files':len(pins)}))"
   run(role,'verify-control',ssh(role,['python3','-B','-c',check]))
   run(role,'preflight',ssh(role,call(role,'preflight')))
   run(role,'prepare-mountpoints',ssh(role,call(role,'prepare-mountpoints')));prepared.append(role)
   run(role,'capability',ssh(role,plan.service(role,call(role,'smoke'),smoke=True)))
   receipt=json.loads((HERE/('step-'+role+'-capability')/'stdout.log').read_text())
   if receipt.get('status')!='PASS_CAPABILITY_ONLY':raise ValueError('capability gate')
   run(role,'capability-absence',ssh(role,call(role,'smoke-absence')))
   (HERE/(role+'-capability-PASS.json')).write_text(json.dumps(receipt,indent=2))
 except BaseException:
  for role in prepared:
   try:run(role,'preparation-rollback',ssh(role,call(role,'cleanup-mountpoints')))
   except BaseException:pass
  raise
 print('Both fresh capability gates passed; no TLS or workload yet')
if __name__=='__main__':prepare()
