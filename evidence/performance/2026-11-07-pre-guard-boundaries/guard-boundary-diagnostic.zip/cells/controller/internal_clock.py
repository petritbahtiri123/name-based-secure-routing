"""Reuse the reviewed three-probe protocol on the client, not across the WAN.

No files, credentials or services are created remotely. Pre/post results are
conditional on relative clock drift <=100 ppm over <=90 seconds, not a proven
physical bound. Every sample is retained; no minimum-RTT selection.
"""
import base64, hashlib, json, pathlib, shlex

HOST='petritbahtiri24@172.30.0.12'
MAX_WIDTH_NS=200_000_000

def payload():
    text=pathlib.Path(__file__).with_name('clock_probe.py').read_text()
    old='from throttle_intervals import offset_probe'
    new='def offset_probe(a,r,b):\n    if b<a:raise ValueError("clock order")\n    return r-b,r-a'
    assert text.count(old)==1;text=text.replace(old,new)
    old="host not in ('nbsr-client','nbsr-server')"
    assert text.count(old)==1;text=text.replace(old,'host != '+repr(HOST))
    old="'-o','BatchMode=yes'"
    assert text.count(old)==1
    text=text.replace(old,"'-o','StrictHostKeyChecking=yes','-o','ForwardAgent=no',"+old)
    old='value=probe(sys.argv[1])'
    assert text.count(old)==1;text=text.replace(old,'value=probe('+repr(HOST)+')')
    compile(text,'emitted-internal-clock.py','exec')
    return text

def remote_command(seconds=18):
    if not 6<=seconds<=18:raise ValueError('clock timeout bounds')
    encoded=base64.b64encode(payload().encode()).decode()
    return shlex.join(['timeout','--kill-after=2s',str(seconds)+'s','python3','-u','-B','-c',
                      "import base64;exec(base64.b64decode('"+encoded+"'))"])

def envelope(before,after,span_ns):
    if len(before)!=3 or len(after)!=3 or not 0<=span_ns<=90_000_000_000:
        raise ValueError('calibration coverage/span')
    bounds=[]
    for row in before+after:
        a,b=row['offset_lo_ns'],row['offset_hi_ns']
        if type(a) is not int or type(b) is not int or a>b or b-a>250_000_000:
            raise ValueError('original per-probe gate')
        bounds.append((a,b))
    # Envelope, not intersection: retain all pre/post observed intervals.
    allowance=(span_ns+9999)//10000 # Conditional 100 ppm relative drift.
    result=min(a for a,b in bounds)-allowance,max(b for a,b in bounds)+allowance
    if result[1]-result[0]>50_000_000:raise ValueError('internal offset width >50ms')
    return result

def classify(event,omission):
    from throttle_intervals import classify as original
    if event[1]-event[0]>MAX_WIDTH_NS:return 'ambiguous_resolution'
    return original(event,omission)

if __name__=='__main__':
    print(json.dumps({'remote_command':remote_command(),
                      'payload_sha256':hashlib.sha256(payload().encode()).hexdigest()}))
