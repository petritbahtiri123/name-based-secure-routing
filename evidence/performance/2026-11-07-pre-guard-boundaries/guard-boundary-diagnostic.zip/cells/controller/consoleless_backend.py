"""Opt-in console-free management worker; detached console never means Job breakaway."""
import ctypes as C
import os
import subprocess
from pathlib import Path
from diagnostic_backend import DiagnosticBackend
from scripts.performance import windows_job_backend as original

class ConsolelessBackend(DiagnosticBackend):
    def create_suspended(self, argv):
        if (not argv or not os.path.isabs(argv[0])
                or any(type(arg) is not str or '\0' in arg for arg in argv)):
            raise ValueError('absolute executable and exact argv required')
        command=C.create_unicode_buffer(subprocess.list2cmdline(argv))
        startup,process=original.Startup(),original.ProcessInfo()
        startup.cb=C.sizeof(startup)
        # CREATE_SUSPENDED | DETACHED_PROCESS. No inherited handles, console,
        # breakaway or privilege change. Original owner assigns before resume.
        self._check(self.kernel.CreateProcessW(argv[0],command,None,None,False,
            0x00000004 | 0x00000008,None,str(Path(original.__file__).resolve().parents[2]),
            C.byref(startup),C.byref(process)))
        return process.hProcess,process.hThread
