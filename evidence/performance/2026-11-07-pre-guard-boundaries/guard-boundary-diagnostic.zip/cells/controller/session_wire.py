"""Fixed PRE/POST/CLOSE controller framing; not an NBSR protocol."""
import json
import re

MAX_FRAME=8192
VERSION=1

def run_id(value):
    if type(value) is not str or re.fullmatch('[a-z0-9-]{1,64}',value) is None:
        raise ValueError('session run identity')
    return value

def _unique(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate JSON field')
        result[key]=value
    return result

def _nonfinite(value):
    raise ValueError('nonfinite JSON value')

def decode(wire):
    if type(wire) is not bytes or not 1<len(wire)<=MAX_FRAME or not wire.endswith(b'\n') or wire.count(b'\n')!=1:
        raise ValueError('bounded single frame required')
    value=json.loads(wire.decode('utf-8'),object_pairs_hook=_unique,parse_constant=_nonfinite)
    if type(value) is not dict:raise ValueError('object frame required')
    return value

def encode(value):
    wire=(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')
    decode(wire)
    return wire

def _identity(value,run,seq,op):
    if (type(value.get('v')) is not int or value['v']!=VERSION
            or type(value.get('seq')) is not int or value['seq']!=seq
            or value.get('run')!=run_id(run) or value.get('op')!=op):
        raise ValueError('session response identity/order')

def reply(wire,run,seq,op):
    value=decode(wire)
    if set(value)!={'v','run','seq','op','payload'} or type(value['payload']) is not dict:
        raise ValueError('response shape')
    _identity(value,run,seq,op)
    return value['payload']

class RequestState:
    def __init__(self,run):
        self.run=run_id(run)
        self.next=1
        self.failed=False

    def consume(self,wire):
        try:
            if self.failed or self.next>3:raise ValueError('session terminal')
            value=decode(wire)
            if set(value)!={'v','run','seq','op'}:raise ValueError('request shape')
            op=('PRE','POST','CLOSE')[self.next-1]
            _identity(value,self.run,self.next,op)
            self.next+=1
            return op
        except Exception:
            self.failed=True
            raise
