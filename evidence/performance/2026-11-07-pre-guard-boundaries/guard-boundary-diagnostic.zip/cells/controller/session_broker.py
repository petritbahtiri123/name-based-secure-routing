"""One owned child carries a finite PRE/POST/CLOSE SSH connection."""
import json,math,os,pathlib,queue,subprocess,sys,threading,time
from session_wire import MAX_FRAME,RequestState,decode,encode,reply,run_id
from session_files import publish,read

def main(config_path):
    path=pathlib.Path(config_path)
    with path.open('rb') as f:wire=f.read(131073)
    if len(wire)>131072:raise ValueError('broker configuration cap')
    c=json.loads(wire);root=path.parent
    if set(c)!={'run','started','deadline','request_seconds','transport','command'}:
        raise ValueError('broker configuration shape')
    run=run_id(c['run']);start=c['started'];deadline=c['deadline'];seconds=c['request_seconds']
    if any(type(n) not in (int,float) or not math.isfinite(n) for n in (start,deadline,seconds)):
        raise ValueError('finite broker clock bounds')
    if not 0<deadline-start<=88 or not 0<seconds<=10:raise ValueError('broker lifetime')
    command=c['command']
    if (type(command) is not list or not command or any(type(x) is not str or '\0' in x for x in command)
            or sum(map(len,command))>28000):raise ValueError('broker argv')
    if c['transport']=='ssh':
        prefix=['ssh','-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','-o','ConnectionAttempts=1','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2','nbsr-client']
        if len(command)!=len(prefix)+1 or command[:-1]!=prefix:raise ValueError('existing SSH route/options required')
    elif c['transport']=='local-fixture':
        if not run.startswith('fixture-') or command[0]!=sys.executable:raise ValueError('local fixture scope')
    else:raise ValueError('unapproved transport')
    previous=time.monotonic();events=[];errors=[];frames=queue.Queue(maxsize=8);total=[0];process=None;threads=[]
    result=dict(run=run,status='FAILED',responses=0,ssh_exit=None,readers_stopped=False)
    def check(limit):
        nonlocal previous
        now=time.monotonic()
        if not math.isfinite(now) or now<previous:raise ValueError('broker clock uncertainty')
        previous=now
        if now>=min(limit,deadline):raise TimeoutError('original broker/request deadline')
        if (root/'cancel').exists():raise InterruptedError('session cancelled')
        if errors:raise RuntimeError('transport reader failed: '+errors[0])
        return now
    def stdout_reader():
        try:
            while True:
                data=process.stdout.readline(MAX_FRAME+1)
                if not data:frames.put(None,timeout=.1);return
                if len(data)>MAX_FRAME:raise ValueError('SSH response frame cap')
                decode(data);frames.put(data,timeout=.1)
        except BaseException as e:errors.append(type(e).__name__)
    def stderr_reader():
        try:
            with (root/'ssh-stderr.log').open('xb') as f:
                while True:
                    data=process.stderr.read(1024)
                    if not data:return
                    total[0]+=len(data)
                    if total[0]>65536:raise ValueError('SSH stderr cap')
                    f.write(data)
        except BaseException as e:errors.append(type(e).__name__)
    def receive(limit,seq,op):
        while True:
            check(limit)
            try:data=frames.get(timeout=.02)
            except queue.Empty:continue
            check(limit)
            if data is None:raise ValueError('unexpected transport EOF')
            reply(data,run,seq,op)
            publish(root,'reply-'+str(seq),data)
            result['responses']+=1
            events.append(dict(event='reply',seq=seq,op=op,monotonic=time.monotonic()))
            return
    try:
        check(start+seconds)
        process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            creationflags=subprocess.DETACHED_PROCESS if os.name=='nt' else 0)
        for fn in (stdout_reader,stderr_reader):
            t=threading.Thread(target=fn,daemon=True);threads.append(t);t.start()
        receive(start+seconds,0,'READY')
        state=RequestState(run)
        for seq in (1,2,3):
            while True:
                check(deadline-2 if seq<3 else deadline)
                data=read(root,'request-'+str(seq))
                if data is not None:break
                if not frames.empty():raise ValueError('unsolicited transport response/EOF')
                time.sleep(.02)
            op=state.consume(data)
            limit=min(start+seconds if seq==1 else time.monotonic()+seconds,deadline-2 if seq<3 else deadline)
            check(limit);process.stdin.write(data);process.stdin.flush();check(limit)
            events.append(dict(event='request',seq=seq,op=op,monotonic=time.monotonic()))
            receive(limit,seq,op)
        process.stdin.close()
        while process.poll() is None:check(deadline);time.sleep(.02)
        if process.returncode:raise RuntimeError('SSH exited nonzero')
        for t in threads:
            check(deadline);t.join(timeout=max(0,deadline-time.monotonic()))
        check(deadline)
        if any(t.is_alive() for t in threads):raise RuntimeError('transport readers remain')
        remaining=[]
        while not frames.empty():remaining.append(frames.get_nowait())
        if remaining!=[None]:raise ValueError('missing EOF or extra response after CLOSE')
        result['status']='CLOSED'
    except BaseException as e:
        result.update(error_type=type(e).__name__,error=str(e)[:256])
        raise
    finally:
        result.update(ssh_exit=None if process is None else process.poll(),readers_stopped=all(not t.is_alive() for t in threads),
            events=events,reader_errors=errors,elapsed=time.monotonic()-start)
        publish(root,'broker-final',encode(result))
        # Failure leaves the exact process tree to its retained Windows Job owner.

if __name__=='__main__':
    main(sys.argv[1])
