"""Cold imports and exact pre-I/O path gates only; never start a peer."""
import pathlib,sys,os,json
HERE=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
if os.name=='nt':import bounded
import activate
activate.activate()
import scripts,coordinator,plan
from scripts.performance import linux_native_finite_run as finite,process_cancellation
from scripts.performance.recv_error_collection import Session
from scripts.performance.recv_error_handoff import collector_config
expected=activate.REPO.resolve()
assert {pathlib.Path(x).resolve(strict=True) for x in scripts.__path__}=={expected/'scripts'}
assert finite.ROOT==expected
config=plan.config();finite.validate_config(config)
Session(json.loads((HERE/'release-pins.json').read_bytes()),collector_config(config))
outputs=[HERE/'run01-trial/coordinator'] if os.name=='nt' else [pathlib.Path(config[r]['output']) for r in plan.HOSTS]
assert all(not x.is_symlink() and not x.resolve().is_relative_to(expected) and not x.exists() for x in outputs)
print(json.dumps(dict(status='PASS_COLD_BOOTSTRAP_NO_WORKLOAD',source_root=str(expected),package_file=scripts.__file__,package_paths=list(scripts.__path__),cancellation_file=process_cancellation.__file__,proposed_outputs=[str(x) for x in outputs],run=config['recv_errors_run'],mode=config['recv_errors_mode'])),flush=True)
