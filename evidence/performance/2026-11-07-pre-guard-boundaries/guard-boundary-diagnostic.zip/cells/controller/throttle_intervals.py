"""Bounded read-only counter samples and conservative interval arithmetic.

Cross-host offsets must be supplied as independently validated intervals.
This module does not infer clock accuracy from SSH midpoint estimates.
"""
import time
import json

FIELDS=('nr_periods','nr_throttled','throttled_usec')

def interval(lo,hi):
    if type(lo) is not int or type(hi) is not int or lo>hi:
        raise ValueError('invalid interval')
    return lo,hi

def offset_probe(local_before,remote,local_after):
    interval(local_before,local_after)
    return remote-local_after,remote-local_before

def counter_sample(paths,clock=time.monotonic_ns):
    if len(paths)!=3:raise ValueError('exact service/system/root hierarchy required')
    result={}
    for label,path in paths.items():
        before=clock()
        with path.open() as f:text=f.read(8193)
        after=clock()
        if len(text)>8192 or not 0<=after-before<=10_000_000:raise ValueError('counter read bounds')
        values={}
        for line in text.splitlines():
            k,v=line.split()
            if k in values:raise ValueError('duplicate counter')
            values[k]=int(v)
        if any(k not in values or values[k]<0 for k in FIELDS):raise ValueError('missing counter')
        result[label]={'before_ns':before,'after_ns':after,'values':values}
    return result

def event_interval(previous,current):
    if current['before_ns']<=previous['after_ns']:raise ValueError('sample order')
    deltas={k:current['values'][k]-previous['values'][k] for k in FIELDS}
    if any(v<0 for v in deltas.values()):raise ValueError('counter reset')
    if deltas['nr_throttled']==0 and deltas['throttled_usec']==0:return None
    # Increment is observed sometime after the first read and by the second.
    # It does NOT locate the beginning or duration of a throttle episode.
    return previous['before_ns'],current['after_ns']

def relative_event(event,server_offset,client_offset,origin):
    for bounds in (event,server_offset,client_offset,origin):interval(*bounds)
    return (event[0]-server_offset[1]+client_offset[0]-origin[1],
            event[1]-server_offset[0]+client_offset[1]-origin[0])

def classify(event,omission_window):
    interval(*event);interval(*omission_window)
    a,b=event;c,d=omission_window
    if b<c or a>d:return 'conditional_separation'
    if c<=a and b<=d:return 'conditional_increment_within_interval'
    return 'ambiguous_overlap'

class CounterWatch:
    """Called by the existing guard loop; never starts a thread or process."""
    def __init__(self,paths,clock=time.monotonic_ns,cpu=time.process_time_ns):
        self.paths=paths;self.clock=clock;self.cpu=cpu;self.rows=[]
        self.started=clock();self.next=self.started;self.cost=0;self.dropped=0
    def poll(self,force=False):
        now=self.clock()
        if not force and now<self.next:return
        if len(self.rows)>=800:raise ValueError('counter buffer cap')
        if self.rows and now-self.rows[-1]['end_ns']>250_000_000:
            self.dropped+=1;raise ValueError('counter coverage gap')
        before=self.cpu();values=counter_sample(self.paths,self.clock)
        self.cost+=self.cpu()-before
        end=self.clock()
        self.rows.append({'start_ns':now,'end_ns':end,'counters':values})
        self.next=end+100_000_000 # No catch-up burst after a slow poll.
        if end-self.started>=1_000_000_000 and self.cost*20>end-self.started:
            raise ValueError('counter sampler exceeds 5 percent CPU')
    def result(self):
        out={'samples':self.rows,'dropped':self.dropped,'sampling_cpu_ns':self.cost,
             'scope':'CPU cost of counter reads only; excludes existing guard work'}
        if len(json.dumps(out))>1_048_576:raise ValueError('counter output cap')
        return out

def calibration_envelope(before,after,allowance_ns):
    """Empirical pre/post envelope, NOT a physical guarantee between probes.

    Caller must report this clock model and retain ambiguous classification.
    No labels may be presented as unconditional host-clock proof.
    """
    if len(before)<3 or len(after)<3 or not 0<=allowance_ns<=50_000_000:
        raise ValueError('clock calibration coverage')
    probes=before+after
    for lo,hi in probes:
        interval(lo,hi)
        if hi-lo>250_000_000:raise ValueError('clock probe uncertainty')
    lo=min(x[0] for x in probes)-allowance_ns
    hi=max(x[1] for x in probes)+allowance_ns
    if hi-lo>350_000_000:raise ValueError('clock envelope too wide')
    return lo,hi
