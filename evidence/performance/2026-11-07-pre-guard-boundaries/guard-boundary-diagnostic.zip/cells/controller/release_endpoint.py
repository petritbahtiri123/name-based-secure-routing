from activate import activate
activate()
from scripts.performance.linux_native_finite_endpoint import main
if __name__=='__main__':main()
