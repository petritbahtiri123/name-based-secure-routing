"""Bounded client for fixed public harness slots; no transport creation here."""
import json,math,pathlib,time
from session_wire import encode,reply,run_id,decode
from session_files import publish,read

class Client:
    def __init__(self,root,run,*,guard,clock=time.monotonic):
        self.root=pathlib.Path(root);self.run=run_id(run);self.guard=guard;self.clock=clock
        with (self.root/'config.json').open('rb') as f:wire=f.read(131073)
        if len(wire)>131072:raise ValueError('client config cap')
        self.config=json.loads(wire)
        if self.config['run']!=self.run:raise ValueError('client run mismatch')
        self.started=self.config['started'];self.end=self.config['deadline'];self.seconds=self.config['request_seconds']
        if any(type(x) not in (int,float) or not math.isfinite(x) for x in (self.started,self.end,self.seconds)):
            raise ValueError('finite client clock bounds')
        if not 0<self.end-self.started<=88 or not 0<self.seconds<=10:raise ValueError('client bounds')
        self.previous=self.started

    def cancel(self):
        try:
            with (self.root/'cancel').open('xb'):pass
        except FileExistsError:pass

    def check(self,deadline):
        now=self.clock()
        if not math.isfinite(now) or now<self.previous:raise ValueError('client clock uncertainty')
        self.previous=now
        if now>=min(deadline,self.end):raise TimeoutError('original session/request deadline')
        if (self.root/'cancel').exists():raise RuntimeError('session cancelled')
        for slot in ('broker-final','ownership-final'):
            wire=read(self.root,slot)
            if wire is not None and decode(wire).get('status')!='CLOSED':raise RuntimeError('session failure latched')
        return now

    def ready(self):
        wire=read(self.root,'reply-0')
        if wire is None:raise RuntimeError('missing session readiness')
        return reply(wire,self.run,0,'READY')

    def wait(self,seq,op,deadline):
        while True:
            self.check(deadline);self.guard();self.check(deadline)
            wire=read(self.root,'reply-'+str(seq))
            if wire is not None:
                value=reply(wire,self.run,seq,op);self.ready();self.check(deadline)
                return value
            time.sleep(.02)

    def pre(self):
        try:return self.wait(1,'PRE',self.started+self.seconds)
        except BaseException:self.cancel();raise

    def exchange(self,op):
        try:
            if op not in ('POST','CLOSE'):raise ValueError('PRE only through owned startup')
            seq=2 if op=='POST' else 3
            prior=read(self.root,'reply-'+str(seq-1))
            if prior is None:raise ValueError('previous request incomplete')
            reply(prior,self.run,seq-1,'PRE' if seq==2 else 'POST')
            if read(self.root,'request-'+str(seq)) is not None:raise ValueError('request cannot be replayed')
            started=self.clock();deadline=min(started+self.seconds,self.end-(2 if op=='POST' else .25))
            self.check(deadline);self.guard();self.check(deadline)
            publish(self.root,'request-'+str(seq),encode(dict(v=1,run=self.run,seq=seq,op=op)))
            value=self.wait(seq,op,deadline)
            if op=='CLOSE':
                while True:
                    self.check(deadline)
                    wire=read(self.root,'ownership-final')
                    if wire is not None:
                        result=decode(wire)
                        if (result['status']!='CLOSED' or result['owned_handles'] or not result['leader_reaped']
                                or not result['group_exit_observed']):raise RuntimeError('session cleanup unconfirmed')
                        break
                    time.sleep(.02)
            with (self.root/(op.lower()+'-admission.json')).open('x') as f:
                json.dump(dict(run=self.run,operation=op,started=started,completed=self.clock(),deadline=deadline),f)
            return value
        except BaseException:self.cancel();raise
