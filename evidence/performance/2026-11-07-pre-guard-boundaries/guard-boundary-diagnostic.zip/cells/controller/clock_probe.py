"""Three bounded request/reply probes over one ordinary SSH session. No workload."""
import json,queue,shlex,subprocess,threading,time
from throttle_intervals import offset_probe

REMOTE="import sys,time;print('READY',flush=True)\nfor i,line in enumerate(sys.stdin):\n if i>=3 or line.strip()!=str(i):raise SystemExit(2)\n print(str(i)+' '+str(time.monotonic_ns()),flush=True)\n"

def probe(host):
    if host not in ('nbsr-client','nbsr-server'):raise ValueError('existing NBSR aliases only')
    command=['ssh','-T','-o','BatchMode=yes','-o','ConnectTimeout=8','-o','ConnectionAttempts=1',host,
             shlex.join(['timeout','15s','python3','-u','-B','-c',REMOTE])]
    p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
    q=queue.Queue(maxsize=5);errors=[];result={'host':host,'command':command,'probes':[]}
    def reader():
        try:
            for _ in range(4):
                line=p.stdout.readline(256)
                if len(line)>=256:raise ValueError('clock line cap')
                q.put(line,timeout=1)
        except BaseException as e:errors.append(type(e).__name__)
    thread=threading.Thread(target=reader,daemon=True);thread.start()
    try:
        if q.get(timeout=12).strip()!='READY':raise ValueError('clock readiness')
        for i in range(3):
            before=time.monotonic_ns();p.stdin.write(str(i)+'\n');p.stdin.flush()
            line=q.get(timeout=2);after=time.monotonic_ns();parts=line.split()
            if len(parts)!=2 or parts[0]!=str(i):raise ValueError('clock response identity')
            remote=int(parts[1]);lo,hi=offset_probe(before,remote,after)
            result['probes'].append({'local_before_ns':before,'remote_ns':remote,'local_after_ns':after,'offset_lo_ns':lo,'offset_hi_ns':hi})
            if after-before>250_000_000:raise ValueError('clock probe exceeds250ms')
        p.stdin.close();p.wait(timeout=2)
        if p.returncode or errors:raise ValueError('clock child exit/reader')
    except BaseException as e:
        result['failure']={'type':type(e).__name__,'message':str(e)[:256]}
    finally:
        if p.poll() is None:
            p.terminate()
            try:p.wait(timeout=2)
            except subprocess.TimeoutExpired:p.kill();p.wait(timeout=2)
        thread.join(timeout=1)
        result['exit']=p.returncode;result['reader_stopped']=not thread.is_alive()
        result['stderr']=p.stderr.read(2048)
        for f in (p.stdin,p.stdout,p.stderr):
            if not f.closed:f.close()
    return result

if __name__=='__main__':
    import sys
    value=probe(sys.argv[1]);print(json.dumps(value));raise SystemExit(int('failure' in value or not value['reader_stopped']))
