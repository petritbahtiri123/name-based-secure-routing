import pathlib,sys,json,time,hashlib
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));from prepare_remote import run,ssh,call
import plan,bounded

def main():
 if (HERE/'AFFINITY-LIVE-DISABLED').exists():raise RuntimeError('support-affinity qualification incomplete')
 for role in plan.HOSTS:
  if not (HERE/(role+'-capability-PASS.json')).exists():raise RuntimeError('both capability gates required')
 attempted=False;problem=None;cleanup={}
 try:
  offsets={}
  for role in plan.HOSTS:
   before_mono=time.monotonic();before=time.time();run(role,'clock',ssh(role,['python3','-B','-c','import time,json;print(json.dumps({"utc":time.time(),"monotonic":time.monotonic()}))']));after=time.time()
   clock=json.loads((HERE/('step-'+role+'-clock')/'stdout.log').read_text());stamp=clock['utc']
   offsets[role]=clock['monotonic']-time.monotonic()
   if stamp<before-120 or stamp>after+120:raise RuntimeError('clock skew exceeds120s')
  (HERE/'clock-offsets.json').write_text(json.dumps(offsets))
  public=HERE/'tls-public';public.mkdir(exist_ok=False)
  for role in plan.HOSTS:
   run(role,'start-tls',ssh(role,call(role,'start-tls')))
   run(role,'public-csr',ssh(role,[plan.ROOT+'/venv/bin/python','-B',plan.CONTROL+'/tls_roles.py',role]))
   wire=(HERE/('step-'+role+'-public-csr')/'stdout.log').read_bytes()
   if not 1<=len(wire)<=4096:raise ValueError('public CSR size')
   (public/(role+'.csr')).write_bytes(wire)
  run('local','sign-public',[sys.executable,'-B',str(HERE/'public_tls_sign.py'),str(public)])
  for role in plan.HOSTS:
   run(role,'transfer-public',['scp',str(public/'certificates/ca.der'),str(public/('certificates/'+role+'.der')),str(public/'certificates/public-hashes.json'),plan.HOSTS[role]+':/run/'+plan.UNIT[role]+'-tls/'])
  time.sleep(15)
  expected=json.loads((public/'certificates/public-hashes.json').read_text())
  for role in plan.HOSTS:
   run(role,'trial-mountpoints',ssh(role,call(role,'verify-mountpoints')))
   run(role,'trial-tls',ssh(role,call(role,'verify-tls')))
   row=json.loads((HERE/('step-'+role+'-trial-tls')/'stdout.log').read_text())
   if any(expected.get(k)!=v for k,v in row['public_hashes'].items()):raise RuntimeError('public hash mismatch')
  import session_adapter
  calibration=session_adapter.create(HERE,plan.RUN)
  trial_problem=None
  try:
   session_adapter.pre(calibration,HERE)
   attempted=True
   print('MEASUREMENT_STARTING streams32',flush=True)
   bounded.run(['@COORDINATOR@','existing-default-aliases'],HERE/'run01-trial',plan.COORDINATOR)
   calibration.close()
  except BaseException as e:
   trial_problem=e
   calibration.abort('trial failed')
  finally:
   if not calibration.wait_closed(2):
    failure=RuntimeError('temporary SSH ownership unconfirmed')
    if trial_problem is None:trial_problem=failure
    else:trial_problem.add_note(str(failure))
   try:
    request=HERE/'run01-trial/request.json'
    deadline=(json.loads(request.read_text())['started']+plan.FINALIZATION if request.exists() else calibration.deadline)
    session_adapter.verify_remote(HERE,plan.RUN,deadline)
   except BaseException as e:
    if trial_problem is None:trial_problem=e
    else:trial_problem.add_note('Calibration remote cleanup: '+type(e).__name__+': '+str(e))
  if trial_problem:raise trial_problem
  result=json.loads((HERE/'run01-trial/final-result.json').read_text());print(json.dumps(result))
 except BaseException as e:
  problem={'type':type(e).__name__,'message':str(e)}
  # On failure, no new test is launched. Repeat only exact idempotent cleanup.
  for role in plan.HOSTS:
   for action in (['finalize'] if attempted else ['remove-tls','stop-tls','cleanup-mountpoints']):
    try:run(role,'failure-'+action,ssh(role,call(role,action)))
    except BaseException as ce:cleanup[role+'-'+action]=type(ce).__name__
  (HERE/'failure.json').write_text(json.dumps({'problem':problem,'cleanup_errors':cleanup,'trial_attempted':attempted},indent=2));raise
if __name__=='__main__':main()
