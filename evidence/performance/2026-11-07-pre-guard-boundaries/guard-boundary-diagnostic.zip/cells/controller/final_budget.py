import json,plan
from prepare_remote import run,ssh
for role in plan.HOSTS:
 code="import pathlib,json; p=pathlib.Path("+repr(plan.ROOT)+"); print(json.dumps(dict(artifact_bytes=sum(f.stat().st_size for f in p.rglob('*') if f.is_file()),owned_cgroups=[str(x) for x in pathlib.Path('/sys/fs/cgroup/system.slice').glob('nbsr*')],tls_exists=pathlib.Path('/run/"+plan.UNIT[role]+"-tls').exists())))"
 run(role,'final-budget',ssh(role,['python3','-B','-c',code]))
