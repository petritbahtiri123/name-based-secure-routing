"""Opt-in Linux local process-group containment; never remote cleanup proof.

The monotonic budget includes worker startup, blocked I/O, validation and cleanup.
Kernel/filesystem stalls, scheduling starvation, escaped sessions and parent death
remain outside a userspace watchdog's guarantee. Raw coordinator APIs are unchanged.
"""

import argparse
import json
from plan import COORDINATOR, WRAPPER
# The approved short-smoke wrapper has a120s absolute bound, including drain.
WRAPPER = min(WRAPPER, 120) if COORDINATOR == 120 else WRAPPER
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

from scripts.performance.process_cancellation import Cancellation, not_cancelled


def supervise(owner, *, clock=time.monotonic, sleep=time.sleep,
              check_cancelled=not_cancelled, guard=not_cancelled, started_at=None):
    """Owner methods must be nonblocking except bounded OS process creation.

    Observe without reaping. Retain the group leader until all group members are
    absent, so its PID/PGID cannot be reused between observation and escalation.
    Cancellation and failures latch once; repeated requests never reset deadlines.
    """
    now = clock()
    started = now if started_at is None else started_at
    if (type(started) not in (int, float) or not math.isfinite(started)
            or type(now) not in (int, float) or not math.isfinite(now) or started > now):
        raise ValueError('invalid monotonic clock')
    deadline, stop_at = started + WRAPPER, started + COORDINATOR
    previous = now
    reason = None
    errors, actions = [], []
    sent = set()
    code, group_live, reaped = None, True, False

    def error(stage, exception):
        entry = dict(stage=stage, type=type(exception).__name__[:64])
        if entry not in errors and len(errors) < 16:
            errors.append(entry)

    def kill_once(now):
        if 'KILL' not in sent:
            sent.add('KILL')
            actions.append(dict(signal='KILL', elapsed_seconds=now - started if math.isfinite(now) else None))
            try:
                owner.signal('KILL')
            except Exception as exception:
                error('KILL', exception)

    try:
        if now >= deadline:
            raise TimeoutError('shared deadline expired before startup')
        guard()
        check_cancelled()
        owner.start()
    except Exception as exception:
        error('start', exception)
        reason, stop_at = 'startup', started
    if not owner.owned:
        return dict(status='INVALID_PARTIAL', reason=reason or 'ownership', errors=errors,
                    actions=actions, leader_reaped=False, group_exit_observed=False,
                    remote_cleanup='UNCONFIRMED', local_cleanup='UNCONFIRMED',
                    elapsed_seconds=clock() - started)

    while True:
        now = clock()
        if not math.isfinite(now) or now < previous:
            reason = reason or 'clock'
            # No trustworthy remaining budget: one immediate owned kill, no waits.
            kill_once(now)
            break
        previous = now
        if now >= deadline:
            reason = reason or 'deadline'
            kill_once(now)
            break
        if reason is None:
            for stage, check in [('cancel', check_cancelled), ('resource', guard)]:
                try:
                    check()
                except Exception as exception:
                    error(stage, exception)
                    reason, stop_at = stage, min(stop_at, now)
                    break
        try:
            code, group_live = owner.observe()
        except Exception as exception:
            error('observe', exception)
            reason, stop_at = reason or 'observation', min(stop_at, now)
            code, group_live = None, True
        observed_at = clock()
        if not math.isfinite(observed_at) or observed_at < now or observed_at >= deadline:
            reason = reason or ('clock' if not math.isfinite(observed_at) or observed_at < now else 'deadline')
            kill_once(observed_at)
            break
        now = observed_at
        if now >= started + COORDINATOR:
            reason = reason or 'deadline'
        if code is not None:
            if code != 0 or group_live:
                reason = reason or ('worker_exit' if code != 0 else 'remaining_group')
                stop_at = min(stop_at, now)
            if not group_live:
                try:
                    owner.reap()
                    reaped = True
                except Exception as exception:
                    error('reap', exception)
                    reason = reason or 'reap'
                break
        if reason is not None:
            for name, offset in [('INT', 0), ('TERM', 5), ('KILL', 10)]:
                if name not in sent and now >= stop_at + offset:
                    sent.add(name)
                    actions.append(dict(signal=name, elapsed_seconds=now - started))
                    try:
                        owner.signal(name)
                    except Exception as exception:
                        error(name, exception)
        sleep(min(.05, max(0, deadline - clock())))
    elapsed = clock() - started
    if elapsed >= WRAPPER:
        reason = reason or 'deadline'
    return dict(status='LOCAL_WORKER_COMPLETED' if reason is None and reaped and not errors else 'INVALID_PARTIAL',
                reason=reason, errors=errors, actions=actions, exit_code=code,
                leader_reaped=reaped, group_exit_observed=not group_live,
                remote_cleanup='UNCONFIRMED', local_cleanup='UNCONFIRMED',
                elapsed_seconds=elapsed if math.isfinite(elapsed) else None)

