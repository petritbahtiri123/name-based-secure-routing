"""Finite Linux calibration helper. No service, credentials or configuration writes."""
import json,os,pathlib,signal,subprocess,sys,time
from session_wire import MAX_FRAME,run_id
from session_agent import serve

ROOT='/home/petritbahtiri24/nbsr-sphere-20261016-01/evidence'

def parse_stat(text):
    try:
        pid=int(text[:text.index(' (')]);tail=text[text.rindex(')')+2:].split()
        result=dict(pid=pid,pgrp=int(tail[2]),start_ticks=int(tail[19]))
        if any(v<=0 for v in result.values()):raise ValueError('positive process identity')
        return result
    except (IndexError,TypeError,ValueError) as e:raise ValueError('invalid proc identity') from e

def process_identity(pid):
    return parse_stat(pathlib.Path('/proc/'+str(pid)+'/stat').read_text())

def validate_end(record,run):
    if (record.get('run')!=run or record.get('status')!='CLOSED' or record.get('requests')!=3
            or record.get('probe_calls')!=2):raise ValueError('incomplete remote end receipt')
    who=record['identity']
    if who['uid']!=1001 or who['gid']!=1001 or any(type(who[k]) is not int or who[k]<=0 for k in ('pid','pgrp','start_ticks')):
        raise ValueError('remote process identity')
    probes=record['probe_cleanup']
    if len(probes)!=2 or any(x.get('group_empty') is not True or x.get('exit')!=0 for x in probes):
        raise ValueError('remote probe ownership not closed')
    return record

def group_exists(pgid):
    try:os.killpg(pgid,0);return True
    except ProcessLookupError:return False

def probe_wrapper(clock_payload,helper_end):
    # Independent absolute watchdog survives abrupt loss of its SSH helper.
    # --foreground keeps timeout/python/SSH in this wrapper's owned group.
    return ('import os,signal,subprocess,time\n'
        'def expire(signum=None,frame=None):os.killpg(os.getpgrp(),signal.SIGKILL)\n'
        'remaining='+repr(helper_end+2)+'-time.monotonic()\n'
        'if remaining<=0:expire()\n'
        'signal.signal(signal.SIGALRM,expire)\n'
        'signal.setitimer(signal.ITIMER_REAL,min(10,remaining))\n'
        'p=subprocess.run('+repr(['timeout','--foreground','--kill-after=2s','8s','python3','-u','-B','-c',clock_payload])+')\n'
        'raise SystemExit(p.returncode)\n')

def main(run,clock_payload):
    import resource,select
    run_id(run)
    if os.getuid()!=1001 or os.getgid()!=1001:raise ValueError('expected benchmark user1001')
    base=pathlib.Path(ROOT)
    if base.is_symlink() or base.resolve()!=base or not base.is_dir():raise ValueError('existing evidence root required')
    root=base/('calibration-'+run);root.mkdir(mode=0o700,exist_ok=False)
    def write(name,record):
        wire=json.dumps(record,allow_nan=False).encode()
        if len(wire)>8192:raise ValueError('receipt size')
        fd=os.open(root/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as f:f.write(wire)
    who=process_identity(os.getpid());who.update(uid=os.getuid(),gid=os.getgid())
    write('identity.json',dict(run=run,identity=who))
    started=time.monotonic();end=started+70;buffer=bytearray();cleanups=[]
    def interrupted(signum,frame):raise InterruptedError('helper termination')
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
    def receive(deadline):
        while True:
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('original helper read deadline')
            if b'\n' in buffer:
                line,_,tail=buffer.partition(b'\n');buffer[:]=tail
                if len(line)+1>MAX_FRAME:raise ValueError('remote frame size')
                return bytes(line)+b'\n'
            if len(buffer)>=MAX_FRAME:raise ValueError('remote frame cap')
            if not select.select([0],[],[],remaining)[0]:raise TimeoutError('remote input expired')
            chunk=os.read(0,MAX_FRAME-len(buffer))
            if not chunk:return b''
            buffer.extend(chunk)
    def send(wire):
        while wire:
            remaining=end-time.monotonic()
            if remaining<=0 or not select.select([],[1],[],remaining)[1]:raise TimeoutError('remote output expired')
            count=os.write(1,wire)
            if count<=0:raise ValueError('remote output closed')
            wire=wire[count:]
    def metrics():
        r=resource.getrusage(resource.RUSAGE_SELF)
        return dict(monotonic_ns=time.monotonic_ns(),cpu_ns=round((r.ru_utime+r.ru_stime)*1e9),peak_rss_bytes=r.ru_maxrss*1024)
    def probe():
        # Same pinned three-probe code and original8+2s inner timeout. This
        # process group is owned explicitly; the outer helper has70+2s expiry.
        limit=min(end-2,time.monotonic()+10)
        if limit<=time.monotonic():raise TimeoutError('no probe cleanup budget')
        p=subprocess.Popen(['python3','-u','-B','-c',probe_wrapper(clock_payload,end)],
            stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        record=dict(pid=p.pid,pgrp=p.pid,start_ticks=None,exit=None,group_empty=False)
        try:
            record.update(process_identity(p.pid));write('probe-'+str(len(cleanups)+1)+'.json',record)
            out,err=p.communicate(timeout=max(.001,limit-time.monotonic()))
            if len(out)>8192 or len(err)>4096:raise ValueError('clock output cap')
            if p.returncode:raise ValueError('clock subprocess failed')
            value=json.loads(out)
            if value.get('failure') or value.get('exit')!=0 or value.get('reader_stopped') is not True:
                raise ValueError('internal clock failed')
            return value
        finally:
            # Cleanup observations do not renew the request or helper budget.
            if group_exists(p.pid):os.killpg(p.pid,signal.SIGKILL)
            if p.poll() is None:p.wait(timeout=max(.001,min(2,end-time.monotonic())))
            for stream in (p.stdout,p.stderr):stream.close()
            record.update(exit=p.returncode,group_empty=not group_exists(p.pid));cleanups.append(record)
            if record['group_empty'] is not True:raise RuntimeError('clock process group remains')
    def ended(record):
        record['probe_cleanup']=cleanups;record['elapsed_seconds']=time.monotonic()-started
        write('ended.json',record)
    return serve(run,receive,send,probe,identity=lambda:who,metrics=metrics,ended=ended,lifetime=70)

def read_receipt(path):
    if path.is_symlink() or not path.is_file() or path.stat().st_uid!=1001 or path.stat().st_size>8192:raise ValueError('public receipt identity/size')
    return json.loads(path.read_bytes())

def inspect(run):
    """Independent read-only receipt/identity check; never signal another process."""
    run_id(run);root=pathlib.Path(ROOT)/('calibration-'+run)
    if root.is_symlink() or root.resolve()!=root:raise ValueError('receipt directory identity')
    errors=[];identity=None;ended=None;execution_valid=False;identities=[];observations=[]
    try:
        identity=read_receipt(root/'identity.json')
        if identity['run']!=run:raise ValueError('identity run mismatch')
        who=identity['identity']
        if who['uid']!=1001 or who['gid']!=1001:raise ValueError('identity user mismatch')
        identities.append(who)
    except (OSError,ValueError,KeyError,TypeError) as e:errors.append('identity:'+type(e).__name__)
    try:
        ended=read_receipt(root/'ended.json')
        if ended['run']!=run or identity is None or ended['identity']!=identity['identity']:raise ValueError('end identity mismatch')
        identities.extend(ended['probe_cleanup'])
        if (type(ended.get('probe_calls')) is not int or not 0<=ended['probe_calls']<=2
                or type(ended['probe_cleanup']) is not list or len(ended['probe_cleanup'])!=ended['probe_calls']):
            raise ValueError('missing probe identity coverage')
        try:validate_end(ended,run);execution_valid=True
        except (ValueError,KeyError,TypeError):pass
    except (OSError,ValueError,KeyError,TypeError) as e:errors.append('end:'+type(e).__name__)
    for n in (1,2):
        path=root/('probe-'+str(n)+'.json')
        if path.exists():
            try:identities.append(read_receipt(path))
            except (OSError,ValueError,KeyError,TypeError) as e:errors.append('probe:'+type(e).__name__)
    seen=set()
    for who in identities:
        try:
            key=tuple(who[k] for k in ('pid','pgrp','start_ticks'))
            if any(type(v) is not int or v<=0 for v in key):raise ValueError('incomplete identity')
            if key in seen:continue
            seen.add(key)
            try:current=process_identity(who['pid'])
            except FileNotFoundError:current=None
            present=current is not None and current['start_ticks']==who['start_ticks']
            group_present=group_exists(who['pgrp'])
            observations.append(dict(identity=who,current=current,original_present=present,group_present=group_present))
        except (OSError,ValueError,KeyError,TypeError) as e:errors.append('observation:'+type(e).__name__)
    clean=not errors and bool(observations) and all(not x['original_present'] and not x['group_present'] for x in observations)
    status='REMOTE_CLOSED' if clean and execution_valid else 'REMOTE_FAILED_CLEANUP_CONFIRMED' if clean else 'REMOTE_CLEANUP_UNCONFIRMED'
    return dict(run=run,status=status,execution_valid=execution_valid,cleanup_confirmed=clean,errors=errors,identity=identity,ended=ended,observations=observations)
