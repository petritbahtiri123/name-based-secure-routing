"""Finite remote controller state; clock probe implementation remains external/pinned."""
import math
import time
from session_wire import RequestState,encode

def serve(run,receive,send,probe,*,identity,metrics,ended,clock=time.monotonic,lifetime=70):
    if type(lifetime) not in (int,float) or not math.isfinite(lifetime) or not 0<lifetime<=70:
        raise ValueError('finite agent lifetime')
    state=RequestState(run);start=clock();deadline=start+lifetime;previous=start
    record=dict(run=run,status='FAILED',requests=0,probe_calls=0)
    def check():
        nonlocal previous
        now=clock()
        if not math.isfinite(now) or not math.isfinite(previous) or now<previous:
            raise ValueError('agent clock uncertainty')
        previous=now
        if now>=deadline:raise TimeoutError('original agent lifetime expired')
        return now
    def respond(seq,op,payload):
        check();send(encode(dict(v=1,run=run,seq=seq,op=op,payload=payload)));check()
    try:
        check();who=identity();record['identity']=who
        respond(0,'READY',dict(identity=who,metrics=metrics(),lifetime_seconds=lifetime))
        while True:
            check();wire=receive(deadline);check()
            if not wire:raise ValueError('EOF before explicit CLOSE')
            op=state.consume(wire);seq=state.next-1;record['requests']=seq
            before=metrics();entered=check()
            if op=='CLOSE':
                respond(seq,op,dict(identity=who,metrics=before,probe_calls=record['probe_calls']))
                record['status']='CLOSED'
                break
            record['probe_calls']+=1
            result=probe();check();after=metrics()
            respond(seq,op,dict(result=result,before=before,after=after,entered_seconds=entered-start))
        return record
    except BaseException as error:
        record['error_type']=type(error).__name__
        raise
    finally:
        # Receipt failure remains fatal; no success can precede process exit.
        ended(record)
