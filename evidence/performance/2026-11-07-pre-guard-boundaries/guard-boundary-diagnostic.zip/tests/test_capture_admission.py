import importlib,importlib.util,json,pathlib,sys,tempfile,unittest
H=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(H))
class AdmissionTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('capture_admission'),'supervised admission missing')
  self.m=importlib.import_module('capture_admission');self.root=pathlib.Path(tempfile.mkdtemp(prefix='admission-',dir=H/'evidence'));self.token='a'*32
  self.out=self.root/'evidence/capture-command';self.out.mkdir(parents=True)
  (self.root/'plan.json').write_text(json.dumps(dict(live=dict(run='fixture-pre'))))
  self.claim=dict(run='fixture-pre',token=self.token,parent_pid=100,parent_created=1234,created=89)
  (self.root/'attempt.json').write_text(json.dumps(self.claim))
  request=dict(argv=[sys.executable,'-u','-B',str(self.root/'supervised_entry.py'),self.token],output=str(self.out.resolve()),started=90)
  (self.out/'request.json').write_text(json.dumps(request))
 def take(self,identity=None):return self.m.consume(self.root,self.token,clock=lambda:100,identity=identity or (lambda pid:dict(created=1234,alive=True)))
 def test_valid_live_parent_consumed_once(self):
  self.assertEqual(self.take(),150)
  with self.assertRaises(FileExistsError):self.take()
 def test_missing_outer_claim_rejected(self):
  (self.root/'attempt.json').unlink()
  with self.assertRaises((ValueError,FileNotFoundError)):self.take()
 def test_outer_admission_failure_without_request_rejected(self):
  (self.out/'request.json').unlink()
  with self.assertRaises((ValueError,FileNotFoundError)):self.take()
 def test_dead_or_reused_outer_parent_rejected(self):
  for who in (dict(created=1234,alive=False),dict(created=1235,alive=True)):
   with self.subTest(who=who),self.assertRaises(ValueError):self.take(lambda pid:who)
 def test_stale_original_outer_deadline_rejected(self):
  with self.assertRaises(TimeoutError):self.m.consume(self.root,self.token,clock=lambda:150,identity=lambda pid:dict(created=1234,alive=True))
 def test_wrong_token_rejected_without_consuming(self):
  with self.assertRaises(ValueError):self.m.consume(self.root,'b'*32,clock=lambda:100,identity=lambda pid:dict(created=1234,alive=True))
  self.assertFalse((self.root/'child-admission.json').exists())
 def test_private_function_requires_the_consuming_child_identity(self):
  self.take()
  self.assertTrue(hasattr(self.m,'validate_consumed'))
  with self.assertRaises(ValueError):self.m.validate_consumed(self.root,150,clock=lambda:100,identity=lambda pid:dict(created=1234,alive=True),pid=99999)
 def test_private_function_rejects_missing_consumption(self):
  self.assertTrue(hasattr(self.m,'validate_consumed'))
  with self.assertRaises(FileNotFoundError):self.m.validate_consumed(self.root,150,clock=lambda:100,identity=lambda pid:dict(created=1234,alive=True),pid=100)
if __name__=='__main__':unittest.main(verbosity=2)
