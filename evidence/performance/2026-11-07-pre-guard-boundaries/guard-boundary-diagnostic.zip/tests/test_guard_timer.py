import importlib,importlib.util,pathlib,sys,unittest
H=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(H))
class TimerTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('guard_timer'),'boundary recorder missing')
  self.m=importlib.import_module('guard_timer');self.now=100;self.thread=1
 def timer(self,limit=64):return self.m.GuardTimer(clock=lambda:self.now,thread=lambda:self.thread,limit=limit)
 def test_success_preserves_same_value_and_call_arguments(self):
  t=self.timer();value=object();calls=[]
  def fn(*a,**kw):calls.append((a,kw));self.now=200;return value
  wrapped=t.wrap('resource_check',fn)
  self.assertIs(wrapped(1,starting=False),value);self.assertEqual(calls,[((1,),dict(starting=False))])
  self.assertEqual(t.rows,[dict(sequence=1,kind='resource_check',begin_ns=100,end_ns=200,error_type=None)])
 def test_original_exception_propagates_with_closed_boundary(self):
  t=self.timer();error=OSError('fixture')
  def fn():self.now=150;raise error
  with self.assertRaises(OSError) as seen:t.wrap('guard',fn)()
  self.assertIs(seen.exception,error);self.assertEqual(t.rows[0]['end_ns'],150);self.assertEqual(t.rows[0]['error_type'],'OSError')
 def test_nested_call_order_is_preserved(self):
  t=self.timer();events=[]
  def inner():events.append('inner');self.now=120
  resource=t.wrap('resource_check',inner)
  def outer():events.append('outer');self.now=110;resource();self.now=130
  t.wrap('guard',outer)()
  self.assertEqual(events,['outer','inner']);self.assertEqual([r['sequence'] for r in t.rows],[1,2]);self.assertEqual([r['begin_ns'] for r in t.rows],[100,110]);self.assertEqual([r['end_ns'] for r in t.rows],[130,120])
 def test_overflow_stops_before_unrecorded_call(self):
  t=self.timer(1);calls=[];wrapped=t.wrap('guard',lambda:calls.append(1));wrapped()
  with self.assertRaises(RuntimeError):wrapped()
  self.assertEqual(calls,[1]);self.assertTrue(t.invalid)
 def test_clock_rollback_invalidates_recording(self):
  t=self.timer()
  def fn():self.now=99
  with self.assertRaises(ValueError):t.wrap('guard',fn)()
  self.assertTrue(t.invalid)
 def test_cross_thread_call_never_invokes_guard(self):
  t=self.timer();calls=[];wrapped=t.wrap('guard',lambda:calls.append(1));self.thread=2
  with self.assertRaises(RuntimeError):wrapped()
  self.assertFalse(calls);self.assertTrue(t.invalid)
 def test_trace_failure_latched(self):
  t=self.timer(1);wrapped=t.wrap('guard',lambda:None);wrapped()
  with self.assertRaises(RuntimeError):wrapped()
  t.rows.clear()
  with self.assertRaises(RuntimeError):wrapped()
 def test_exit_clock_failure_preserves_original_guard_exception(self):
  t=self.timer();error=OSError('original resource failure')
  def fn():self.now=99;raise error
  with self.assertRaises(OSError) as seen:t.wrap('resource_check',fn)()
  self.assertIs(seen.exception,error);self.assertTrue(t.invalid)
 def test_raised_entry_clock_failure_is_latched(self):
  calls=[]
  def clock():
   calls.append(1)
   if len(calls)==1:raise OSError('clock unavailable')
   return 100
  t=self.m.GuardTimer(clock=clock,thread=lambda:1)
  with self.assertRaises(OSError):t.wrap('guard',lambda:None)()
  self.assertTrue(t.invalid)
  with self.assertRaises(RuntimeError):t.wrap('guard',lambda:None)()
if __name__=='__main__':unittest.main(verbosity=2)
