import importlib,importlib.util,pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
class AnalysisTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('analyze_trace'),'boundary analysis missing')
  self.m=importlib.import_module('analyze_trace')
 def rows(self,last=10.1):
  result=[]
  for a,b in ((0,.5),(.52,2),(2.02,last)):
   for kind,x,y in (('guard',a,b),('resource_check',a+.001,b-.001)):
    result.append(dict(sequence=len(result)+1,kind=kind,begin_ns=round((100+x)*1e9),end_ns=round((100+y)*1e9),error_type=None))
  return result
 def broker(self,reply=9):
  rows=[dict(event='reply',op='READY',seq=0,monotonic=107),dict(event='request',op='PRE',seq=1,monotonic=107.1)]
  if reply is not None:rows.append(dict(event='reply',op='PRE',seq=1,monotonic=100+reply))
  return rows
 def test_buffered_reply_and_crossed_guard_identified(self):
  v=self.m.analyze(self.rows(),100,self.broker(),'REJECTED_AT_ORIGINAL_PRE_DEADLINE')
  self.assertEqual(v['finding'],'CURRENT_GUARD_CROSSED_PRE_DEADLINE_WITH_REPLY_BUFFERED')
  self.assertEqual(v['reply_inside_guard'],3);self.assertEqual(v['deadline_crossing_guards'],[3])
 def test_before_deadline_guard_does_not_claim_late_admission(self):
  v=self.m.analyze(self.rows(9.5),100,self.broker(),'ACCEPTED_WITHIN_ORIGINAL_PRE_WINDOW')
  self.assertEqual(v['finding'],'REPLY_BUFFERED_DURING_GUARD_WITHOUT_DEADLINE_CROSSING')
 def test_no_reply_cannot_prove_ready_response_was_delayed(self):
  v=self.m.analyze(self.rows(),100,self.broker(None),'REJECTED_AT_ORIGINAL_PRE_DEADLINE')
  self.assertEqual(v['finding'],'NO_PRE_REPLY_OBSERVED');self.assertIsNone(v['reply_inside_guard'])
 def test_missing_resource_boundary_rejected(self):
  with self.assertRaises(ValueError):self.m.analyze(self.rows()[:-1],100,self.broker(),'REJECTED_AT_ORIGINAL_PRE_DEADLINE')
 def test_reversed_clock_rejected(self):
  rows=self.rows();rows[0]['end_ns']=rows[0]['begin_ns']-1
  with self.assertRaises(ValueError):self.m.analyze(rows,100,self.broker(),'REJECTED_AT_ORIGINAL_PRE_DEADLINE')
 def test_accepted_status_after_deadline_rejected(self):
  with self.assertRaises(ValueError):self.m.analyze(self.rows(),100,self.broker(),'ACCEPTED_WITHIN_ORIGINAL_PRE_WINDOW')
if __name__=='__main__':unittest.main(verbosity=2)
