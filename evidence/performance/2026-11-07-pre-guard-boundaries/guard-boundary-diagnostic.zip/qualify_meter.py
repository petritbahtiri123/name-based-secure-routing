"""Four small control/recorder batches; no filesystem walk or VM connection."""
import json,os,pathlib,sys,time
from guard_timer import GuardTimer
from capture_admission import process_identity
H=pathlib.Path(__file__).resolve().parent;plan=json.loads((H/'plan.json').read_bytes());screen=plan['meter_qualification']
own_identity=process_identity(os.getpid())
if not own_identity['alive'] or own_identity['created']<=0:raise RuntimeError('local parent identity API check')
def noop():return None
rows=[]
for block in range(screen['local_blocks']):
    for mode in (('control','recorded') if block%2==0 else ('recorded','control')):
        timer=GuardTimer();fn=noop if mode=='control' else timer.wrap('guard',noop)
        start=time.monotonic_ns()
        for _ in range(screen['calls_per_block']):fn()
        elapsed=time.monotonic_ns()-start
        if mode=='recorded':assert not timer.invalid and len(timer.rows)==64 and all(r['end_ns']>=r['begin_ns'] and r['error_type'] is None for r in timer.rows)
        rows.append(dict(block=block,mode=mode,calls=64,elapsed_ns=elapsed))
passed=all(r['elapsed_ns']<=screen['maximum_batch_ns'] for r in rows if r['mode']=='recorded')
result=dict(status='PASS_FINITE_RECORDER_SCREEN' if passed else 'STOP_RECORDER_SCREEN_FAILED',rows=rows,
 local_identity_api=own_identity,
 threshold_ns=screen['maximum_batch_ns'],interpretation='Entire recorded64-call batch compared with10ms; control retained, no subtraction or causal overhead estimate. Finite scheduling observation only.')
name='meter-qualification-after-review.json' if sys.argv[1:]==['after-review'] else 'meter-qualification.json'
if sys.argv[1:] not in ([],['after-review']):raise ValueError('fixed local meter stages')
with (H/'evidence'/name).open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result));assert passed
